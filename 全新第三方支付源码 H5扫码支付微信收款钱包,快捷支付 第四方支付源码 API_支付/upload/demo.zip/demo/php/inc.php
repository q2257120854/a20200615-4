<?php
header('Content-Type:text/html;charset=utf8');
date_default_timezone_set('Asia/Shanghai');

$userid='10000';
$userkey='4767571f087847dc35bd0a4c1b67ed44a12130a1';
?>
