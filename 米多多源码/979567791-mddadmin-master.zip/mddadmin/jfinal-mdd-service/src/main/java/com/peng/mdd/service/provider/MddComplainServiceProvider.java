package com.peng.mdd.service.provider;

import com.jfinal.plugin.activerecord.Page;
import com.peng.mdd.model.MddComplain;
import com.peng.mdd.service.MddComplainService;
import com.peng.service.provider.BaseServiceProvider;

import java.util.ArrayList;
import java.util.List;


public class MddComplainServiceProvider extends BaseServiceProvider<MddComplain> implements MddComplainService {

    @Override
    public Page<MddComplain> list(Integer pageNumber, Integer pageSize,Long task_id, Long uid) {
        List<Object> para = new ArrayList<Object>();
        StringBuffer sql = new StringBuffer();
        sql.append("from mdd_complain where 1=1 ");
        if (task_id != null){
            sql.append(" and task_id = ?");
            para.add(task_id);
        }
        if (uid != null){
            sql.append(" and uid = ?");
            para.add(uid);
        }
        return DAO.paginate(pageNumber,pageSize,"select * ",sql.toString(),para.toArray());
    }
}