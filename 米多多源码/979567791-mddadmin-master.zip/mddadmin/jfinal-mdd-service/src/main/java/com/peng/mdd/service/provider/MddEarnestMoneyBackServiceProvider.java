package com.peng.mdd.service.provider;

import com.jfinal.plugin.activerecord.Page;
import com.peng.mdd.model.MddEarnestMoneyBack;
import com.peng.mdd.service.MddEarnestMoneyBackService;
import com.peng.service.provider.BaseServiceProvider;

import java.util.ArrayList;
import java.util.List;


public class MddEarnestMoneyBackServiceProvider extends BaseServiceProvider<MddEarnestMoneyBack> implements MddEarnestMoneyBackService {

    @Override
    public Page<MddEarnestMoneyBack> list(Integer pageNumber, Integer pageSize,Long uid,Integer state) {
        List<Object> para = new ArrayList<Object>();
        StringBuffer sql = new StringBuffer();
        sql.append("from mdd_earnest_money_back where 1=1 ");
        if (uid != null){
            sql.append(" and uid = ?");
            para.add(uid);
        }
        if (state != null){
            sql.append(" and state = ?");
            para.add(state);
        }
        return DAO.paginate(pageNumber,pageSize,"select * ",sql.toString(),para.toArray());
    }
}