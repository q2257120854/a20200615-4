package com.peng.mdd.service.provider;

import com.peng.config.Constants;
import com.peng.mdd.model.MddChat;
import com.peng.mdd.service.MddChatService;
import com.peng.service.provider.BaseServiceProvider;
import org.apache.commons.lang3.StringUtils;

import java.util.List;


public class MddChatServiceProvider extends BaseServiceProvider<MddChat> implements MddChatService {

    @Override
    public List<MddChat> list(Object myTaskId) {
        List<MddChat> chatList = MddChat.dao.find("select * from mdd_chat where mytask_id = ?",myTaskId);
        for (MddChat chat:chatList) {
            if (StringUtils.isNotBlank(chat.getImageList())) {
                StringBuffer imgSb = new StringBuffer();
                String[] explainImgArr = chat.getImageList().split(",");
                for (String img: explainImgArr) {
                    imgSb.append(Constants.QINIU_DOMAIN+img+",");
                }
                imgSb.deleteCharAt(imgSb.length()-1);
                chat.setImageList(imgSb.toString());
            }
        }
        return chatList;
    }
}