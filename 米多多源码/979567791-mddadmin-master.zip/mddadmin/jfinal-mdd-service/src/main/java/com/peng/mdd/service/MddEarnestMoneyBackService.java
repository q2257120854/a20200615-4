package com.peng.mdd.service;

import com.jfinal.plugin.activerecord.Page;
import com.peng.mdd.model.MddEarnestMoneyBack;
import com.peng.service.BaseService;

public interface MddEarnestMoneyBackService extends BaseService {

    Page<MddEarnestMoneyBack> list(Integer pageNumber, Integer pageSize, Long uid,Integer state);
}