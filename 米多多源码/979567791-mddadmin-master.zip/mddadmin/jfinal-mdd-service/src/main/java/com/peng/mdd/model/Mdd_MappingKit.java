package com.peng.mdd.model;

import com.jfinal.plugin.activerecord.ActiveRecordPlugin;

/**
 * Created by wupeng on 2019/5/8.
 */
public class Mdd_MappingKit {
    public static void mapping(ActiveRecordPlugin arp) {
        arp.addMapping("mdd_account_detail", "id", MddAccountDetail.class);
        arp.addMapping("mdd_appeal", "id", MddAppeal.class);
        arp.addMapping("mdd_banner", "id", MddBanner.class);
        arp.addMapping("mdd_chat", "id", MddChat.class);
        arp.addMapping("mdd_complain", "id", MddComplain.class);
        arp.addMapping("mdd_config", "id", MddConfig.class);
        arp.addMapping("mdd_earnest_money_back", "id", MddEarnestMoneyBack.class);
        arp.addMapping("mdd_invite_code", "id", MddInviteCode.class);
        arp.addMapping("mdd_follow", "id", MddFollow.class);
        arp.addMapping("mdd_message", "id", MddMessage.class);
        arp.addMapping("mdd_my_task", "id", MddMyTask.class);
        arp.addMapping("mdd_notice", "id", MddNotice.class);
        arp.addMapping("mdd_report", "id", MddReport.class);
        arp.addMapping("mdd_task", "id", MddTask.class);
        arp.addMapping("mdd_task_step", "id", MddTaskStep.class);
        arp.addMapping("mdd_task_type", "id", MddTaskType.class);
        arp.addMapping("mdd_user", "id", MddUser.class);
        arp.addMapping("mdd_trade", "id", MddTrade.class);
    }
}
