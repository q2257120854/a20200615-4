package com.peng.mdd.service.provider;

import com.jfinal.plugin.activerecord.Page;
import com.peng.mdd.model.MddNotice;
import com.peng.mdd.service.MddNoticeService;
import com.peng.service.provider.BaseServiceProvider;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.List;


public class MddNoticeServiceProvider extends BaseServiceProvider<MddNotice> implements MddNoticeService {


    @Override
    public List<MddNotice> list() {
        return DAO.find("select * from mdd_notice order by sort");
    }

    @Override
    public Page<MddNotice> list(Integer pageNumber, Integer pageSize, String content) {
        List<Object> para = new ArrayList<Object>();
        StringBuffer sql = new StringBuffer();
        sql.append("from mdd_notice where 1=1 ");
        if (StringUtils.isNotBlank(content)){
            sql.append(" and content like ?");
            para.add("%"+content+"%");
        }
        return DAO.paginate(pageNumber,pageSize,"select * ",sql.toString(),para.toArray());
    }
}