package com.peng.mdd.service;

import com.jfinal.plugin.activerecord.Page;
import com.peng.mdd.model.MddUser;
import com.peng.service.BaseService;

import java.util.List;

public interface MddUserService  extends BaseService {

    MddUser info(Long uid);

    MddUser login(String phone,String pwd);

    MddUser findByPhone(String phone);

    List<MddUser> listByPid(Long pid);

    Page<MddUser> list(Integer pageNumber, Integer pageSize,Long id ,String phone ,Integer state,Long pid);

    MddUser searchCaptain(Long pid, Integer count);

    /**
     * 直推数量
     * @param pid
     * @return
     */
    Integer countByPid(Long pid);

    /**
     * 升级队长
     * @param pid
     * @param count
     */
    public void upCaptain(Long pid, Integer count);

    /**
     * 团队数量
     * @param pid
     * @param count
     * @param totalCount
     * @return
     */
    Integer countAllByPid(Long pid, Integer count, Integer totalCount);

    /**
     * 收入分红
     * @param user
     * @param money
     * @param op
     */
    void income(MddUser user, Float money, String op);

    /**
     * 米币
     * @param user
     * @param money
     * @param op
     */
    void micoin(MddUser user, Float money, String op);
}