package com.peng.mdd.service.provider;

import com.jfinal.aop.Inject;
import com.jfinal.plugin.activerecord.Db;
import com.jfinal.plugin.activerecord.IAtom;
import com.jfinal.plugin.activerecord.Page;
import com.peng.config.DataSource;
import com.peng.enums.AccountDetailEnum;
import com.peng.enums.GradeEnum;
import com.peng.enums.MyPublishEnum;
import com.peng.enums.MyTaskEnum;
import com.peng.mdd.model.*;
import com.peng.mdd.service.MddConfigService;
import com.peng.mdd.service.MddTaskService;
import com.peng.mdd.service.MddUserService;
import com.peng.service.provider.BaseServiceProvider;
import com.peng.utils.PushUtils;
import org.apache.commons.lang3.StringUtils;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class MddTaskServiceProvider extends BaseServiceProvider<MddTask> implements MddTaskService {

    @Inject
    private MddConfigService configService;
    @Inject
    private MddUserService userService;

    @Override
    public Page<MddTask> list(Integer pageNumber, Integer pageSize, String title,Integer state,Long id) {
        List<Object> para = new ArrayList<Object>();
        StringBuffer sql = new StringBuffer();
        sql.append("from mdd_task a where del_state = 0 ");
        if (id != null){
            sql.append(" and id = ?");
            para.add(id);
        }
        if (StringUtils.isNotBlank(title)){
            sql.append(" and title like ?");
            para.add("%"+title+"%");
        }
        if (state != null){
            sql.append(" and state = ?");
            para.add(state);
        }
        sql.append(" order by add_time desc");
        return DAO.paginate(pageNumber,pageSize,"select a.*,(a.total_count - ( SELECT count(*) AS finish_count FROM mdd_my_task WHERE task_id = a.id)) AS residue_count ",sql.toString(),para.toArray());
    }

//    @Override
//    public Boolean top(MddUser user, MddTask task) {
//
//        return Db.use(DataSource.MDD).tx(new IAtom() {
//            @Override
//            public boolean run() throws SQLException {
//                user.update();
//
//                task.update();
//                return true;
//            }
//        });
//    }

    @Override
    public MddTask findById(Object id) {
        MddTask task = MddTask.dao.findFirst("select * from mdd_task where del_state = 0 and id = ?",id);
        return task;
    }

    @Override
    public MddTask findByIdWithUid(Object id, Object uid) {
        MddTask task = MddTask.dao.findFirst("select * from mdd_task where del_state = 0 and id = ? and uid = ?",id,uid);
        return task;
    }

    @Override
    public void finish(final MddUser user, final MddTask task, final MddMyTask mmt) {
        Db.use(DataSource.MDD).tx(new IAtom() {

            @Override
            public boolean run() throws SQLException {
                //接单者加钱
                userService.income(user, task.getPrice(), AccountDetailEnum.任务获得.getMsg()+task.getTitle());
                // 新增消息记录
                MddMessage msg = new MddMessage();
                msg.setTitle("收入提醒");
                StringBuffer content = new StringBuffer("亲,您有一笔收入到账!<br/>");
                content.append("收入类型:任务"+task.getTitle()+"获得<br/>");
                content.append("收入金额:"+task.getPrice()+"<br/>");
                content.append("劳动换来的果实特别甜,继续加油吧!");
                msg.setContent(content.toString());
                msg.setUid(user.getId());
                msg.save();

                // 发送推送通知
                String body = "收入金额:"+task.getPrice();
                PushUtils.push(user.getId().toString(), msg.getTitle(), body);

                //邀请人奖励 一级
                MddUser pUser = MddUser.dao.findById(user.getPid());
                if (pUser != null) {

                    //佣金
                    Float commission1 = Float.valueOf(MddConfig.dao.findFirst("select * from mdd_config where mc_key = 'commission1'").getMcValue());

                    Float money = task.getPrice()*commission1;
                    userService.income(pUser, money, AccountDetailEnum.一级佣金.getMsg()+task.getTitle());


                    // 判断上级是否是队长
                    if (pUser.getGrade().equals(GradeEnum.会员.getCode())){
                        // 开始用递归寻找队长
                        MddUser capUser = userService.searchCaptain(pUser.getPid(),10);
                        if (capUser != null){
                            // 找到队长后给队长专属奖励
                            Float commission2 = Float.valueOf(MddConfig.dao.findFirst("select * from mdd_config where mc_key = 'commission2'").getMcValue());
                            money = task.getPrice()*commission2;
                            userService.income(capUser, money, AccountDetailEnum.队长佣金.getMsg()+task.getTitle());
                        }
                    }
                }

                //更新任务状态
                mmt.setState(MyTaskEnum.已完成.getCode());
                mmt.update();
                //提交数量减1
                //task.setSubmitCount(task.getSubmitCount()-1);
                //完成任务数量加1
                //task.setFinishCount(task.getFinishCount()+1);
                //发布者扣钱
                task.setBalance(task.getBalance()-task.getPrice());
                //更新发布者任务状态
                if (finishCountByTaskId(task.getId()) >= task.getTotalCount()) {
                    task.setState(MyPublishEnum.已结束.getCode());
                }
                task.update();

                return true;
            }
        });
    }

    @Override
    public Integer finishCountByTaskId(Long taskId) {
        return Db.use(DataSource.MDD).findFirst("SELECT count(*) AS count FROM mdd_my_task WHERE task_id = ?",taskId).getInt("count");
    }

    @Override
    public Integer unsubmitCountByTaskId(Long taskId) {
        return Db.use(DataSource.MDD).findFirst("SELECT count(*) AS count FROM mdd_my_task WHERE task_id = ? and state = 1",taskId).getInt("count");
    }


}