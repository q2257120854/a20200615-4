package com.peng.mdd.service.provider;

import com.jfinal.plugin.activerecord.Page;
import com.peng.mdd.model.MddConfig;
import com.peng.mdd.service.MddConfigService;
import com.peng.service.provider.BaseServiceProvider;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.List;


public class MddConfigServiceProvider extends BaseServiceProvider<MddConfig> implements MddConfigService {

    @Override
    public Page<MddConfig> list(Integer pageNumber, Integer pageSize,String mc_desc ) {
        List<Object> para = new ArrayList<Object>();
        StringBuffer sql = new StringBuffer();
        sql.append("from mdd_config where 1=1 ");
        if (StringUtils.isNotBlank(mc_desc)){
            sql.append(" and mc_desc like ?");
            para.add("%"+mc_desc+"%");
        }
        return DAO.paginate(pageNumber,pageSize,"select * ",sql.toString(),para.toArray());
    }

    @Override
    public String getConfig(String key) {
        MddConfig config = DAO.findFirst("select mc_value from mdd_config where mc_key = ?",key);
        return config.getMcValue();
    }
}