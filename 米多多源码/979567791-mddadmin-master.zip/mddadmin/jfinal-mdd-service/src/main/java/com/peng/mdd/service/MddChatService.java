package com.peng.mdd.service;

import com.peng.mdd.model.MddChat;
import com.peng.service.BaseService;

import java.util.List;

public interface MddChatService extends BaseService {

    List<MddChat> list(Object myTaskId);
}