package com.peng.mdd.service;

import com.peng.mdd.model.MddMyTask;
import com.peng.service.BaseService;

import java.util.List;

public interface MddMyTaskService extends BaseService {

    MddMyTask findByTaskIdWithUid(Object taskId, Object uid);

    List<MddMyTask> findByTaskId(Object taskId);
}