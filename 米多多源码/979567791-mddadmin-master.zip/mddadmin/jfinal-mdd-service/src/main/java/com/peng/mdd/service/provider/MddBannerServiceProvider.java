package com.peng.mdd.service.provider;

import com.jfinal.plugin.activerecord.Page;
import com.peng.mdd.model.MddBanner;
import com.peng.mdd.service.MddBannerService;
import com.peng.service.provider.BaseServiceProvider;

import java.util.ArrayList;
import java.util.List;


public class MddBannerServiceProvider extends BaseServiceProvider<MddBanner> implements MddBannerService {


    @Override
    public List<MddBanner> list() {
        return DAO.find("select * from mdd_banner where is_enable = 1 order by sort");
    }

    @Override
    public Page<MddBanner> list(Integer pageNumber, Integer pageSize, Integer isEnable) {
        List<Object> para = new ArrayList<Object>();
        StringBuffer sql = new StringBuffer();
        sql.append("from mdd_banner where 1=1 ");
        if (isEnable != null){
            sql.append(" and is_enable = ?");
            para.add(isEnable);
        }
        return DAO.paginate(pageNumber,pageSize,"select * ",sql.toString(),para.toArray());
    }
}