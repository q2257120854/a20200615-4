package com.peng.mdd.service;

import com.jfinal.plugin.activerecord.Page;
import com.peng.mdd.model.MddNotice;
import com.peng.service.BaseService;

import java.util.List;

public interface MddNoticeService extends BaseService {

    List<MddNotice> list();

    Page<MddNotice> list(Integer pageNumber, Integer pageSize, String content);
}