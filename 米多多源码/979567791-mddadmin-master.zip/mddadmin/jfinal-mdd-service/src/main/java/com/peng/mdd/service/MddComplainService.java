package com.peng.mdd.service;

import com.jfinal.plugin.activerecord.Page;
import com.peng.mdd.model.MddComplain;
import com.peng.service.BaseService;

public interface MddComplainService extends BaseService {

    Page<MddComplain> list(Integer pageNumber, Integer pageSize, Long task_id, Long uid);
}