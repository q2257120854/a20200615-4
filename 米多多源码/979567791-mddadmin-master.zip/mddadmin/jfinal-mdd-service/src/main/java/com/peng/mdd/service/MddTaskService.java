package com.peng.mdd.service;

import com.jfinal.plugin.activerecord.Page;
import com.peng.mdd.model.MddMyTask;
import com.peng.mdd.model.MddTask;
import com.peng.mdd.model.MddUser;
import com.peng.service.BaseService;

public interface MddTaskService extends BaseService {

    Page<MddTask> list(Integer pageNumber, Integer pageSize, String name,Integer state,Long id);

    //Boolean top(MddUser user,MddTask task);

    MddTask findById(Object id);

    MddTask findByIdWithUid(Object id,Object uid);

    void finish(final MddUser user, final MddTask task, final MddMyTask mmt);

    Integer finishCountByTaskId(Long taskId);

    Integer unsubmitCountByTaskId(Long taskId);
}