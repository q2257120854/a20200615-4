package com.peng.mdd.service.provider;

import com.jfinal.plugin.activerecord.Page;
import com.peng.mdd.model.MddAppeal;
import com.peng.mdd.service.MddAppealService;
import com.peng.service.provider.BaseServiceProvider;

import java.util.ArrayList;
import java.util.List;


public class MddAppealServiceProvider extends BaseServiceProvider<MddAppeal> implements MddAppealService {

    @Override
    public Page<MddAppeal> list(Integer pageNumber, Integer pageSize,Long uid, Long task_id,Integer is_solve) {
        List<Object> para = new ArrayList<Object>();
        StringBuffer sql = new StringBuffer();
        sql.append("from mdd_appeal where 1=1 ");
        if (uid != null){
            sql.append(" and uid = ?");
            para.add(uid);
        }
        if (task_id != null){
            sql.append(" and task_id = ?");
            para.add(task_id);
        }
        if (is_solve != null){
            sql.append(" and is_solve = ?");
            para.add(is_solve);
        }
        return DAO.paginate(pageNumber,pageSize,"select * ",sql.toString(),para.toArray());
    }
}