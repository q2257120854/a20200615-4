package com.peng.mdd.service.provider;

import com.jfinal.plugin.activerecord.Page;
import com.peng.mdd.model.MddInviteCode;
import com.peng.mdd.service.MddInviteCodeService;
import com.peng.service.provider.BaseServiceProvider;

import java.util.ArrayList;
import java.util.List;


public class MddInviteCodeServiceProvider extends BaseServiceProvider<MddInviteCode> implements MddInviteCodeService {

    @Override
    public Page<MddInviteCode> list(Integer pageNumber, Integer pageSize,Integer is_use) {
        List<Object> para = new ArrayList<Object>();
        StringBuffer sql = new StringBuffer();
        sql.append("from mdd_invite_code where 1=1 ");
        if (is_use != null){
            sql.append(" and is_use = ?");
            para.add(is_use);
        }
        return DAO.paginate(pageNumber,pageSize,"select * ",sql.toString(),para.toArray());
    }

    @Override
    public MddInviteCode findByCode(String code) {
        return DAO.findFirst("select * from mdd_invite_code where code = ? limit 1",code);
    }
}