package com.peng.mdd.service;

import com.jfinal.plugin.activerecord.Page;
import com.peng.mdd.model.MddAccountDetail;
import com.peng.service.BaseService;

public interface MddAccountDetailService extends BaseService {


    Page<MddAccountDetail> pageByUid(Integer pageNumber,Integer pageSize,Long uid);
}