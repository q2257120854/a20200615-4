package com.peng.mdd.service;

import com.jfinal.plugin.activerecord.Page;
import com.peng.mdd.model.MddTaskType;
import com.peng.service.BaseService;

import java.util.List;

public interface MddTaskTypeService extends BaseService {

    List<MddTaskType> list();

    Page<MddTaskType> list(Integer pageNumber, Integer pageSize, String name);
}