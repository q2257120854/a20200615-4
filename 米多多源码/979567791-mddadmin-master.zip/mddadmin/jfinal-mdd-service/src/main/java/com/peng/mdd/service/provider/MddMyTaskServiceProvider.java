package com.peng.mdd.service.provider;

import com.peng.mdd.model.MddMyTask;
import com.peng.mdd.service.MddMyTaskService;
import com.peng.service.provider.BaseServiceProvider;

import java.util.List;


public class MddMyTaskServiceProvider extends BaseServiceProvider<MddMyTask> implements MddMyTaskService {

    @Override
    public MddMyTask findByTaskIdWithUid(Object taskId, Object uid) {
        MddMyTask myTask = MddMyTask.dao.findFirst("select * from mdd_my_task where task_id = ? and uid = ?",taskId,uid);
        return myTask;
    }

    @Override
    public List<MddMyTask> findByTaskId(Object taskId) {
        List<MddMyTask> list = MddMyTask.dao.find("select * from mdd_my_task where task_id = ? and (state = 1 or state = 2 or state = 3)",taskId);
        return list;
    }
}