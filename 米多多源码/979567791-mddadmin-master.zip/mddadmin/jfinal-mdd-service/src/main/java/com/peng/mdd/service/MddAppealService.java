package com.peng.mdd.service;

import com.jfinal.plugin.activerecord.Page;
import com.peng.mdd.model.MddAppeal;
import com.peng.service.BaseService;

public interface MddAppealService extends BaseService {

    Page<MddAppeal> list(Integer pageNumber, Integer pageSize, Long uid, Long task_id,Integer is_solve);
}