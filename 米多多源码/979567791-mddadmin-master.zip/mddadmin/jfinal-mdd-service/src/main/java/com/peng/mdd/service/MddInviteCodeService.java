package com.peng.mdd.service;

import com.jfinal.plugin.activerecord.Page;
import com.peng.mdd.model.MddInviteCode;
import com.peng.service.BaseService;

public interface MddInviteCodeService extends BaseService {

    Page<MddInviteCode> list(Integer pageNumber, Integer pageSize, Integer is_use);

    MddInviteCode findByCode(String code);
}