package com.peng.mdd.service.provider;

import com.jfinal.aop.Inject;
import com.jfinal.plugin.activerecord.Db;
import com.jfinal.plugin.activerecord.Page;
import com.jfinal.plugin.activerecord.Record;
import com.peng.config.Constants;
import com.peng.enums.GradeEnum;
import com.peng.mdd.model.MddAccountDetail;
import com.peng.mdd.model.MddUser;
import com.peng.mdd.service.MddConfigService;
import com.peng.mdd.service.MddUserService;
import com.peng.service.provider.BaseServiceProvider;
import com.peng.utils.MD5Helper;
import com.peng.utils.PushUtils;
import org.apache.commons.lang3.StringUtils;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;


public class MddUserServiceProvider extends BaseServiceProvider<MddUser> implements MddUserService {

    @Inject
    private MddConfigService mddConfigService;

    @Override
    public MddUser info(Long uid) {
        MddUser user = DAO.findFirst("select phone,name,mi_coin,id,income,earnest_money,credit_score,head_img,total_advance_money,grade,nickname from mdd_user where id = ?",uid);
        user.setHeadImg(Constants.QINIU_DOMAIN + user.getHeadImg());
        return user;
    }

    @Override
    public MddUser login(String phone, String pwd) {
        return DAO.findFirst("select * from mdd_user where phone = ? and pwd = ? and state = 1 limit 1", phone, MD5Helper.encoderByMD5Salt(pwd));
    }

    @Override
    public MddUser findByPhone(String phone) {
        return DAO.findFirst("select * from mdd_user where phone = ?",phone);
    }

    @Override
    public List<MddUser> listByPid(Long pid) {
        List<MddUser> list = DAO.find("select id,reg_time,head_img,nickname from mdd_user where pid = ?",pid);
        for (MddUser user : list) {
            user.setHeadImg(Constants.QINIU_DOMAIN + user.getHeadImg());
//            if (user.getPhone().length() == 11){
//                user.setPhone(user.getPhone().substring(0, 3) + "****" + user.getPhone().substring(7, user.getPhone().length()));
//            }
        }
        return list;
    }

    @Override
    public Page<MddUser> list(Integer pageNumber, Integer pageSize,Long id ,String phone,Integer state,Long pid) {
        List<Object> para = new ArrayList<>();
        StringBuffer sql = new StringBuffer();
        sql.append("from mdd_user where 1=1 ");
        if (id != null){
            sql.append(" and id = ?");
            para.add(id);
        }
        if (pid != null){
            sql.append(" and pid = ?");
            para.add(pid);
        }else {
            sql.append(" and pid is null");
        }
        if (StringUtils.isNotBlank(phone)){
            sql.append(" and phone like ?");
            para.add("%"+phone+"%");
        }
        if (state != null){
            sql.append(" and state = ?");
            para.add(state);
        }

        Page<MddUser> page = DAO.paginate(pageNumber,pageSize,"select * ",sql.toString(),para.toArray());

        for (MddUser user: page.getList()) {
            user.put("children",userTree(user.getId()));
            user.setHeadImg(Constants.QINIU_DOMAIN + user.getHeadImg());
        }

        return page;
    }

    private List<MddUser> userTree(Long pid){
        List<MddUser> list = DAO.find("select * from mdd_user where pid = ?",pid);
        for (MddUser user: list) {
            user.put("children",userTree(user.getId()));
            user.setHeadImg(Constants.QINIU_DOMAIN + user.getHeadImg());
        }
        return list;
    }

    @Override
    public MddUser searchCaptain(Long pid, Integer count) {
        count --;
        MddUser user = DAO.findById(pid);
        if (user == null || count == 0){
            return null;
        }
        if (user.getGrade().equals(GradeEnum.队长.getCode())){
            return user;
        }
        user = searchCaptain(user.getPid(),count);
        return user;
    }

    @Override
    public void upCaptain(Long pid, Integer count) {
        count --;
        MddUser user = DAO.findById(pid);
        if (user == null || count == 0){
            return;
        }
        if (user.getGrade().equals(GradeEnum.队长.getCode())){
            return;
        }
        Integer directCount = countByPid(user.getId());
        Integer allCount = countAllByPid(user.getId(),10,0);
        Integer directCount2 = Integer.valueOf(mddConfigService.getConfig("direct_count"));
        Integer allCount2 = Integer.valueOf(mddConfigService.getConfig("all_count"));
        if (directCount >= directCount2 && allCount >= allCount2){
            // 升级队长
            user.setGrade(2);
            user.update();
            PushUtils.push(user.getId().toString(), "恭喜升级队长", "恭喜您升级成为队长啦!!!");
            return;
        }
        upCaptain(user.getPid(),count);
        return;
    }

    @Override
    public Integer countByPid(Long pid) {
        Record result = Db.findFirst("select count(*) as count from mdd_user where pid = ?",pid);
        Integer count = result.getInt("count");

        return count;
    }

    @Override
    public Integer countAllByPid(Long pid, Integer count, Integer totalCount) {
        if (count == 0){
            return 0;
        }
        count --;
        List<MddUser> userList = DAO.find("select * from mdd_user where pid = ?",pid);
        if (userList.size() == 0){
            return 0;
        }
        totalCount = userList.size();
        for (MddUser user : userList) {
            if (user.getGrade().equals(1)){
                totalCount = totalCount + countAllByPid(user.getId(),count,totalCount);
            }
        }
        return totalCount;
    }

    @Override
    public void income(MddUser user, Float money, String op) {
        user.setIncome(user.getIncome() + money);
        user.update();

        //添加账户明细
        MddAccountDetail mad2 = new MddAccountDetail();
        mad2.setMoney(money);
        mad2.setOp(op);
        mad2.setUid(user.getId());
        mad2.save();
    }

    @Override
    public void micoin(MddUser user, Float money, String op) {
        user.setMiCoin(new BigDecimal(user.getMiCoin()).add(new BigDecimal(money)).setScale(2, BigDecimal.ROUND_HALF_UP).floatValue());
        user.update();

        //添加账户明细
        MddAccountDetail mad2 = new MddAccountDetail();
        mad2.setMoney(new BigDecimal(money).setScale(2, BigDecimal.ROUND_HALF_UP).floatValue());
        mad2.setOp(op);
        mad2.setUid(user.getId());
        mad2.save();
    }
}