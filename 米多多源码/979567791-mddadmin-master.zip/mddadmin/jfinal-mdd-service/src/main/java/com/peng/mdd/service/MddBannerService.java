package com.peng.mdd.service;

import com.jfinal.plugin.activerecord.Page;
import com.peng.mdd.model.MddBanner;
import com.peng.service.BaseService;

import java.util.List;

public interface MddBannerService extends BaseService {

    List<MddBanner> list();

    Page<MddBanner> list(Integer pageNumber, Integer pageSize, Integer isEnable);
}