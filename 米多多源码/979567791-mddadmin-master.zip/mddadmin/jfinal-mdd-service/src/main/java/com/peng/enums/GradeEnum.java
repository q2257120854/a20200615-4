package com.peng.enums;

/**
 * 服务器返回码枚举
 * @author wupeng
 *
 */
public enum GradeEnum {
	会员(1,"会员"),
	队长(2,"队长"),

	;

	private int code;
	private String msg;


	private GradeEnum(int code, String msg) {
		this.code = code;
		this.msg = msg;
	}

	public String getMsg() {
		return this.msg;
	}

	public int getCode() {
		return this.code;
	}
}
