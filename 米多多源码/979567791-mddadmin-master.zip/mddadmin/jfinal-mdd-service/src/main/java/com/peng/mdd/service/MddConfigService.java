package com.peng.mdd.service;

import com.jfinal.plugin.activerecord.Page;
import com.peng.mdd.model.MddConfig;
import com.peng.service.BaseService;

public interface MddConfigService extends BaseService {

    Page<MddConfig> list(Integer pageNumber, Integer pageSize, String mc_desc);

    String getConfig(String key);
}