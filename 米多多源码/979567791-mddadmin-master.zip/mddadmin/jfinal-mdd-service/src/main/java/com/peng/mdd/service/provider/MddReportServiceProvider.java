package com.peng.mdd.service.provider;

import com.jfinal.plugin.activerecord.Page;
import com.peng.mdd.model.MddReport;
import com.peng.mdd.service.MddReportService;
import com.peng.service.provider.BaseServiceProvider;

import java.util.ArrayList;
import java.util.List;


public class MddReportServiceProvider extends BaseServiceProvider<MddReport> implements MddReportService {

    @Override
    public Page<MddReport> list(Integer pageNumber, Integer pageSize,Long uid, Long task_id) {
        List<Object> para = new ArrayList<Object>();
        StringBuffer sql = new StringBuffer();
        sql.append("from mdd_report where 1=1 ");
        if (uid != null){
            sql.append(" and uid = ?");
            para.add(uid);
        }
        if (task_id != null){
            sql.append(" and task_id = ?");
            para.add(task_id);
        }
        return DAO.paginate(pageNumber,pageSize,"select * ",sql.toString(),para.toArray());
    }
}