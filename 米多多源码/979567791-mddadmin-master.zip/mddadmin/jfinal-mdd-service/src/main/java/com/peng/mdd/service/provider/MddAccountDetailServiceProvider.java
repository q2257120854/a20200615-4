package com.peng.mdd.service.provider;

import com.jfinal.plugin.activerecord.Page;
import com.peng.mdd.model.MddAccountDetail;
import com.peng.mdd.service.MddAccountDetailService;
import com.peng.service.provider.BaseServiceProvider;


public class MddAccountDetailServiceProvider extends BaseServiceProvider<MddAccountDetail> implements MddAccountDetailService {

    @Override
    public Page<MddAccountDetail> pageByUid(Integer pageNumber,Integer pageSize,Long uid) {
        Page<MddAccountDetail> page = DAO.paginate(pageNumber, pageSize, "select *","from mdd_account_detail where uid = ? order by add_time desc",uid);
        return page;
    }
}