package com.peng.mdd.service.provider;

import com.jfinal.plugin.activerecord.Page;
import com.peng.mdd.model.MddTaskType;
import com.peng.mdd.service.MddTaskTypeService;
import com.peng.service.provider.BaseServiceProvider;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.List;


public class MddTaskTypeServiceProvider extends BaseServiceProvider<MddTaskType> implements MddTaskTypeService {


    @Override
    public List<MddTaskType> list() {
        return DAO.find("select id,name,service_charge,min_price,min_count from mdd_task_type");
    }

    @Override
    public Page<MddTaskType> list(Integer pageNumber, Integer pageSize, String name) {
        List<Object> para = new ArrayList<Object>();
        StringBuffer sql = new StringBuffer();
        sql.append("from mdd_task_type where 1=1 ");
        if (StringUtils.isNotBlank(name)){
            sql.append(" and name like ?");
            para.add("%"+name+"%");
        }
        return DAO.paginate(pageNumber,pageSize,"select * ",sql.toString(),para.toArray());
    }
}