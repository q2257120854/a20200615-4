package com.peng.utils;

import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

public class HttpUtils {
	public static String post(HttpPost httpPost) throws Exception {
		String ss = new String();   
		CloseableHttpClient httpclient = HttpClients.createDefault();
	    try {

	        
	        CloseableHttpResponse response = httpclient.execute(httpPost);

	        try {
	            //logger.info(response.getStatusLine());
	            HttpEntity entity = response.getEntity();
	            // do something useful with the response body
	            InputStream in = entity.getContent();
	            
	            InputStreamReader inputStreamReader = new InputStreamReader(in);   
	            
	            BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
	            
	            String s;   
	            while((s = bufferedReader.readLine())!=null){   
	                    ss += s;   
	            }
	            
	            //logger.info(ss);
	            
	            // and ensure it is fully consumed
	            EntityUtils.consume(entity);
	        } finally {
	            response.close();
	        }
	    } finally {
	        httpclient.close();
	    }
		return ss;
	
	}
	
	public static String get(HttpGet httpGet) throws Exception {
		String ss = new String();   
		CloseableHttpClient httpclient = HttpClients.createDefault();
	    try {

	        
	        CloseableHttpResponse response = httpclient.execute(httpGet);

	        try {
	            //logger.info(response.getStatusLine());
	            HttpEntity entity = response.getEntity();
	            // do something useful with the response body
	            InputStream in = entity.getContent();
	            
	            InputStreamReader inputStreamReader = new InputStreamReader(in);   
	            
	            BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
	            
	            String s;   
	            while((s = bufferedReader.readLine())!=null){   
	                    ss += s;   
	            }
	            
	            //logger.info(ss);
	            
	            // and ensure it is fully consumed
	            EntityUtils.consume(entity);
	        } finally {
	            response.close();
	        }
	    } finally {
	        httpclient.close();
	    }
		return ss;
	
	}
}
