package com.peng.controller;

import com.jfinal.aop.Inject;
import com.peng.enums.ReturnCodeEnum;
import com.peng.mdd.model.MddBanner;
import com.peng.mdd.service.MddBannerService;

import java.util.List;


public class BannerController extends BaseController {
	
	//private final static Logger logger = LoggerFactory.getLogger(BannerController.class);
    @Inject
	private MddBannerService bannerService;
	
	public void list() throws Exception {
		
		List<MddBanner> list = bannerService.list();
		
		if (list.isEmpty()) {
			renderInfo(ReturnCodeEnum.数据为空);
			return;
		}
		
		renderList(list);
	}

}
