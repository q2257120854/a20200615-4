package com.peng.controller;

import com.jfinal.aop.Inject;
import com.jfinal.plugin.activerecord.Db;
import com.peng.config.Constants;
import com.peng.enums.AccountDetailEnum;
import com.peng.enums.MyPublishEnum;
import com.peng.enums.ReturnCodeEnum;
import com.peng.mdd.model.*;
import com.peng.mdd.service.MddUserService;
import org.apache.commons.lang3.time.DateUtils;

import java.util.*;


public class StoreController extends BaseController {
	
	//private final static Logger logger = LoggerFactory.getLogger(BannerController.class);

    @Inject
    private MddUserService userService;

    /**
     * 关注
     */
	public void follow() {
		Long uid = getUserId();
		Long followUid = getParaToLong("uid");

        if (followUid == null){
            renderFault();
            return;
        }

        if (uid.equals(followUid)){
            renderInfo(ReturnCodeEnum.不能关注自己);
            return;
        }

        MddFollow follow = MddFollow.dao.findFirst("select * from mdd_follow where uid = ? and follow_uid = ?",uid,followUid);

        if (follow != null){
            renderInfo(ReturnCodeEnum.用户已关注);
            return;
        }
        follow = new MddFollow();
        follow.setUid(uid);
        follow.setFollowUid(followUid);
        follow.save();
        renderSuccess();
	}

    /**
     * 取消关注
     */
    public void cancelfollow() {
        Long uid = getUserId();
        Long followUid = getParaToLong("uid");

        if (followUid == null){
            renderFault();
            return;
        }

        MddFollow follow = MddFollow.dao.findFirst("select * from mdd_follow where uid = ? and follow_uid = ?",uid,followUid);

        if (follow == null){
            renderInfo(ReturnCodeEnum.请先关注);
            return;
        }
        follow.delete();
        renderSuccess();
    }

    /**
     * 置顶店铺
     */
    public void top() {
        // 周期:1=30元/小时,2=288/天,3=1588/一周,4=4888/月
        Integer cycle = getParaToInt("cycle");
        Integer cycle_count = getParaToInt("cycle_count");

        Float money = 0f;
        Integer hour = 0;
        switch (cycle){
            case 1:
               money = 30f * cycle_count;
               hour = cycle_count;
               break;
            case 2:
               money = 12f * 24 * cycle_count;
               hour = 24 * cycle_count;
               break;
            case 3:
               money = 9.45f * 24 * 7 * cycle_count;
               hour = 24 * 7 * cycle_count;
               break;
            case 4:
               money = 6.78f * 24 * 7 * 30 * cycle_count;
               hour = 24 * 7 * 30 * cycle_count;
               break;
        }

        MddUser user = MddUser.dao.findById(getUserId());

        if (user.getMiCoin() < money){
            renderInfo(ReturnCodeEnum.余额不足);
            return;
        }

        Date nowDate = new Date();
        Date topDate = DateUtils.addHours(nowDate,hour);
        if (user.getTopExpireTime() != null && user.getTopExpireTime().getTime() > nowDate.getTime()){
            topDate = DateUtils.addHours(user.getTopExpireTime(),hour);
        }
        user.setTopExpireTime(topDate);
        user.setMiCoin(user.getMiCoin() - money);
        user.update();

        //添加账户明细
        MddAccountDetail mad = new MddAccountDetail();
        mad.setMoney(- money);
        mad.setOp(AccountDetailEnum.置顶店铺.getMsg());
        mad.setUid(user.getId());
        mad.save();
        renderSuccess();
    }

    /**
     * 置顶店铺列表
     */
    public void toplist() {

        List<MddUser> list = MddUser.dao.find("select head_img,nickname,id from mdd_user where top_expire_time > now()");
        for (MddUser user : list) {
            user.setHeadImg(Constants.QINIU_DOMAIN + user.getHeadImg());
//            if (user.getPhone().length() == 11){
//                user.setPhone(user.getPhone().substring(0, 3) + "****" + user.getPhone().substring(7, user.getPhone().length()));
//            }
        }
        renderObject(list);
    }

    /**
     * 店铺主页
     */
    public void home() {
        Long userId = getParaToLong("uid");
        if (userId == null){
            userId = getUserId();
        }

        List<Object> para = new ArrayList<>();
        String sql = "select a.id,a.title,a.price,b.name as task_type,b.icon,(a.total_count - ( SELECT count(*) AS count FROM mdd_my_task WHERE task_id = a.id)) AS residue_count from mdd_task a left join mdd_task_type b on a.task_type_id = b.id where a.state = ? and a.uid = ? order by a.add_time desc";
        para.add(MyPublishEnum.进行中.getCode());
        para.add(userId);

        List<MddTask> proceedList = MddTask.dao.find(sql,para.toArray());

        para.clear();
        para.add(MyPublishEnum.已结束.getCode());
        para.add(userId);
        List<MddTask> finishList = MddTask.dao.find(sql,para.toArray());

        Map<Object,Object> map = new HashMap<>();
        map.put("proceedList",proceedList);
        map.put("finishList",finishList);


        // 发任务 总发单
        map.putAll(Db.findFirst("select count(*) as task_count,COALESCE(sum(total_count),0) as total_count from mdd_task where uid = ? and (state = 3 or state = 4 or state = 5)",userId).getColumns());
        // 总成交
        map.putAll(Db.findFirst("select sum(finish_count) as finish_count from (select ( SELECT count(*) AS finish_count FROM mdd_my_task WHERE task_id = a.id AND state = 4) AS finish_count from mdd_task a where uid = ?) a",userId).getColumns());

        // 投诉
        map.putAll(Db.findFirst("select count(*) as complain_count from mdd_complain a left join mdd_task b on a.task_id = b.id where a.uid = ?",userId).getColumns());
        // 被投诉
        map.putAll(Db.findFirst("select count(*) as complain_by_count from mdd_complain where uid = ?",userId).getColumns());

        // 被举报
        map.putAll(Db.findFirst("select count(*) as report_by_count from mdd_report a left join mdd_task b on a.task_id = b.id where b.uid = ?",userId).getColumns());
        // 举报
        map.putAll(Db.findFirst("select count(*) as report_count from mdd_report where uid = ?",userId).getColumns());

        // 被申诉
        map.putAll(Db.findFirst("select count(*) as appeal_by_count from mdd_appeal a left join mdd_task b on a.task_id = b.id where b.uid = ?",userId).getColumns());
        // 申诉
        map.putAll(Db.findFirst("select count(*) as appeal_count from mdd_appeal where uid = ?",userId).getColumns());

        // 接任务数量
        map.putAll(Db.findFirst("select count(*) as take_count from mdd_my_task where uid = ? and state = 4",userId).getColumns());

        MddUser user = userService.info(userId);
        map.put("user",user);

        boolean is_follow = false;
        MddFollow follow = MddFollow.dao.findFirst("select * from mdd_follow where uid = ? and follow_uid = ?",getUserId(),userId);
        if (follow != null){
            is_follow = true;
        }
        map.put("is_follow", is_follow);

        renderObject(map);
    }


}
