package com.peng.controller;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.jfinal.aop.Inject;
import com.jfinal.core.ActionKey;
import com.jfinal.plugin.activerecord.Db;
import com.jfinal.plugin.activerecord.IAtom;
import com.jfinal.plugin.activerecord.Page;
import com.peng.config.Constants;
import com.peng.config.DataSource;
import com.peng.enums.AccountDetailEnum;
import com.peng.enums.MyPublishEnum;
import com.peng.enums.MyTaskEnum;
import com.peng.enums.ReturnCodeEnum;
import com.peng.mdd.model.*;
import com.peng.mdd.service.*;
import com.peng.utils.PushUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.*;
public class TaskController extends BaseController {
	
	private final static Logger logger = LoggerFactory.getLogger(TaskController.class);

	@Inject
	private MddNoticeService noticeService;
    @Inject
    private MddTaskService taskService;
	@Inject
	private MddTaskTypeService taskTypeService;
	@Inject
	private MddUserService userService;
    @Inject
    private MddConfigService configService;
    @Inject
    private MddAccountDetailService accountDetailService;
    @Inject
    private MddChatService chatService;
    @Inject
    private MddMyTaskService myTaskService;
	
	/**
	 * 任务类型列表
	 */
	@ActionKey("task/type/list")
	public void typeList() {
		List<MddTaskType> list = taskTypeService.list();
		
		if (list.isEmpty()) {
			renderInfo(ReturnCodeEnum.数据为空);
			return;
		}
		
		renderList(list);
	}
	
	/**
	 * 发布任务
	 */
	public void publish(){



		Long userId = getUserId();
		
		MddUser user = (MddUser) userService.findById(userId);
		if (user == null) {
			renderInfo(ReturnCodeEnum.找不到用户);
			return;
		}
		
		//支付密码是否正确
//		String pay_pwd = getPara("pay_pwd");
//		if (user.getPayPwd() == null || !user.getPayPwd().equals(MD5Helper.encoderByMD5Salt(pay_pwd))) {
//			renderInfo(ReturnCodeEnum.支付密码错误);
//			return;
//		}
		
		Map<String, ReturnCodeEnum> map = new HashMap<>();
		
		Db.use().tx(new IAtom() {
			
			@Override
			public boolean run() throws SQLException {
				
				//价格
				Float price = 1f;
				try {
					price = Float.valueOf(getPara("price"));
				} catch (NumberFormatException e) {
					logger.error("价格格式化错误");
					//renderFault();
					map.put("info", ReturnCodeEnum.操作失败);
					return false;
				}
				
				//总数
				Integer totalCount = 1;
				try {
					totalCount = Integer.valueOf(getPara("total_count"));
				} catch (NumberFormatException e) {
					logger.error("总数格式化错误");
					//renderFault();
					map.put("info", ReturnCodeEnum.操作失败);
					return false;
				}
				
				//任务类型
				String type = getPara("type");
				MddTaskType taskType = MddTaskType.dao.findById(type);
				//判断类型是否正确
				if (taskType == null) {
					//renderFault();
					map.put("info", ReturnCodeEnum.操作失败);
					return false;
				}

                if (taskType.getMinCount() > totalCount) {
                    map.put("info", ReturnCodeEnum.操作失败);
                    return false;
                }

                if (taskType.getMinPrice() > price) {
                    map.put("info", ReturnCodeEnum.操作失败);
                    return false;
                }

                Integer orderTimeLimit = null;
                Integer checkTimeLimit = null;
                if ("cd".equals(taskType.getAlias())) {
                    orderTimeLimit = getParaToInt("order_time_limit");
                    checkTimeLimit = getParaToInt("check_time_limit");
                }

                //TODO 保证金判断,可能改为人口审核更好
                if (user.getEarnestMoney() < taskType.getEarnestMoney()){
                    ReturnCodeEnum returnCodeEnum = ReturnCodeEnum.保证金不足;
                    returnCodeEnum.setMsg("保证金不足,需要缴纳"+taskType.getEarnestMoney().intValue()+"元保证金");
                    map.put("info", returnCodeEnum);
                    return false;
                }
				
				//标题
				//TODO 标题文字验证处理
				String title = getPara("title");
                title = title.replace(" ","");

				//扣除服务费，在任务列表中显示的价格
				// price = price - (price * taskType.getServiceCharge());
				
				//支持设备
				Integer device = 1;
				try {
					device = Integer.valueOf(getPara("device"));
				} catch (NumberFormatException e) {
					logger.error("设备格式化错误");
					//renderFault();
					map.put("info", ReturnCodeEnum.操作失败);
					return false;
				}
					
				//截止日期
				String end_time = getPara("end_time");
				Date endTime = null;
				try {
					endTime = DateUtils.parseDate(end_time, "yyyy-MM-dd HH:mm");
				} catch (ParseException e) {
					logger.error("日期格式不正确，解析失败");
					//renderFault();
					map.put("info", ReturnCodeEnum.操作失败);
					return false;
				}
				//截止时间不能小于当前时间
				if (endTime.getTime() <= new Date().getTime()) {
					map.put("info", ReturnCodeEnum.截止时间不能小于当前时间);
					return false;
				}
                if (DateUtils.addHours(new Date(),24).getTime() > endTime.getTime()) {
                    map.put("info", ReturnCodeEnum.任务截止时间不能小于审核限时);
                    return false;
                }
//				if (endTime == null) {
//					//默认当前日期加3天
//					endTime = DateUtils.addDays(new Date(), 3);
//				}
				
				
				//说明图
				String explain_img = getPara("explain_img_json");
				if (StringUtils.isBlank(explain_img)) {
					//renderFault();
					map.put("info", ReturnCodeEnum.操作失败);
					return false;
				}
                String[] explain_img_arr = explain_img.split(",");
                if (explain_img_arr.length > 5){
                    map.put("info", ReturnCodeEnum.最多只能上传5张照片);
                    return false;
                }

				//操作步骤
				String step_json = getPara("step_json");
				//链接
				String url = getPara("url");
				//备注
				String remark = getPara("remark");
				
				//文字验证
				String wordVerify = getPara("word_verify");
				
				Long taskId = getParaToLong("task_id");
                MddTask task = MddTask.dao.findById(taskId);
                if (task == null){
                    task = new MddTask();
                }

                if (task.getState() != null && MyPublishEnum.已结束.getCode() == task.getState()){
                    map.put("info", ReturnCodeEnum.操作失败);
                    return false;
                }

                // 未通过的任务不需要再次扣钱
                if (task.getState() == null || MyPublishEnum.未通过.getCode() != task.getState()){
                    //判断账户余额是否充足
                    Float totalMoney = price * totalCount;
                    totalMoney = totalMoney + totalMoney * taskType.getServiceCharge();
                    if (user.getMiCoin() < totalMoney) {
                        map.put("info", ReturnCodeEnum.余额不足);
                        return false;
                    }

                    //扣除米币
                    userService.micoin(user,-totalMoney,AccountDetailEnum.发布任务.getMsg()+title);
                }

				task.setTaskTypeId(taskType.getId());
				task.setDevice(device);
				task.setTitle(title);
				task.setEndTime(endTime);
				task.setPrice(price);
                task.setServiceCharge(taskType.getServiceCharge());
				task.setTotalCount(totalCount);
				task.setExplainImg(explain_img);
				task.setUrl(url);
				task.setRemark(remark);
				task.setUid(user.getId());
				task.setState(MyPublishEnum.待审核.getCode());
				task.setBalance(price * totalCount);
				task.setWordVerify(wordVerify);
                if (orderTimeLimit != null && checkTimeLimit != null){
                    if (DateUtils.addHours(new Date(),checkTimeLimit).getTime() > endTime.getTime()) {
                        map.put("info", ReturnCodeEnum.任务截止时间不能小于审核限时);
                        return false;
                    }
                    task.setOrderTimeLimit(orderTimeLimit);
                    task.setCheckTimeLimit(checkTimeLimit);
                }
                if (task.getId() == null){
                    task.save();
                }else{
                    task.update();
                }
				
				if (StringUtils.isNotBlank(step_json)) {
					JSONArray stepArray = JSONArray.parseArray(step_json);
					if (stepArray != null) {
                        if (stepArray.size() > 10){
                            map.put("info", ReturnCodeEnum.最多只有10条操作步骤);
                            return false;
                        }
                        Db.update("delete from mdd_task_step where task_id = ?",task.getId());
						for (int i = 0; i < stepArray.size(); i++) {
							JSONObject obj = (JSONObject) stepArray.get(i);
							String desc = obj.getString("description");
							String step_explain_img = obj.getString("explain_img");

							MddTaskStep taskStep = new MddTaskStep();
							taskStep.setSort(i+1);
							taskStep.setTaskId(task.getId());
							taskStep.setDescription(desc);
                            taskStep.setExplainImg(step_explain_img);
							taskStep.save();
						}
					}
				}
				
				map.put("info", ReturnCodeEnum.请求成功);
				return true;
			}
		});
		
		
		
		renderInfo(map.get("info"));
	}

	
	/**
	 * 任务列表
	 */
	public void list() {

        Long userId = getUserId();
        String taskId = getPara("task_id");
        String title = getPara("title");
		String typeId = getPara("type_id");
        Integer device = getParaToInt("device");
		Integer pageNumber = getParaToInt("pageNumber") == null?1:getParaToInt("pageNumber");
		Integer pageSize = getParaToInt("pageSize") == null?30:getParaToInt("pageSize");
		
		StringBuffer totalRowSql = new StringBuffer();
		List<Object> para = new ArrayList<>();
        totalRowSql.append(" from mdd_task a left join mdd_task_type b on a.task_type_id = b.id left join mdd_user c on a.uid = c.id where a.state = ? and del_state = 0 and a.id not in(select task_id from mdd_my_task where uid = ?) and end_time > now()");
		para.add(MyPublishEnum.进行中.getCode());
        para.add(userId);
		if (StringUtils.isNotBlank(typeId)) {
            totalRowSql.append(" and a.task_type_id = ?");
			para.add(typeId);
		}
        if (device != null) {
            totalRowSql.append(" and a.device = ?");
            para.add(device);
        }
        if (StringUtils.isNotBlank(taskId)) {
            totalRowSql.append(" and a.id = ?");
            para.add(Long.valueOf(taskId));
        }
        if (StringUtils.isNotBlank(title)) {
            totalRowSql.append(" and a.title like ?");
            para.add("%"+title+"%");
        }

        StringBuffer findSql = new StringBuffer(totalRowSql);
        findSql.append(" order by (Case When a.top_expire_time > now() Then a.top_expire_time Else a.add_time End) desc");

        findSql.insert(0,"select a.id,a.title,a.price,b.name as task_type,b.icon,a.top_expire_time,add_time,c.earnest_money,a.device");
        totalRowSql.insert(0,"select count(*)");



        Page<MddTask> page = MddTask.dao.paginateByFullSql(pageNumber, pageSize,totalRowSql.toString(),findSql.toString(),para.toArray());

        for (MddTask task: page.getList()) {
            if (task.getTopExpireTime() != null && task.getTopExpireTime().getTime() > new Date().getTime()){
                task.setIsTop(1);
            }else {
                task.setIsTop(0);
            }
            if (task.getFloat("earnest_money") >= 1000){
                task.put("is_earnest_money",1);
            }else {
                task.put("is_earnest_money",0);
            }
        }

        renderList(page.getList());
	}
	
	/**
	 * 开始任务
	 */
	public void begin() {
        Long userId = getUserId();
		
		//检查是否通过认证
		MddUser user = (MddUser) userService.findById(userId);
		if (user == null) {
			renderInfo(ReturnCodeEnum.找不到用户);
			return;
		}
		
//		if (user.getAuthState() == null || user.getAuthState() != UserAuthEnum.已认证.getCode()) {
//			renderInfo(ReturnCodeEnum.未认证);
//			return;
//		}
		
		
		String taskId = getPara("task_id");
		
		//判断任务是否正常
		MddTask task = MddTask.dao.findById(taskId);
		if (task == null) {
			renderInfo(ReturnCodeEnum.找不到任务);
			return;
		}
		
		if (task.getState() != MyPublishEnum.进行中.getCode()) {
			renderInfo(ReturnCodeEnum.任务状态异常);
			return;
		}

        if (task.getEndTime().getTime() < System.currentTimeMillis()) {
            renderInfo(ReturnCodeEnum.任务状态异常);
            return;
        }
		
		if (task.getUid().equals(userId)) {
			renderInfo(ReturnCodeEnum.不能接自己的任务);
			return;
		}
		
		MddMyTask mmt = myTaskService.findByTaskIdWithUid(task.getId(),userId);
		
		if (mmt != null) {
			renderInfo(ReturnCodeEnum.不能重复接单哦);
			return;
		}

		//任务是否接满
        Integer finishCount = taskService.finishCountByTaskId(task.getId());
		if (finishCount >= task.getTotalCount()) {
			renderInfo(ReturnCodeEnum.任务已完成);
			return;
		}
		
		Db.tx(new IAtom() {
			
			@Override
			public boolean run() throws SQLException {
				MddMyTask mmt = new MddMyTask();
				mmt.setState(MyTaskEnum.待提交.getCode());
				mmt.setUid(userId);
				mmt.setTaskId(task.getId());
				mmt.save();
				
				//未提交数量加1
				//task.setUnsubmitCount(task.getUnsubmitCount()+1);
				//task.update();

				//任务是否接满
				Integer finishCount = taskService.finishCountByTaskId(task.getId());
				if (finishCount > task.getTotalCount()) {
					return false;
				}
				
				return true;
			}
		});
		
		
		renderSuccess();
	}
	
	/**
	 * 提交任务
	 */
	public void submit() {
        Long userId = getUserId();
		
		String taskId = getPara("task_id");
        String wordVerify = getPara("word_verify");
		//判断任务是否正常
		MddTask task = MddTask.dao.findById(taskId);
		if (task == null) {
			renderInfo(ReturnCodeEnum.找不到任务);
			return;
		}
		
		if (!(task.getState() == MyPublishEnum.进行中.getCode() || task.getState() == MyPublishEnum.已暂停.getCode())) {
			renderInfo(ReturnCodeEnum.任务状态异常);
			return;
		}
		
		if (task.getUid().equals(userId)) {
			renderInfo(ReturnCodeEnum.不能接自己的任务);
			return;
		}

		MddMyTask mmt = myTaskService.findByTaskIdWithUid(task.getId(),userId);
		if (mmt == null) {
			renderInfo(ReturnCodeEnum.请先接单后再提交);
			return;
		}
		if (mmt.getState() == MyTaskEnum.已完成.getCode() || mmt.getState() == MyTaskEnum.待审核.getCode()) {
			renderInfo(ReturnCodeEnum.任务状态异常);
			return;
		}

        if (StringUtils.isNotBlank(task.getWordVerify()) && StringUtils.isBlank(wordVerify)) {
            renderInfo(ReturnCodeEnum.文字验证不能为空);
            return;
        }
		
		//验证图
		String auth_img = getPara("auth_img");
        if (StringUtils.isBlank(auth_img)){
            renderInfo(ReturnCodeEnum.验证图不能为空);
            return;
        }

		// 发送推送通知
		String body = "任务名称:"+task.getTitle();
		PushUtils.push(task.getUid().toString(), "任务审核", body);

		Db.tx(new IAtom() {
			
			@Override
			public boolean run() throws SQLException {
                Db.update("delete from mdd_chat where mytask_id = ?",mmt.getId());

				mmt.setAuthImg(auth_img);
                if (StringUtils.isNotBlank(task.getWordVerify())) {
                    mmt.setWordVerify(wordVerify);
                }
				mmt.setState(MyTaskEnum.待审核.getCode());
				mmt.update();
				
				//未提交数量减1
				//task.setUnsubmitCount(task.getUnsubmitCount()-1);
				//提交数量加1
				//task.setSubmitCount(task.getSubmitCount()+1);
				//task.update();
				return true;
			}
		});
		
		
		renderSuccess();
		
	}
	
	/**
	 * 取消任务
	 */
	public void cancel() {
        Long userId = getUserId();
		
		renderNull();
		//String task_id = getPara("task_id");
	}

    /**
     * 删除任务
     */
    public void delete() {
        Long userId = getUserId();
        Long taskId = getParaToLong("task_id");

        //是否是这个人发布的任务
        MddTask task = taskService.findByIdWithUid(taskId,userId);
        if (task == null) {
            renderInfo(ReturnCodeEnum.找不到任务);
            return;
        }

        if (task.getState().equals(MyPublishEnum.进行中.getCode()) || task.getState().equals(MyPublishEnum.已暂停.getCode())) {
            renderInfo(ReturnCodeEnum.任务状态异常);
            return;
        }

        Db.use(DataSource.MDD).tx(new IAtom() {

            @Override
            public boolean run() throws SQLException {

                if (task.getState().equals(MyPublishEnum.待审核.getCode()) || task.getState().equals(MyPublishEnum.未通过.getCode())) {
                    //退回剩余的钱给发布者
                    MddUser user = MddUser.dao.findById(task.getUid());
                    userService.micoin(user,task.getBalance() + task.getBalance() * task.getServiceCharge(),AccountDetailEnum.任务退回.getMsg()+task.getTitle());

                    //修改任务状态
                    task.setState(MyPublishEnum.已结束.getCode());
                }

                task.setDelState(1);
                task.update();

                return true;
            }
        });
//        MddComplain complain = MddComplain.dao.findFirst("select * from mdd_complain where task_id = ?",taskId);
//        MddReport report = MddReport.dao.findFirst("select * from mdd_report where task_id = ?",taskId);
//        MddAppeal appeal = MddAppeal.dao.findFirst("select * from mdd_appeal where task_id = ?",taskId);
//        if (complain != null || report != null || appeal != null){
//            renderInfo(ReturnCodeEnum.有投诉未处理);
//            return;
//        }

        renderSuccess();
    }

    /**
     * 删除我的任务
     */
    public void deletemy() {
        Long userId = getUserId();
        Long taskId = getParaToLong("task_id");

        //是否是这个人接的任务
        MddMyTask myTask = myTaskService.findByTaskIdWithUid(taskId,userId);
        if (myTask == null) {
            renderInfo(ReturnCodeEnum.找不到任务);
            return;
        }

        if (myTask.getState() == MyTaskEnum.待审核.getCode() || myTask.getState() == MyTaskEnum.待提交.getCode()) {
            renderInfo(ReturnCodeEnum.任务状态异常);
            return;
        }

        Db.tx(new IAtom() {
            @Override
            public boolean run() throws SQLException {
                Db.update("delete from mdd_chat where mytask_id = ?",myTask.getId());
                myTask.delete();
                return true;
            }
        });


//        MddComplain complain = MddComplain.dao.findFirst("select * from mdd_complain where task_id = ?",taskId);
//        MddReport report = MddReport.dao.findFirst("select * from mdd_report where task_id = ?",taskId);
//        MddAppeal appeal = MddAppeal.dao.findFirst("select * from mdd_appeal where task_id = ?",taskId);
//        if (complain != null || report != null || appeal != null){
//            renderInfo(ReturnCodeEnum.有投诉未处理);
//            return;
//        }

        renderSuccess();
    }

	/**
	 * 我的任务
	 */
	public void my() {
        Long userId = getUserId();
		
		String state = getPara("state");
		
		Integer pageNumber = getParaToInt("pageNumber") == null?1:getParaToInt("pageNumber");
		Integer pageSize = getParaToInt("pageSize") == null?30:getParaToInt("pageSize");
		
		StringBuffer sql = new StringBuffer();
		sql.append("from mdd_my_task a left join mdd_task b on a.task_id = b.id left join mdd_task_type c on b.task_type_id = c.id where a.del_state = 0 and a.uid = ?");
		List<Object> para = new ArrayList<>();
		para.add(userId);
		if (StringUtils.isNotBlank(state)) {
			sql.append(" and a.state = ?");
			para.add(state);
		}
		sql.append(" order by a.add_time desc");
		Page<MddTask> page = MddTask.dao.paginate(pageNumber, pageSize, "select b.*,a.state,c.icon,c.name as task_type",sql.toString(),para.toArray());
		renderList(page.getList());
	}
	
	/**
	 * 任务详情
	 */
	public void detail() {

        Long userId = getUserId();
		boolean is_take = false;
        boolean is_follow = false;
		Integer state = 0;
		String rejectReason = "";
		
		String task_id = getPara("task_id");
		MddTask task = MddTask.dao.findFirst("select a.*,b.name as type_name,c.nickname from mdd_task a left join mdd_task_type b on a.task_type_id = b.id left join mdd_user c on a.uid = c.id where a.id = ?",task_id);
        if (task == null) {
			renderInfo(ReturnCodeEnum.找不到任务);
			return;
		}
        StringBuffer explainImgSb = new StringBuffer();
        String[] explainImgArr = task.getExplainImg().split(",");
        for (String img: explainImgArr) {
            explainImgSb.append(Constants.QINIU_DOMAIN).append(img).append(",");
        }
        explainImgSb.deleteCharAt(explainImgSb.length()-1);
        task.setExplainImg(explainImgSb.toString());

        MddFollow follow = MddFollow.dao.findFirst("select * from mdd_follow where uid = ? and follow_uid = ?",userId,task.getUid());
        if (follow != null){
            is_follow = true;
        }


        if (userId != null) {
            MddMyTask myTask = MddMyTask.dao.findFirst("select * from mdd_my_task where uid = ? and task_id = ?",userId,task.getId());
            if (myTask != null) {
                is_take = true;
                state = myTask.getState();
                rejectReason = myTask.getRejectReason();
            }
        }
		

		
		List<MddTaskStep> stepList =  MddTaskStep.dao.find("select * from mdd_task_step where task_id = ?",task.getId());
		for (MddTaskStep step: stepList) {
            if (StringUtils.isNotBlank(step.getExplainImg())) {
                step.setExplainImg(Constants.QINIU_DOMAIN + step.getExplainImg());
            }
		}
		task.put("step_list", stepList);
		task.put("is_take", is_take);
        task.put("is_follow", is_follow);
		task.put("state", state);
		task.put("reject_reason", rejectReason);
		
		renderObject(task);
	}
	
	/**
	 * 我的发布
	 */
	public void mypublish() {
		//判断用户是否登录
        Long userId = getUserId();
		
		String state = getPara("state");
		
		Integer pageNumber = getParaToInt("pageNumber") == null?1:getParaToInt("pageNumber");
		Integer pageSize = getParaToInt("pageSize") == null?30:getParaToInt("pageSize");
		
		String taskId = getPara(0);
        // 审核列表
		if (taskId != null) {
			//是否是这个人发布的任务
            MddTask task = taskService.findByIdWithUid(taskId,userId);
			if (task == null) {
				renderInfo(ReturnCodeEnum.找不到任务);
				return;
			}
			
			StringBuffer sql = new StringBuffer();
			sql.append("from mdd_my_task a left join mdd_user b on a.uid = b.id where a.task_id = ?");
			List<Object> para = new ArrayList<>();
			para.add(taskId);
            sql.append(" and a.state = 2");
			sql.append(" order by a.add_time desc");
			List<MddMyTask> list = MddMyTask.dao.find("select a.id,a.task_id,a.state,b.nickname,b.head_img,a.uid as user_id,a.auth_img,a.word_verify "+sql.toString(),para.toArray());
            for (MddMyTask mddMyTask: list) {
                mddMyTask.put("head_img",Constants.QINIU_DOMAIN + mddMyTask.get("head_img"));
                if (StringUtils.isNotBlank(mddMyTask.getAuthImg())) {
                    StringBuffer explainImgSb = new StringBuffer();
                    String[] explainImgArr = mddMyTask.getAuthImg().split(",");
                    for (String img: explainImgArr) {
                        explainImgSb.append(Constants.QINIU_DOMAIN+img+",");
                    }
                    explainImgSb.deleteCharAt(explainImgSb.length()-1);
                    mddMyTask.setAuthImg(explainImgSb.toString());
                }
                // 信息交流
                List<MddChat> chatList = chatService.list(mddMyTask.getId());
                mddMyTask.put("chatList",chatList);
            }
			renderList(list);
			return;
		}
		
		StringBuffer sql = new StringBuffer();
		sql.append("from mdd_task a left join mdd_task_type b on a.task_type_id = b.id where uid = ? and del_state = 0");
		List<Object> para = new ArrayList<>();
		para.add(userId);
		if (StringUtils.isNotBlank(state)) {
			sql.append(" and a.state = ?");
			para.add(state);
		}
		sql.append(" order by a.add_time desc");


        String select = ",( SELECT count(*) AS unsubmit_count FROM mdd_my_task WHERE task_id = a.id AND state = 1) AS unsubmit_count ,( SELECT count(*) AS submit_count FROM mdd_my_task WHERE task_id = a.id AND state = 2) AS submit_count ,( SELECT count(*) AS fail_count FROM mdd_my_task WHERE task_id = a.id AND state = 3) AS fail_count ,( SELECT count(*) AS finish_count FROM mdd_my_task WHERE task_id = a.id AND state = 4) AS finish_count";
		Page<MddTask> page = MddTask.dao.paginate(pageNumber, pageSize, "select a.*,b.name type_name,a.pause_count,a.end_time"+select,sql.toString(),para.toArray());
        for (MddTask task: page.getList()) {
            if (task.getEndTime().getTime() > System.currentTimeMillis()){
                task.put("is_end",0);
            }else {
                task.put("is_end",1);
            }
        }
        renderList(page.getList());
	}
	
	/**
	 * 任务审核
	 */
	public void check() {
		String taskId = getPara("task_id");
        Long userId = getUserId();
		
		//判断任务是否正常
		MddTask task = taskService.findById(taskId);
		if (task == null) {
			renderInfo(ReturnCodeEnum.找不到任务);
			return;
		}

		//任务状态正常
//		if (task.getState() == MyPublishEnum.进行中.getCode()) {
//			renderInfo(ReturnCodeEnum.任务状态异常);
//			return;
//		}
		
		//是否是这个人接的任务 并且任务状态正常
        MddMyTask mmt = myTaskService.findByTaskIdWithUid(taskId,userId);
		if (mmt == null) {
			renderInfo(ReturnCodeEnum.请先接单后再提交);
			return;
		}
        if (StringUtils.isNotBlank(mmt.getAuthImg())) {
            StringBuffer explainImgSb = new StringBuffer();
            String[] explainImgArr = mmt.getAuthImg().split(",");
            for (String img: explainImgArr) {
                explainImgSb.append(Constants.QINIU_DOMAIN+img+",");
            }
            explainImgSb.deleteCharAt(explainImgSb.length()-1);
            mmt.setAuthImg(explainImgSb.toString());
        }

        List<MddChat> chatList = chatService.list(mmt.getId());
        mmt.put("chatList",chatList);

		renderObject(mmt);
	}
	
	/**
	 * 通过审核
	 */
	public void finish() {
		String taskId = getPara("task_id");
		String user_id = getPara("user_id");
        Long userId = getUserId();

        MddUser user = (MddUser) userService.findById(user_id);
		if (user == null) {
			renderInfo(ReturnCodeEnum.找不到用户);
			return;
		}
		
		//是否是这个人发布的任务  并且任务状态正常
        MddTask task = taskService.findByIdWithUid(taskId,userId);
        if (task == null || !(task.getState() == MyPublishEnum.进行中.getCode() || task.getState() == MyPublishEnum.已暂停.getCode())) {
			renderInfo(ReturnCodeEnum.任务状态异常);
			return;
		}
		
		if (task.getUid().toString().equals(user_id)) {
			renderInfo(ReturnCodeEnum.不能接自己的任务);
			return;
		}
		
		//是否是这个人接的任务 并且任务状态正常
        MddMyTask mmt = myTaskService.findByTaskIdWithUid(taskId,user_id);
		if (mmt == null) {
			renderInfo(ReturnCodeEnum.请先接单后再提交);
			return;
		}
		if (mmt.getState() != MyTaskEnum.待审核.getCode()) {
			renderInfo(ReturnCodeEnum.任务状态异常);
			return;
		}

        taskService.finish(user, task, mmt);

        renderSuccess();
	}

    /**
	 * 不通过审核
	 */
	public void fail() {
		String taskId = getPara("task_id");
		String user_id = getPara("user_id");
		String rejectReason = getPara("reject_reason");
        String imgs = getPara("imgs");

        Long userId = getUserId();
		
		//是否是这个人发布的任务  并且任务状态正常
        MddTask task = taskService.findByIdWithUid(taskId,userId);
		if (task == null || !(task.getState() == MyPublishEnum.进行中.getCode() || task.getState() == MyPublishEnum.已暂停.getCode())) {
			renderInfo(ReturnCodeEnum.任务状态异常);
			return;
		}
		
		if (task.getUid().toString().equals(user_id)) {
			renderInfo(ReturnCodeEnum.不能接自己的任务);
			return;
		}
		
		//是否是这个人接的任务 并且任务状态正常
        MddMyTask mmt = myTaskService.findByTaskIdWithUid(taskId,user_id);
		if (mmt == null) {
			renderInfo(ReturnCodeEnum.请先接单后再提交);
			return;
		}
		if (mmt.getState() != MyTaskEnum.待审核.getCode()) {
			renderInfo(ReturnCodeEnum.任务状态异常);
			return;
		}

        // 发送推送通知
        String body = "任务名称:"+task.getTitle();
        PushUtils.push(user_id, "未通过审核", body);

        Db.tx(new IAtom() {
			
			@Override
			public boolean run() throws SQLException {
				//更新任务状态
				mmt.setState(MyTaskEnum.未通过.getCode());
				mmt.setRejectReason(rejectReason);
				mmt.update();

                //保存信息交流
                MddChat chat = new MddChat();
                chat.setDirection(0);
                chat.setContent(rejectReason);
                chat.setMytaskId(mmt.getId());
                chat.setImageList(imgs);
                chat.save();

                // 新增消息记录
                MddMessage msg = new MddMessage();
                msg.setTitle("任务处理通知");
                StringBuilder content = new StringBuilder("哎呦，你的任务审核未通过，请重新上传验证图吧！").append("<br/>");
                content.append("任务名称:").append(task.getTitle()).append("<br/>");
                content.append("拒绝原因:").append(rejectReason);
                msg.setContent(content.toString());
                msg.setUid(Long.valueOf(user_id));
                msg.save();
				return true;
			}
		});
		
		renderSuccess();
	}

    /**
     * 开启任务
     */
    public void open() {
        Long userId = getUserId();
        Long taskId = getParaToLong("task_id");

        //是否是这个人发布的任务
        MddTask task = taskService.findByIdWithUid(taskId,userId);
        if (task == null) {
            renderInfo(ReturnCodeEnum.找不到任务);
            return;
        }

        if (task.getEndTime().getTime() < System.currentTimeMillis()) {
            renderInfo(ReturnCodeEnum.任务状态异常);
            return;
        }

        task.setState(MyPublishEnum.进行中.getCode());
        task.update();
        renderSuccess();
    }

    /**
     * 下架任务
     */
    public void close() {
        Long userId = getUserId();
        Long taskId = getParaToLong("task_id");

        //是否是这个人发布的任务
        MddTask task = taskService.findByIdWithUid(taskId,userId);
        if (task == null) {
            renderInfo(ReturnCodeEnum.找不到任务);
            return;
        }

        //过期的任务可以直接下架
        if (task.getEndTime().getTime() > System.currentTimeMillis()){
            if (task.getState() != MyPublishEnum.已暂停.getCode()) {
                renderInfo(ReturnCodeEnum.请先暂停任务);
                return;
            }
        }

        // 有尚未提交审核的数据，暂时不能下架
        if (taskService.unsubmitCountByTaskId(task.getId()) > 0){
            renderInfo(ReturnCodeEnum.有尚未提交审核的数据);
            return;
        }

        // 进行中和未审核的任务都视为合格
        Db.tx(new IAtom() {
            @Override
            public boolean run() throws SQLException {
                List<MddMyTask> myTaskList = MddMyTask.dao.find("select a.* from mdd_my_task a left join mdd_task b on a.task_id = b.id where (a.state = 2 or a.state = 3) and task_id = ?", task.getId());
                for (final MddMyTask mytask : myTaskList) {
                    MddUser user = MddUser.dao.findById(mytask.getUid());
                    taskService.finish(user, task, mytask);
                }

                //退回剩余的钱给发布者
                MddUser user = MddUser.dao.findById(task.getUid());
                userService.micoin(user, task.getBalance(), AccountDetailEnum.任务退回.getMsg() + task.getTitle());

                //修改任务状态
                task.setState(MyPublishEnum.已结束.getCode());
                task.setCancelTime(new Date());
                task.update();

                return true;
            }
        });
        renderSuccess();
    }

    /**
     * 暂停任务
     */
    public void pause() {
        Long userId = getUserId();
        Long taskId = getParaToLong("task_id");

        //是否是这个人发布的任务
        MddTask task = taskService.findByIdWithUid(taskId,userId);
        if (task == null) {
            renderInfo(ReturnCodeEnum.找不到任务);
            return;
        }

        MddTaskType taskType = MddTaskType.dao.findById(task.getTaskTypeId());
        if ("cd".equals(taskType.getAlias())) {
            renderInfo(ReturnCodeEnum.长单任务不能暂停);
            return;
        }
        if (task.getPauseCount() >= 2){
            MddUser user = MddUser.dao.findById(userId);
            if (user.getMiCoin() < 2){
                renderInfo(ReturnCodeEnum.余额不足);
                return;
            }
        }

        Db.use(DataSource.MDD).tx(new IAtom() {
            @Override
            public boolean run() throws SQLException {
                if (task.getPauseCount() >= 2){
                    MddUser user = MddUser.dao.findById(userId);
                    if (user.getMiCoin() < 2){
                        return false;
                    }
                    userService.micoin(user,-2f,AccountDetailEnum.发布任务.getMsg()+task.getTitle());
                }

                task.setState(MyPublishEnum.已暂停.getCode());
                task.setPauseCount(task.getPauseCount() + 1);
                task.update();
                return true;
            }
        });
		renderSuccess();
    }

    /**
     * 上调价格
     */
    public void addprice() {
        Long userId = getUserId();
        Long taskId = getParaToLong("task_id");
        Float price = Float.valueOf(getPara("price"));

        //是否是这个人发布的任务
        MddTask task = taskService.findByIdWithUid(taskId,userId);
        if (task == null) {
            renderInfo(ReturnCodeEnum.找不到任务);
            return;
        }
        if (task.getState() != MyPublishEnum.已暂停.getCode()) {
            renderInfo(ReturnCodeEnum.请先暂停任务);
            return;
        }
        if (taskService.unsubmitCountByTaskId(task.getId()) > 0){
            renderInfo(ReturnCodeEnum.有尚未提交审核的数据);
            return;
        }

        if (price <= task.getPrice()){
            renderInfo(ReturnCodeEnum.金额必须大于当前单价);
            return;
        }

        //MddTaskType taskType = (MddTaskType) taskTypeService.findById(task.getTaskTypeId());

        Float priceDiff = price - task.getPrice();

        Integer finishCount = taskService.finishCountByTaskId(task.getId());
        BigDecimal totalMoney = new BigDecimal(priceDiff * (task.getTotalCount() - finishCount));

        BigDecimal balance =totalMoney.multiply(new BigDecimal(task.getServiceCharge())).add(totalMoney);
        MddUser user = MddUser.dao.findById(userId);

        if (user.getMiCoin() < balance.floatValue()){
            Map<String,Object> map = new HashMap<>();
            map.put("code", ReturnCodeEnum.余额不足.getCode());

            map.put("msg", ReturnCodeEnum.余额不足.getMsg()+"还差:"+ (balance.subtract(new BigDecimal(user.getMiCoin())).setScale(2, BigDecimal.ROUND_HALF_UP).floatValue()));
            renderJson(map);
            return;
        }
        task.setBalance(new BigDecimal(price * (task.getTotalCount() - finishCount)).setScale(2, BigDecimal.ROUND_HALF_UP).floatValue());
        task.setPrice(price);

        Db.use(DataSource.MDD).tx(new IAtom() {
            @Override
            public boolean run() throws SQLException {
                task.update();
                userService.micoin(user,-balance.floatValue(),AccountDetailEnum.上调价格.getMsg()+task.getTitle());
                return true;
            }
        });


		renderSuccess();
    }

    /**
     * 追加数量
     */
    public void addcount() {
        Long userId = getUserId();
        Long taskId = getParaToLong("task_id");
        Integer count = getParaToInt("count");

        //是否是这个人发布的任务
        MddTask task = taskService.findByIdWithUid(taskId,userId);
        if (task == null) {
            renderInfo(ReturnCodeEnum.找不到任务);
            return;
        }
        Integer finishCount = taskService.finishCountByTaskId(task.getId());

        // MddTaskType taskType = (MddTaskType) taskTypeService.findById(task.getTaskTypeId());

        BigDecimal totalMoney = new BigDecimal(count * task.getPrice());

        BigDecimal balance =totalMoney.multiply(new BigDecimal(task.getServiceCharge())).add(totalMoney);
        balance.setScale(2, BigDecimal.ROUND_HALF_UP);
        MddUser user = MddUser.dao.findById(userId);

        if (user.getMiCoin() < balance.floatValue()){
            Map<String,Object> map = new HashMap<>();
            map.put("code", ReturnCodeEnum.余额不足.getCode());

            map.put("msg", ReturnCodeEnum.余额不足.getMsg()+"还差:"+ (balance.subtract(new BigDecimal(user.getMiCoin())).setScale(2, BigDecimal.ROUND_HALF_UP).floatValue()));
            renderJson(map);
            return;
        }

        task.setTotalCount(task.getTotalCount() + count);
        task.setBalance(new BigDecimal(task.getPrice() * (task.getTotalCount() - finishCount)).setScale(2, BigDecimal.ROUND_HALF_UP).floatValue());

        Db.use(DataSource.MDD).tx(new IAtom() {
            @Override
            public boolean run() throws SQLException {
                task.update();
                userService.micoin(user,-balance.floatValue(),AccountDetailEnum.追加数量.getMsg()+task.getTitle());
                return true;
            }
        });


		renderSuccess();
    }

    /**
     * 置顶任务
     */
    public void top() {
        Long userId = getUserId();
        Long taskId = getParaToLong("task_id");
        Integer hour = getParaToInt("hour");

        MddUser user = (MddUser) userService.findById(userId);
        if (user == null) {
            renderInfo(ReturnCodeEnum.找不到用户);
            return;
        }

        //是否是这个人发布的任务
        MddTask task = taskService.findByIdWithUid(taskId,userId);
        if (task == null) {
            renderInfo(ReturnCodeEnum.找不到任务);
            return;
        }

        Integer hourPrice = Integer.valueOf(configService.getConfig(Constants.task_top_hour_price));

        //判断账户余额是否充足
        if (user.getMiCoin() < hourPrice*hour) {
            renderInfo(ReturnCodeEnum.余额不足);
            return;
        }
        Date nowDate = new Date();
        Date topDate = DateUtils.addHours(nowDate,hour);
        if (task.getTopExpireTime() != null && task.getTopExpireTime().getTime() > nowDate.getTime()){
            topDate = DateUtils.addHours(task.getTopExpireTime(),hour);
        }
        task.setTopExpireTime(topDate);

        Db.use(DataSource.MDD).tx(new IAtom() {
            @Override
            public boolean run() throws SQLException {
                user.update();
                task.update();
                userService.micoin(user,-new BigDecimal(hourPrice*hour).setScale(2, BigDecimal.ROUND_HALF_UP).floatValue(),AccountDetailEnum.置顶任务.getMsg()+task.getTitle());
                return true;
            }
        });



        renderSuccess();
    }

    /**
     * 留言
     */
    public void chat() {
        Long userId = getUserId();
        Long mytask_id = getParaToLong("mytask_id");
        String content = getPara("content");

        //是否是这个人接的任务
        MddMyTask mytask = MddMyTask.dao.findFirst("select * from mdd_my_task where id = ? and uid = ?",mytask_id,userId);
        if (mytask == null) {
            renderInfo(ReturnCodeEnum.找不到任务);
            return;
        }

        MddTask task = taskService.findById(mytask.getTaskId());

        if (task == null || !(task.getState() == MyPublishEnum.进行中.getCode() || task.getState() == MyPublishEnum.已暂停.getCode())) {
            renderInfo(ReturnCodeEnum.任务状态异常);
            return;
        }

        Db.tx(new IAtom() {

            @Override
            public boolean run() throws SQLException {

                MddChat chat = new MddChat();
                chat.setDirection(1);
                chat.setContent(content);
                chat.setMytaskId(mytask_id);
                chat.save();

                mytask.setState(MyTaskEnum.待审核.getCode());
                mytask.update();

                //未提交数量减1
                //task.setUnsubmitCount(task.getUnsubmitCount()-1);
                //提交数量加1
                //task.setSubmitCount(task.getSubmitCount()+1);
                //不合格数量减1
                //task.setFailCount(task.getFailCount()-1);
                //task.update();

                return true;
            }
        });

        renderSuccess();
    }

    public static void main(String[] args) {
//        Date date = DateUtils.addDays(new Date(),750);
//        System.out.print(DateFormatUtils.format(date,"yyyy-MM-dd"));
//        Integer a = 2;
//
//        System.out.print(MyPublishEnum.未通过.getCode().equals(a));
//
//        System.out.print(StringUtils.equals(String.valueOf(MyPublishEnum.未通过.getCode()),String.valueOf(a)));

        Integer a = new Integer(2);
        int b = 2;
        System.out.print(a.equals(b));
    }
}
