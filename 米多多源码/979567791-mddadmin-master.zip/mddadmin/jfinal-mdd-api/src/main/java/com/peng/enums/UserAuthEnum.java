package com.peng.enums;

/**
 * 服务器返回码枚举
 * @author wupeng
 *
 */
public enum UserAuthEnum {
	未认证(0,"未认证"),
	审核中(1,"审核中"),
	未通过(2,"未通过"),
	已认证(3,"已认证"),
	
	;
	
	private int code;
	private String msg;
	

	private UserAuthEnum(int code, String msg) {
		this.code = code;
		this.msg = msg;
	}

	public String getMsg() {
		return this.msg;
	}

	public int getCode() {
		return this.code;
	}
}
