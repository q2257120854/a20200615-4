package com.peng.controller;

import com.alipay.api.AlipayApiException;
import com.alipay.api.AlipayClient;
import com.alipay.api.DefaultAlipayClient;
import com.alipay.api.request.AlipaySystemOauthTokenRequest;
import com.alipay.api.response.AlipaySystemOauthTokenResponse;
import com.jfinal.aop.Inject;
import com.jfinal.core.ActionKey;
import com.jfinal.plugin.activerecord.Db;
import com.jfinal.plugin.activerecord.IAtom;
import com.jfinal.plugin.activerecord.Page;
import com.peng.config.Constants;
import com.peng.enums.AccountDetailEnum;
import com.peng.enums.ReturnCodeEnum;
import com.peng.mdd.model.*;
import com.peng.mdd.service.MddAccountDetailService;
import com.peng.mdd.service.MddConfigService;
import com.peng.mdd.service.MddInviteCodeService;
import com.peng.mdd.service.MddUserService;
import com.peng.model.AlipayConfig;
import com.peng.model.JwtUser;
import com.peng.model.vo.TradeVo;
import com.peng.service.AlipayConfigService;
import com.peng.utils.*;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;
import redis.clients.jedis.Jedis;

import java.sql.SQLException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by wupeng on 2019/4/16.
 */
public class UserController extends BaseController {

    @Inject
    private MddUserService userService;

    @Inject
    private MddAccountDetailService mddAccountDetailService;

    @Inject
    private AlipayConfigService alipayConfigService;

    @Inject
    private MddConfigService mddConfigService;

    @Inject
    private MddInviteCodeService mddInviteCodeService;


    /**
     * 登录
     */
    public void login() {
        String phone = getPara("phone");
        String pwd = getPara("pwd");

        MddUser user = userService.login(phone,pwd);
        if (user == null) {
            renderInfo(ReturnCodeEnum.账号或者密码不正确);
            return;
        }

        JwtUser jwtUser = new JwtUser();
        jwtUser.setId(user.getId());
        jwtUser.setUsername(user.getPhone());
        jwtUser.setPassword(user.getPwd());
        String token = JwtTokenUtil.createJWT(600000L, jwtUser);
        Map<String, Object> map = new HashMap<>();
        map.put("token", token);
        map.put("code", ReturnCodeEnum.请求成功.getCode());
        user = userService.info(user.getId());
        map.put("info", user);

        renderJson(map);
    }

    /**
     * 修改昵称
     */
    public void updateNickname() {
        String nickname = getPara("nickname");

        MddUser user = MddUser.dao.findById(getUserId());
        user.setNickname(nickname);
        user.update();

        renderSuccess();
    }

    /**
     * 注册
     */
    public void reg() {
        String phone = getPara("phone");
        String authCode = getPara("auth_code");
        String pwd = getPara("pwd");
        String invite_phone = getPara("invite_phone");
        String invite_code = getPara("invite_code");
        String nickname = getPara("nickname");

//        MddInviteCode inviteCode = mddInviteCodeService.findByCode(invite_code);
//        if (inviteCode == null){
//            renderInfo(ReturnCodeEnum.邀请码不正确);
//            return;
//        }

        if (StringUtils.isBlank(phone)) {
            renderInfo(ReturnCodeEnum.手机号不能为空);
            return;
        }

        if (phone.equals(invite_phone)){
            renderInfo(ReturnCodeEnum.邀请手机号不能和自己手机号一样);
            return;
        }

        if (StringUtils.isBlank(authCode)) {
            renderInfo(ReturnCodeEnum.验证码不能为空);
            return;
        }

        if (StringUtils.isBlank(pwd)) {
            renderInfo(ReturnCodeEnum.密码不能为空);
            return;
        }

        if (StringUtils.isBlank(nickname)) {
            renderInfo(ReturnCodeEnum.昵称不能为空);
            return;
        }

        Jedis jedis = null;
        try {
            jedis = RedisUtil.smsJedis();
            String sendsms = jedis.get(phone);

            //请先发送短信
            if (sendsms == null) {
                renderInfo(ReturnCodeEnum.请先发送短信);
                return;
            }

            //短信不匹配
            if (!sendsms.equals(authCode)) {
                renderInfo(ReturnCodeEnum.短信不匹配);
                return;
            }else {
                //删除短信验证码
                jedis.del(phone);
                jedis.del(phone+"ex");
            }
        } finally {
            jedis.close();
        }

        //判断用户是否注册
        MddUser user = userService.findByPhone(phone);
        if (user != null) {
            renderInfo(ReturnCodeEnum.手机号已被注册);
            return;
        }

        Db.tx(new IAtom() {

            @Override
            public boolean run() throws SQLException {
                //判断邀请人手机号是否正确
                MddUser inviteUser = null;
                if (StringUtils.isNotBlank(invite_phone)) {
                    inviteUser = userService.findByPhone(invite_phone);
                }

                MddUser user = new MddUser();
                user.setHeadImg("headimg.png");
                user.setPhone(phone);
                user.setPwd(MD5Helper.encoderByMD5Salt(pwd));
                user.setNickname(nickname);
                user.setState(1);
                if (inviteUser != null) {
                    user.setPid(inviteUser.getId());
                    PushUtils.push(inviteUser.getId().toString(), "新增战队成员", "用户"+user.getNickname()+"成为你的战队成员啦!!!");
                }
                user.save();

                // 判断用户是否能升级队长
                if (inviteUser != null) {
                    userService.upCaptain(inviteUser.getId(),10);
                }

//                inviteCode.setIsUse(1);
//                inviteCode.setUseTime(new Date());
//                inviteCode.update();
                return true;
            }
        });


        renderSuccess();
    }

    /**
     * 忘记密码
     */
    public void forgetpwd() {
        String phone = getPara("phone");
        String authCode = getPara("auth_code");
        String pwd = getPara("pwd");

        if (StringUtils.isBlank(phone)) {
            renderInfo(ReturnCodeEnum.手机号不能为空);
            return;
        }

        if (StringUtils.isBlank(authCode)) {
            renderInfo(ReturnCodeEnum.验证码不能为空);
            return;
        }

        if (StringUtils.isBlank(pwd)) {
            renderInfo(ReturnCodeEnum.密码不能为空);
            return;
        }

        Jedis jedis = null;
        try {
            jedis = RedisUtil.smsJedis();
            String sendsms = jedis.get(phone);

            //请先发送短信
            if (sendsms == null) {
                renderInfo(ReturnCodeEnum.请先发送短信);
                return;
            }

            //短信不匹配
            if (!sendsms.equals(authCode)) {
                renderInfo(ReturnCodeEnum.短信不匹配);
                return;
            }else {
                //删除短信验证码
                jedis.del(phone);
                jedis.del(phone+"ex");
            }
        } finally {
            jedis.close();
        }

        //判断用户是否注册
        MddUser user = userService.findByPhone(phone);
        if (user != null) {
            user.setPwd(MD5Helper.encoderByMD5Salt(pwd));
            user.update();
            renderSuccess();
        }else {
            renderFault();
        }

    }

    public void  test (){
//        Long pid = getParaToLong("pid");
//        Integer count = userService.countAllByPid(pid,10,0);

//        String alias = getPara("alias");
//        String title = getPara("title");
//        String content = getPara("content");
//        PushUtils.push(alias, title, content);


        String APP_PRIVATE_KEY = "MIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQDjeauQxfl9xZ/yXuK4Xqf2kjleqT/9YXvo7lcBIuWG3x79UcWod06UgaLglU/X/4chpIE1Utkm+yu0jjb3+7kBxElhpprwaXarjPnZ4NUe9eDNEGUuzqkE3luPJSit8loUCIMkDL4wrxBeW1tYoEA0WltL0Ev96KwBMcrK/sm4im7F8np4rMvCyKktlDQQhZLHneSKTZfzpO9AfdkySci6GbelxqtLiBkJUw67wtqzYP64UlLPwhe+7qw0fq8NySGEk+blZtisjhgS3hXmwMAIeqgv3CBw5Dp7WavVTrQgGiVeNC+DVLBdUDrDkpdr29MUBmLUJncQxytna0atbhezAgMBAAECggEBAIofbO+hZpbaEv7mYqA0yaRMsY0rE/HU6ZpMboQAHoLApF6I8o4Ss6I0/SOFRlAPlov1CYfJYJXs2WLvH62AKZxLBYvH0Di+sRIFrgiAHqiIABJELEw5rCOKqOnIVGUazVtwt8CCBFInWrcQney4kYO4gcsNFbd9OkQXad3My8vDDahIfpTClU9z/qIWo0DAv9TZVf3T+rQppdEVS7/OE0gp1IMBgeHz5PM/t+uPhbfyl+VKbY5ZrenX/QwnwC9PfMH7Bs4iUJGVN/C6x33zDfWN1JZYuaySB1X18EBmoZ9ortwNx8ImcHCm2OXQ465xrTUXKDDOSuHC+E1jNsyolRECgYEA+zqavAdFRSJMvxMJ1cgH8wVtRhX/Sh04rPwBrOSH1bj8QtS1wv5SPDXeQZ+gVmWgZRLqbLvV8OeXK82YQCqLUWgyZQRlIm5/WSHgeR2YsvqD9GLXykIBcOZgaa0FWEh/43D8UkYmny2ekeetBNt5oh/kZEaTfPbQtvQffXTszT0CgYEA58uVQH/8vEdqVq539f5Am8XI8zj+GvAQJkDCcXc2vf5rOoBbGfgGOdQvcc18qZfzN5E+ChKW3A170ToU8UfH0OYtPVHtOWojhydR/Orz3bPqAJ/ImTVBsIgI7ZxpaJERWI27y8rztv/pzEnT1UrvhDgaV/KzKFER4qXJTt0Hp68CgYEAj/Ci6SpNQPAHAs74qpjiHRY15psB2sflSg9VMmb5gLVtKylOPruSCFdg0T6REg9GF8L/t27jhBRco8c2/USi7/CANyqOe2zN4Bat0xbm/1zTL7lWI9cvli0YflOYpV1ckMaSet0gkcEEglo34nmRNheJtv5M0KNlL/2s8SeF6Y0CgYA78yV49yEwuO/B14HjN40SPMdKULU31lr26czgd8rKvOCS0tu9Da7eighzUIgrfMdE2eXHySMHat1ZMcJ03PHLD50nvOaz8MWbkQnddg74ii29V5YUOffxZl2YxtlkWBC6bH3jqWv7KpkXYwjMo4LrGW+Gy5iWltEfY217XiM6tQKBgFGKGiPKGQe7A2aCjIRYdxpibIfblC0e3ZQYWro4IHaWRjxupSEVPMtfYXk1v5uny9806qPLjhixanLDalHvrrBBwddu/OMGfsB1S9MqEQjD0Kd9GPqEBGQ3RABmet8qWk/lKVqbgnR4FKcuqgRXhZdc6vScsLn2GXK6mwHpor0r";
        String ALIPAY_PUBLIC_KEY = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAukJIL5HzBFamOpqEEww7INZFrHXwd0CvDmgxZg8AtPfVRaPuRtFb5VpwJxxTlHF8OWcdsKDzMxTjPMLoJsNB4oDsnDDfjX9lX+Brt+V7KChXvsDZCtendwP2tKfL45OS32DRqcz6HjW/ZlGRno3oI534UYxBBd7n0+930cD1w8hjIaZylL7Uh6Eh/yvfT6ZSMm10rdhL4n4JzvsLzgkezNWjYqGTCT0BbmHz2oGXXVQ24DX5Zh6o7R1cEy074lImW2jYGbq6j1SqZPkPP52iwzYjGSqWu/NViHNsWNTEIA329ZAdLKeEh+LfWMJSsxCfnuwIIFGitc3ZK5B766jO5QIDAQAB";

        AlipayClient alipayClient = new DefaultAlipayClient("https://openapi.alipay.com/gateway.do", "2019061165518378", APP_PRIVATE_KEY, "json", "utf-8", ALIPAY_PUBLIC_KEY, "RSA2");
        AlipaySystemOauthTokenRequest request = new AlipaySystemOauthTokenRequest();
        request.setCode("8c7767adf5794748ae9d8e60f575XE48");//这个就是第一步获取的auth_code
        request.setGrantType("authorization_code");//这个固定值,参考https://docs.open.alipay.com/api_9/alipay.system.oauth.token
        try {
            AlipaySystemOauthTokenResponse oauthTokenResponse = alipayClient.execute(request);
            System.out.println(oauthTokenResponse.getBody());
            System.out.println(oauthTokenResponse.getUserId());
        } catch (AlipayApiException e) {
            //处理异常
            e.printStackTrace();
        }
        renderJson("");
    }



    /**
     * 发送短信
     */
    public void sendsms() {
        String phone = getPara("phone");

        if (StringUtils.isBlank(phone)) {
            renderInfo(ReturnCodeEnum.手机号不能为空);
            return;
        }

        String sms = RedisUtil.smsJedis().get(phone+"ex");
        if (sms != null) {
            renderInfo(ReturnCodeEnum.请60秒后再获取验证码);
            return;
        }

        //生成验证码
        String number = RandomStringUtils.random(4,false,true);
        //number = "1234";

        //保存验证码
        Jedis jedis = RedisUtil.smsJedis();
        jedis.setex(phone, 60*5, number);
        jedis.setex(phone+"ex", 60, number);
        jedis.close();


        boolean flag = SmsUtil.sendAuthCode(phone, number.toString());

        if (flag) {
            renderSuccess();
        }else {
            renderFault();
        }

    }

    /**
     * 个人信息
     */
    public void info() {
        Long userId = getUserId();
        MddUser user = userService.info(userId);
        Integer allCount = userService.countAllByPid(user.getId(),10,0);
        user.put("all_count",allCount);
        renderObject(user);
    }

    /**
     * 我的团队
     */
    public void team() {
        Long userId = getUserId();

        List<MddUser> list = userService.listByPid(userId);

        renderObject(list);
    }

    /**
     * 账户明细
     */
    public void accountdetail() {

        Long userId = getUserId();

        Integer pageNumber = getParaToInt("pageNumber") == null?1:getParaToInt("pageNumber");
        Integer pageSize = getParaToInt("pageSize") == null?30:getParaToInt("pageSize");

        Page<MddAccountDetail> page = mddAccountDetailService.pageByUid(pageNumber,pageSize,userId);

        renderList(page.getList());
    }

    /**
     * 我的关注
     */
    public void myfollow() {
        Long userId = getUserId();

        List<MddUser> list = MddUser.dao.find("select b.nickname,b.head_img,a.follow_time,b.id from mdd_follow a left join mdd_user b on a.follow_uid = b.id where a.uid = ?",userId);
        for (MddUser user : list) {
            user.setHeadImg(Constants.QINIU_DOMAIN + user.getHeadImg());
        }

        renderObject(list);
    }

    /**
     * 我的粉丝
     */
    public void myfans() {
        Long userId = getUserId();

        List<MddUser> list = MddUser.dao.find("select b.nickname,b.head_img,a.follow_time,b.id from mdd_follow a left join mdd_user b on a.uid = b.id where a.follow_uid = ?",userId);
        for (MddUser user : list) {
            user.setHeadImg(Constants.QINIU_DOMAIN + user.getHeadImg());
        }

        renderObject(list);
    }

    /**
     * 投诉用户
     */
    public void complain() {
        Long taskId = getParaToLong("task_id");
        Long userId = getParaToLong("user_id");
        String content = getPara("content");
        Long loginUserId = getUserId();

        //是否是这个人发布的任务
        MddTask task = MddTask.dao.findFirst("select * from mdd_task where id = ? and uid = ?",taskId,loginUserId);
        if (task == null) {
            renderInfo(ReturnCodeEnum.找不到任务);
            return;
        }

        MddComplain complain = new MddComplain();
        complain.setTaskId(taskId);
        complain.setUid(userId);
        complain.setContent(content);
        complain.save();

        renderSuccess();
    }

    /**
     * 申述
     */
    public void appeal() {
        Long taskId = getParaToLong("task_id");
        String content = getPara("content");
        Long userId = getUserId();

        //任务是否存在
        MddTask task = MddTask.dao.findFirst("select * from mdd_task where id = ?",taskId);
        if (task == null) {
            renderInfo(ReturnCodeEnum.找不到任务);
            return;
        }

        MddAppeal appeal = new MddAppeal();
        appeal.setTaskId(taskId);
        appeal.setUid(userId);
        appeal.setContent(content);
        appeal.save();

        renderSuccess();
    }

    /**
     * 举报任务
     */
    public void report() {
        Long taskId = getParaToLong("task_id");
        String content = getPara("content");
        String imgs = getPara("imgs");
        Long userId = getUserId();

        //任务是否存在
        MddTask task = MddTask.dao.findFirst("select * from mdd_task where id = ?",taskId);
        if (task == null) {
            renderInfo(ReturnCodeEnum.找不到任务);
            return;
        }

        MddReport report = new MddReport();
        report.setTaskId(taskId);
        report.setUid(userId);
        report.setContent(content);
        report.setImageList(imgs);
        report.save();

        renderSuccess();
    }

    /**
     * 米币充值
     */
    public void pay() throws Exception{

        String amount = getPara("amount");
        if (Float.valueOf(amount) < 1) {
            renderInfo(ReturnCodeEnum.金额必须大于1);
            return;
        }
        TradeVo trade = new TradeVo();
        AlipayConfig alipay = alipayConfigService.find();
        trade.setOutTradeNo(AlipayUtils.getOrderCode());
        trade.setSubject(AccountDetailEnum.米币充值.getMsg());
        trade.setTotalAmount(amount);
        trade.setBody("米多多平台的米币");

        MddTrade mddTrade = new MddTrade();
        mddTrade.setBody(trade.getBody());
        mddTrade.setSubject(trade.getSubject());
        mddTrade.setTotalAmount(trade.getTotalAmount());
        mddTrade.setUid(getUserId());
        mddTrade.setState(1);
        mddTrade.setCreateTime(new Date());
        mddTrade.setOutTradeNo(trade.getOutTradeNo());
        mddTrade.save();
        String payUrl = alipayConfigService.toPayAsWeb(alipay,trade);
        renderObject(payUrl);
    }

    /**
     * 保证金充值
     */
    public void earnestMoneyPay() throws Exception{

        String amount = getPara("amount");
        if (Float.valueOf(amount) < 1000) {
            renderInfo(ReturnCodeEnum.保证金必须大于1000元);
            return;
        }
        TradeVo trade = new TradeVo();
        AlipayConfig alipay = alipayConfigService.find();
        trade.setOutTradeNo(AlipayUtils.getOrderCode());
        trade.setSubject(AccountDetailEnum.保证金充值.getMsg());
        trade.setTotalAmount(amount);
        trade.setBody("米多多平台的保证金");

        MddTrade mddTrade = new MddTrade();
        mddTrade.setBody(trade.getBody());
        mddTrade.setSubject(trade.getSubject());
        mddTrade.setTotalAmount(trade.getTotalAmount());
        mddTrade.setUid(getUserId());
        mddTrade.setState(1);
        mddTrade.setCreateTime(new Date());
        mddTrade.setOutTradeNo(trade.getOutTradeNo());
        mddTrade.save();
        String payUrl = alipayConfigService.toPayAsWeb(alipay,trade);
        renderObject(payUrl);
    }

    /**
     * 保证金申退
     */
    public void earnestMoneyBack() throws Exception{

        MddUser user = MddUser.dao.findById(getUserId());
        String amount = getPara("amount");
        if (Float.valueOf(amount) <= 0 || Float.valueOf(amount) > user.getEarnestMoney()) {
            renderInfo(ReturnCodeEnum.余额不足);
            return;
        }

        MddEarnestMoneyBack memb = new MddEarnestMoneyBack();
        memb.setAmount(Float.valueOf(amount));
        memb.setUid(user.getId());
        memb.save();

        user.setEarnestMoney(user.getEarnestMoney() - Float.valueOf(amount));
        user.update();

        renderSuccess();
    }

    /**
     * 米币提现
     */
    public void coinAdvance() throws Exception{

        Integer amount = getParaToInt("amount");
        AlipayConfig alipay = alipayConfigService.find();
        MddUser user = MddUser.dao.findById(getUserId());

        if (StringUtils.isBlank(user.getAlipayNumber()) || StringUtils.isBlank(user.getAlipayName())) {
            renderInfo(ReturnCodeEnum.请先完善支付宝账号);
            return;
        }

        if (amount < 10 || amount > 500){
            renderInfo(ReturnCodeEnum.提现金额需大于等于10元小于等于500元);
            return;
        }

        if (user.getMiCoin() < amount){
            renderInfo(ReturnCodeEnum.余额不足);
            return;
        }

        if (user.getAdvanceCount() > 2){
            renderInfo(ReturnCodeEnum.一天只能提现3次);
            return;
        }

        Boolean flag = alipayConfigService.transfer(alipay,user.getAlipayNumber(),user.getAlipayName(),String.valueOf(amount-amount*0.1),"三明市启晟网络有限公司","米币提现",AlipayUtils.getOrderCode());
        if (flag){
            user.setMiCoin(user.getMiCoin() - amount);
            user.setTotalAdvanceMoney(user.getTotalAdvanceMoney() + Float.valueOf(amount));
            user.setAdvanceCount(user.getAdvanceCount() + 1);
            user.update();

            //添加账户明细
            MddAccountDetail mad = new MddAccountDetail();
            mad.setMoney(- Float.valueOf(amount));
            mad.setOp(AccountDetailEnum.米币提现.getMsg());
            mad.setUid(user.getId());
            mad.save();

            renderSuccess();
        }else {
            renderFault();
        }

    }

    /**
     * 收入提现
     */
    public void incomeAdvance() throws Exception{

        Integer amount = getParaToInt("amount");
        AlipayConfig alipay = alipayConfigService.find();
        MddUser user = MddUser.dao.findById(getUserId());

        if (StringUtils.isBlank(user.getAlipayNumber()) || StringUtils.isBlank(user.getAlipayName())) {
            renderInfo(ReturnCodeEnum.请先完善支付宝账号);
            return;
        }

        if (amount < 1 || amount > 200){
            renderInfo(ReturnCodeEnum.提现金额需大于等于1元小于等于200元);
            return;
        }

        if (user.getIncome() < amount){
            renderInfo(ReturnCodeEnum.余额不足);
            return;
        }

        if (user.getAdvanceCount() > 2){
            renderInfo(ReturnCodeEnum.一天只能提现3次);
            return;
        }

        Boolean flag = alipayConfigService.transfer(alipay,user.getAlipayNumber(),user.getAlipayName(),String.valueOf(amount-amount*0.1),"三明市启晟网络有限公司","收入提现",AlipayUtils.getOrderCode());
        if (flag){
            user.setIncome(user.getIncome() - amount);
            user.setTotalAdvanceMoney(user.getTotalAdvanceMoney() + Float.valueOf(amount));
            user.setAdvanceCount(user.getAdvanceCount() + 1);
            user.update();

            //添加账户明细
            MddAccountDetail mad = new MddAccountDetail();
            mad.setMoney(- Float.valueOf(amount));
            mad.setOp(AccountDetailEnum.收入分红提现.getMsg());
            mad.setUid(user.getId());
            mad.save();

            renderSuccess();
        }else {
            renderFault();
        }

    }

    /**
     * 保存支付宝信息
     */
    public void updateAlipay(){
        String account = getPara("account");
        String name = getPara("name");

        Long userId = getUserId();

        MddUser user = MddUser.dao.findById(userId);

        if (user.getUpdateAlipayCount() >= 1){
            renderInfo(ReturnCodeEnum.支付宝账户只能修改一次);
            return;
        }

        user.setAlipayNumber(account);
        user.setAlipayName(name);
        user.setUpdateAlipayCount(user.getUpdateAlipayCount() + 1);
        user.update();

        renderSuccess();
    }

    /**
     * 获取支付宝信息
     */
    public void getAlipay(){
        Long userId = getUserId();

        MddUser user = MddUser.dao.findFirst("select alipay_number,alipay_name from mdd_user where id = ?",userId);

        renderObject(user);
    }

    /**
     * 上传头像
     */
    @ActionKey("user/upload/headimg")
    public void uploadHeadimg(){
        String img = getPara("img");
        MddUser user = MddUser.dao.findById(getUserId());
        user.setHeadImg(img);
        user.update();

        renderSuccess();
    }

}
