package com.peng.controller;

import com.auth0.jwt.JWT;
import com.jfinal.core.Controller;
import com.jfinal.kit.JsonKit;
import com.peng.enums.ReturnCodeEnum;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BaseController extends Controller {

	public Long getUserId(){
		String token = getHeader("Authorization");
		if (token == null){
			return null;
		}
		Long userId = JWT.decode(token).getClaim("id").asLong();
		return userId;
	}
	
	/**
	 * 构建返回map
	 * @param data 数据
	 * @return
	 */
	public Map<String,Object> buildReturnMap(Object data){
		Map<String,Object> returnMap = new HashMap<String,Object>();
		returnMap.put("code", ReturnCodeEnum.请求成功.getCode());
		returnMap.put("data", data);
		return returnMap;
	}
	
	public void renderObject(Object data){
		renderJson(buildReturnMap(data));
	}
	
	public void renderList(List<?> list){
		Map<String,Object> returnMap = new HashMap<String,Object>();
		returnMap.put("code", ReturnCodeEnum.请求成功.getCode());
		returnMap.put("count", list.size());
		returnMap.put("data", list);
		renderJson(returnMap);
	}
	
	/**
	 * 返回信息
	 * @param returnCodeEnum 返回码枚举
	 */
	public void renderInfo(ReturnCodeEnum returnCodeEnum) {
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("code", returnCodeEnum.getCode());
		map.put("msg", returnCodeEnum.getMsg());
		
		renderJson(map);
	}
	
	/**
	 * 返回成功信息
	 */
	public void renderSuccess() {
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("code", ReturnCodeEnum.请求成功.getCode());
		map.put("msg", ReturnCodeEnum.请求成功.getMsg());
		
		renderJson(map);
	}
	
	/**
	 * 返回失败信息
	 */
	public void renderFault() {
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("code", ReturnCodeEnum.操作失败.getCode());
		map.put("msg", ReturnCodeEnum.操作失败.getMsg());
		
		renderJson(map);
	}

	public void renderJsonp(String jsonText) {
		//super.renderJson("callback("+jsonText+")");
		//getResponse().setHeader("Access-Control-Allow-Origin", "*");
		getResponse().setHeader("Access-Control-Allow-Headers", "Origin,X-Requested-With,Content-Type,Accept,Authorization,Jwt");
		getResponse().setHeader("Access-Control-Allow-Origin", getRequest().getHeader("Origin"));
		getResponse().setHeader("Access-Control-Allow-Methods", "GET,PUT,POST,DELETE,PATCH,OPTIONS");
		getResponse().setHeader("Access-Control-Allow-Credentials", "true");

		super.renderJson(jsonText);
	}

	@Override
	public void renderJson(String jsonText) {
		this.renderJsonp(jsonText);
	}

	@Override
	public void renderJson(Object object) {
		String jsonText = JsonKit.toJson(object).replaceAll("null", "\"\"");
		this.renderJsonp(jsonText);
	}

	@Override
	public void renderJson(String key, Object value) {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put(key, value);
		this.renderJsonp(JsonKit.toJson(map));
	}
}
