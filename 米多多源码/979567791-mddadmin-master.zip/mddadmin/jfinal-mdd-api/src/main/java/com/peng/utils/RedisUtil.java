package com.peng.utils;

import com.jfinal.plugin.redis.Redis;

import redis.clients.jedis.Jedis;

public class RedisUtil {
	
	public static Jedis smsJedis() {
		 Jedis jedis = Redis.use("mdd").getJedis();
		 jedis.select(1);
		return jedis;
	}
	
	public static Jedis tokenJedis() {
		 Jedis jedis = Redis.use("mdd").getJedis();
		 jedis.select(2);
		return jedis;
	}

}
