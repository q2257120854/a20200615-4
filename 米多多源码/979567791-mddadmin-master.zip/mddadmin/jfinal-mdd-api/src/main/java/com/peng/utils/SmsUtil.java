package com.peng.utils;

import com.alibaba.fastjson.JSONObject;
import com.peng.config.Constants;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.message.BasicNameValuePair;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

public class SmsUtil {
	public static boolean sendAuthCode(String phone,String number) {
		//发送短信
		String tplId = Constants.SMS_TPL_ID;
		String url = Constants.SMS_URL;
		String appKey = Constants.SMS_APP_KEY;


		try {
			HttpPost httpPost = new HttpPost(url);
			List<NameValuePair> params=new ArrayList<NameValuePair>();
			//建立一个NameValuePair数组，用于存储欲传送的参数
			params.add(new BasicNameValuePair("tpl_id",tplId));
			params.add(new BasicNameValuePair("key",appKey));
			params.add(new BasicNameValuePair("mobile",phone));
			params.add(new BasicNameValuePair("tpl_value",URLEncoder.encode("#code#="+number,"GBK")));
			//添加参数
			httpPost.setEntity(new UrlEncodedFormEntity(params));
			String result = HttpUtils.post(httpPost);
			JSONObject object = JSONObject.parseObject(result);
			if(object.getInteger("error_code") != 0){
				return false;
	        }
			return true;
		} catch (Exception e) {
			return false;
		}
	}
}
