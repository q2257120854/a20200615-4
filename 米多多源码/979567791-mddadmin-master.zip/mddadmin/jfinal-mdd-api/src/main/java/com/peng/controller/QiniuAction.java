package com.peng.controller;

import com.jfinal.kit.HttpKit;
import com.peng.config.Constants;
import com.qiniu.util.Auth;
import com.qiniu.util.StringMap;
import com.qiniu.util.UrlSafeBase64;

import java.util.HashMap;
import java.util.Map;

public class QiniuAction extends BaseController {
	
	//private final static Logger logger = LoggerFactory.getLogger(IndexAction.class);
	
	public void token() throws Exception {
		String accessKey = Constants.QINIU_ACCESS_KEY;
		String secretKey = Constants.QINIU_SECRET_KEY;
		String bucket = Constants.QINIU_BUCKET;
		Auth auth = Auth.create(accessKey, secretKey);
		String upToken = auth.uploadToken(bucket, null, 60*15, null, true);
		renderObject(upToken);
	}

    public void manage() throws Exception {
        String filename = getPara("filename");
        String op = getPara("op");
        String accessKey = Constants.QINIU_ACCESS_KEY;
        String secretKey = Constants.QINIU_SECRET_KEY;
        String bucket = Constants.QINIU_BUCKET;
        Auth auth = Auth.create(accessKey, secretKey);


        Map<String,String> heads = new HashMap<String,String>();


//        encodedEntryURI
        // filename = "FvaOW0Yz9uAArtAIZ9fBN5TTXBC6";
        String encodedEntryURI = UrlSafeBase64.encodeToString(bucket+":"+filename);
        String url = "http://rs.qiniu.com/"+op+"/"+encodedEntryURI;

        StringMap authorization = auth.authorization(url);
        heads.put("Authorization",authorization.get("Authorization").toString());
        String s = HttpKit.post("http://rs.qiniu.com/delete/"+encodedEntryURI,null,heads);
        renderNull();
    }
}
