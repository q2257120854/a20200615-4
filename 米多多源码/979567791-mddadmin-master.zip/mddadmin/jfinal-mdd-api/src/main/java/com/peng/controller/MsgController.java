package com.peng.controller;

import com.peng.enums.ReturnCodeEnum;
import com.peng.mdd.model.MddMessage;

import java.util.List;


public class MsgController extends BaseController {
	
	//private final static Logger logger = LoggerFactory.getLogger(BannerController.class);
	
	public void list() throws Exception {
		
		List<MddMessage> list = MddMessage.dao.find("select * from mdd_message where uid = ? order by time desc",getUserId());
		
		if (list.isEmpty()) {
			renderInfo(ReturnCodeEnum.数据为空);
			return;
		}
		
		renderList(list);
	}

}
