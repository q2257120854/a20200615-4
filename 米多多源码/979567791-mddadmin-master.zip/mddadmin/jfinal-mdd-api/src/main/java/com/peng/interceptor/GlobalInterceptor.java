package com.peng.interceptor;

import com.jfinal.aop.Interceptor;
import com.jfinal.aop.Invocation;
import com.jfinal.render.JsonRender;
import com.jfinal.render.Render;
import com.peng.enums.ReturnCodeEnum;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by wupeng on 2019/4/17.
 */
public class GlobalInterceptor implements Interceptor {


    public void intercept(Invocation inv) {

        inv.invoke();
        Render r = inv.getController().getRender();
        if (r instanceof JsonRender) {
            String JsonText = ((JsonRender)r).getJsonText();
            // JsonText 处理
        }

    }

    /**
     * 返回信息
     * @param returnCodeEnum 返回码枚举
     */
    public Map renderInfo(ReturnCodeEnum returnCodeEnum) {
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("code", returnCodeEnum.getCode());
        map.put("msg", returnCodeEnum.getMsg());

        return map;
    }
}
