package com.peng.controller;

import com.jfinal.aop.Inject;
import com.peng.enums.ReturnCodeEnum;
import com.peng.mdd.model.MddNotice;
import com.peng.mdd.service.MddNoticeService;

import java.util.List;


public class NoticeController extends BaseController {
	
	//private final static Logger logger = LoggerFactory.getLogger(BannerController.class);
	@Inject
	private MddNoticeService noticeService;
	
	public void list() throws Exception {
		
		List<MddNotice> list = noticeService.list();
		
		if (list.isEmpty()) {
			renderInfo(ReturnCodeEnum.数据为空);
			return;
		}
		
		renderList(list);
	}

}
