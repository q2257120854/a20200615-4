package com.peng.utils;

import com.alibaba.druid.pool.DruidDataSource;
import com.jfinal.kit.PathKit;
import com.jfinal.plugin.activerecord.generator.Generator;

public class ModelGenerator {
	public static void main(String[] args) {
		// base model 所使用的包名
		String baseModelPkg = "com.peng.model.base";
		// base model 文件保存路径
		String baseModelDir = PathKit.getWebRootPath()  + "/src/main/java/" + baseModelPkg.replace(".", "/");
		 
		// model 所使用的包名
		String modelPkg = "com.peng.model";
		// model 文件保存路径
		String modelDir = PathKit.getWebRootPath()  + "/src/main/java/" + modelPkg.replace(".", "/");
		
		DruidDataSource ds = new DruidDataSource();
		ds.setUrl("jdbc:mysql://127.0.0.1:3306/mdd");
		ds.setUsername("root");
		ds.setPassword("root");
		 
		Generator gernerator = new Generator(ds, baseModelPkg, baseModelDir, modelPkg, modelDir);
		gernerator.generate();
	}
}
