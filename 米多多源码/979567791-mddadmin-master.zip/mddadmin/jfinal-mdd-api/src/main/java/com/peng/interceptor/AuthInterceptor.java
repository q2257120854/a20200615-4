package com.peng.interceptor;

import com.auth0.jwt.JWT;
import com.jfinal.aop.Interceptor;
import com.jfinal.aop.Invocation;
import com.jfinal.core.Controller;
import com.peng.enums.ReturnCodeEnum;
import com.peng.mdd.model.MddUser;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by wupeng on 2019/4/17.
 */
public class AuthInterceptor implements Interceptor {

    public static ArrayList<String> excludes = new ArrayList<String>();

    static {
        excludes.add("/user/login");
        excludes.add("/user/sendsms");
        excludes.add("/user/reg");
        excludes.add("/banner/list");
        excludes.add("/notice/list");
    }

    public void intercept(Invocation inv) {

        String uri = inv.getActionKey();

        for (String pattern : excludes) {
            if (uri.contains(pattern)) {
                inv.invoke();
                return;
            }
        }

        Controller controller = inv.getController();
        String token = controller.getHeader("Authorization");
        if (token == null){
            controller.renderJson(renderInfo(ReturnCodeEnum.token不能为空));
            return;
        }
        Long userId = JWT.decode(token).getClaim("id").asLong();
        if (userId == null){
            controller.renderJson(renderInfo(ReturnCodeEnum.请先登录));
            return;
        }

        MddUser user = MddUser.dao.findById(userId);
        if (user == null || user.getState() == 0){
            controller.renderJson(renderInfo(ReturnCodeEnum.请先登录));
            return;
        }

        inv.invoke();

    }

    /**
     * 返回信息
     * @param returnCodeEnum 返回码枚举
     */
    public Map renderInfo(ReturnCodeEnum returnCodeEnum) {
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("code", returnCodeEnum.getCode());
        map.put("msg", returnCodeEnum.getMsg());

        return map;
    }
}
