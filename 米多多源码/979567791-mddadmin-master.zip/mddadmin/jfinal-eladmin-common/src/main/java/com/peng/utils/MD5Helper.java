package com.peng.utils;

import org.apache.commons.codec.digest.DigestUtils;

public class MD5Helper {
	
	static private final String salt = "sbusv234hio2T%F@";
	
	static public String encoderByMD5Salt(String str){
		return DigestUtils.md5Hex(str+salt);
	}

	static public String encoderByMD5(String str){
		return DigestUtils.md5Hex(str);
	}
}
