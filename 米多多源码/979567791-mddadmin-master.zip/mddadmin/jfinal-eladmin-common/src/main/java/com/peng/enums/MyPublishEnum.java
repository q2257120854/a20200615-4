package com.peng.enums;

/**
 * 服务器返回码枚举
 * @author wupeng
 *
 */
public enum MyPublishEnum {
	待审核(1,"待审核"),
	未通过(2,"未通过"),
	进行中(3,"进行中"),
	已暂停(4,"已暂停"),
	已结束(5,"已结束"),
	
	;
	
	private int code;
	private String msg;
	

	private MyPublishEnum(int code, String msg) {
		this.code = code;
		this.msg = msg;
	}

	public String getMsg() {
		return this.msg;
	}

	public int getCode() {
		return this.code;
	}
}
