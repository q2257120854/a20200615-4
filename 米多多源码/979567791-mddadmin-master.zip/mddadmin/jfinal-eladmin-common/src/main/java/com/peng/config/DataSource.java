package com.peng.config;

public class DataSource {
	public static String ADMIN = "admin";
	public static String MDD = "mdd";
}
