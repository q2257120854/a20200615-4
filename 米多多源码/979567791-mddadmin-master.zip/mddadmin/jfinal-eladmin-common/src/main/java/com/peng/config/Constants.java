package com.peng.config;

import com.jfinal.kit.PropKit;

public class Constants {
	public static String QINIU_DOMAIN = PropKit.get("qiniu_domain");
    public static String QINIU_ACCESS_KEY = PropKit.get("QINIU_ACCESS_KEY");
    public static String QINIU_SECRET_KEY = PropKit.get("QINIU_SECRET_KEY");
    public static String QINIU_BUCKET = PropKit.get("QINIU_BUCKET");

    public static String SMS_URL = PropKit.get("SMS_URL");
    public static String SMS_APP_KEY = PropKit.get("SMS_APP_KEY");
    public static String SMS_TPL_ID = PropKit.get("SMS_TPL_ID");

    public static String jpush_appkey = PropKit.get("jpush_appkey");
    public static String jpush_secret = PropKit.get("jpush_secret");
    public static String task_top_hour_price = "task_top_hour_price";

}
