package com.peng.service;

import com.peng.model.AlipayConfig;
import com.peng.model.vo.TradeVo;

public interface AlipayConfigService extends BaseService {

    /**
     * 处理来自PC的交易请求
     * @param alipay
     * @param trade
     * @return
     * @throws Exception
     */
    String toPayAsPC(AlipayConfig alipay, TradeVo trade) throws Exception;

    /**
     * 处理来自手机网页的交易请求
     * @param alipay
     * @param trade
     * @return
     * @throws Exception
     */
    String toPayAsWeb(AlipayConfig alipay, TradeVo trade) throws Exception;

    com.peng.model.AlipayConfig find();

    Boolean transfer(AlipayConfig alipay,String account,String name,String amount,String showName,String remark,String outBizNo) throws Exception;
}