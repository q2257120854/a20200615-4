package com.peng.utils;

import cn.jiguang.common.ClientConfig;
import cn.jpush.api.JPushClient;
import cn.jpush.api.push.PushResult;
import cn.jpush.api.push.model.Platform;
import cn.jpush.api.push.model.PushPayload;
import cn.jpush.api.push.model.audience.Audience;
import cn.jpush.api.push.model.notification.AndroidNotification;
import cn.jpush.api.push.model.notification.IosAlert;
import cn.jpush.api.push.model.notification.IosNotification;
import cn.jpush.api.push.model.notification.Notification;
import com.peng.config.Constants;

/**
 * Created by wupeng on 2019/6/11.
 */
public class PushUtils {
    public static void push(String alias, String title, String content) {
        // 发送推送通知
        try {

            IosAlert iosAlert = IosAlert.newBuilder().setTitleAndBody(title,"",content).build();

            PushPayload payload = PushPayload.newBuilder()
                    .setPlatform(Platform.all())
                    .setAudience(Audience.alias(alias.split(",")))
                    .setNotification(Notification.newBuilder()
                            .addPlatformNotification(IosNotification.newBuilder()
                                    .setAlert(iosAlert)
                                    .setBadge(0)
                                    .setSound("happy")
                                    .build())
                            .addPlatformNotification(AndroidNotification.newBuilder()
                                    .setAlert(content)
                                    .setTitle(title)
                                    .build()).build())
                    .build();

            JPushClient jpushClient = new JPushClient(Constants.jpush_secret, Constants.jpush_appkey, null, ClientConfig.getInstance());
            PushResult result = jpushClient.sendPush(payload);
            System.out.print(result.getOriginalContent());
            // 请求结束后，调用 NettyHttpClient 中的 close 方法，否则进程不会退出。
            jpushClient.close();
        } catch(Exception e) {
            e.printStackTrace();
        }
    }
}
