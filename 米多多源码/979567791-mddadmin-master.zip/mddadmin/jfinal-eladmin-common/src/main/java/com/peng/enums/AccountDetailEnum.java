package com.peng.enums;

/**
 * 服务器返回码枚举
 * @author wupeng
 *
 */
public enum AccountDetailEnum {
    发布任务(1,"发布任务-"),
    任务获得(2,"任务获得-"),
    一级佣金(3,"一级佣金-"),
    任务退回(4,"任务退回-"),
    上调价格(5,"上调价格-"),
    追加数量(6,"追加数量-"),
    置顶任务(7,"置顶任务-"),
	米币充值(8,"米币充值"),
    保证金充值(9,"保证金充值"),
    米币提现(10,"米币提现"),
    收入分红提现(11,"收入分红提现"),
	置顶店铺(12,"置顶店铺"),
    队长佣金(13,"队长佣金-"),
    充值奖励(14,"充值奖励-"),
	保证金退回(14,"保证金退回"),

	;

	private int code;
	private String msg;


	AccountDetailEnum(int code, String msg) {
		this.code = code;
		this.msg = msg;
	}

	public String getMsg() {
		return this.msg;
	}

	public int getCode() {
		return this.code;
	}
}
