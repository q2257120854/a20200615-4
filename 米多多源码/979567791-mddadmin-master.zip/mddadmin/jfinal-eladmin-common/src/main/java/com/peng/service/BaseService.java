package com.peng.service;

import java.util.List;

public interface BaseService<T>{

    /**
     * find model by primary key
     *
     * @param id
     * @return
     */
    public T findById(Object id);


    /**
     * find all model
     *
     * @return all <Dept
     */
    public List<T> findAll();


    /**
     * delete model by primary key
     *
     * @param id
     * @return success
     */
    public boolean deleteById(Object id);


}