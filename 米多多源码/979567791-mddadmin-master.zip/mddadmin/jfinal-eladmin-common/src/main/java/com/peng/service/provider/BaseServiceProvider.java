package com.peng.service.provider;

import com.jfinal.plugin.activerecord.Model;
import com.peng.service.BaseService;
import com.peng.utils.ClassUtil;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.List;


public class BaseServiceProvider<T extends Model<T>> implements BaseService {

    protected T DAO = null;

    public BaseServiceProvider() {
        DAO = initDao();
    }

    /**
     * 初始化 DAO
     * 子类可以复写 自定义自己的DAO
     *
     * @return
     */
    protected T initDao() {
        Type type = ClassUtil.getUsefulClass(getClass()).getGenericSuperclass();
        Class<T> modelClass = (Class<T>) ((ParameterizedType) type).getActualTypeArguments()[0];
        if (modelClass == null) throw new RuntimeException("can not get model class name in JbootServiceBase");

        //默认不通过AOP构建DAO，提升性能，若特殊需要重写initDao()方法即可
        return ClassUtil.newInstance(modelClass, false);
    }

    @Override
    public T findById(Object id) {
        return DAO.findById(id);
    }

    @Override
    public List findAll() {
        return DAO.findAll();
    }

    @Override
    public boolean deleteById(Object id) {
        return DAO.deleteById(id);
    }

}