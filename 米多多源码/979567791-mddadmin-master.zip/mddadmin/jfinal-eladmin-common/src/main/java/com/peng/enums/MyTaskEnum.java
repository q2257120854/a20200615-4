package com.peng.enums;

/**
 * 服务器返回码枚举
 * @author wupeng
 *
 */
public enum MyTaskEnum {
	待提交(1,"待提交"),
	待审核(2,"待审核"),
	未通过(3,"未通过"),
	已完成(4,"已完成"),
	
	;
	
	private int code;
	private String msg;
	

	private MyTaskEnum(int code, String msg) {
		this.code = code;
		this.msg = msg;
	}

	public String getMsg() {
		return this.msg;
	}

	public int getCode() {
		return this.code;
	}
}
