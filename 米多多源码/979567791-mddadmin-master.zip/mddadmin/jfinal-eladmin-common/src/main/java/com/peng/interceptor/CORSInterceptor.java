package com.peng.interceptor;

import com.jfinal.aop.Interceptor;
import com.jfinal.aop.Invocation;
import com.jfinal.core.Controller;

/**
 * Created by wupeng on 2019/4/17.
 */
public class CORSInterceptor implements Interceptor {
    public void intercept(Invocation inv) {

        Controller controller = inv.getController();



        controller.getResponse().setHeader("Access-Control-Allow-Headers", "Origin,X-Requested-With,Content-Type,Accept,Authorization,Jwt");
        controller.getResponse().setHeader("Access-Control-Allow-Origin", controller.getRequest().getHeader("Origin"));
        controller.getResponse().setHeader("Access-Control-Allow-Methods", "GET,PUT,POST,DELETE,PATCH,OPTIONS");
        controller.getResponse().setHeader("Access-Control-Allow-Credentials", "true");

        if("OPTIONS".equalsIgnoreCase(controller.getRequest().getMethod())) {
            controller.renderNull();
        }else{
            inv.invoke();
        }


    }
}
