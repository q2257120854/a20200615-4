package com.peng.rest;

import com.alibaba.fastjson.JSONObject;
import com.jfinal.aop.Inject;
import com.jfinal.core.ActionKey;
import com.jfinal.core.Controller;
import com.jfinal.kit.HttpKit;
import com.peng.config.DataSource;
import com.peng.domain.vo.ColumnInfo;
import com.peng.model.GenConfig;
import com.peng.service.GenConfigService;
import com.peng.service.GeneratorService;
import org.apache.commons.lang3.StringUtils;

import java.util.List;

/**
 * @author jie
 * @date 2019-01-02
 */
public class GeneratorController extends Controller{

    @Inject
    private GeneratorService generatorService;

    @Inject
    private GenConfigService genConfigService;

    /**
     * 查询数据库元数据
     * @return
     */
    @ActionKey("api/generator/tables")
    public void getTables(){
        String name = getPara("name");
        String dataSource = getPara("dataSource");
        if (StringUtils.isBlank(dataSource)){
            dataSource = DataSource.MDD;
        }
        Integer page = getParaToInt("page");
        Integer size = getParaToInt("size");
        Object obj = generatorService.getTables(name,page,size,dataSource);
        renderJson(obj);
    }

    /**
     * 查询表内元数据
     * @return
     */
    @ActionKey("api/generator/columns")
    public void getColumns(){
        String dataSource = getPara("dataSource");
        if (StringUtils.isBlank(dataSource)){
            dataSource = DataSource.MDD;
        }
        String tableName = getPara("tableName");
        Object obj = generatorService.getColumns(tableName,dataSource);
        renderJson(obj);
    }

    /**
     * 生成代码
     * @return
     */
    @ActionKey("api/generator")
    public void generator(){
        String json = HttpKit.readData(getRequest());
        List<ColumnInfo> columnInfos = JSONObject.parseArray(json,ColumnInfo.class);
        String tableName = getPara("tableName");

        GenConfig config = (GenConfig)genConfigService.findById(1);
        generatorService.generator(columnInfos,config,tableName);
        renderNull();
    }
}
