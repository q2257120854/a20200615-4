package com.peng.service.impl;

import com.peng.model.GenConfig;
import com.peng.service.GenConfigService;
import com.peng.service.provider.BaseServiceProvider;


public class GenConfigServiceImpl extends BaseServiceProvider<GenConfig> implements GenConfigService {

}
