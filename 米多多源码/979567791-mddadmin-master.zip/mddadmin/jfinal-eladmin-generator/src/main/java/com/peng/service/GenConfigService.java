package com.peng.service;

/**
 * @author jie
 * @date 2019-01-14
 */
public interface GenConfigService extends BaseService{

}
