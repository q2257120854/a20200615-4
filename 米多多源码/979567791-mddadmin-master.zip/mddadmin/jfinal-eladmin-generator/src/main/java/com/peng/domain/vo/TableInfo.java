package com.peng.domain.vo;

/**
 * 表的数据信息
 * @author jie
 * @date 2019-01-02
 */
public class TableInfo {

    /** 表名称 **/
    private Object tableName;

    /** 创建日期 **/
    private Object createTime;

    public TableInfo(Object tableName, Object createTime) {
        this.tableName = tableName;
        this.createTime = createTime;
    }

    public Object getTableName() {
        return tableName;
    }

    public void setTableName(Object tableName) {
        this.tableName = tableName;
    }

    public Object getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Object createTime) {
        this.createTime = createTime;
    }
}
