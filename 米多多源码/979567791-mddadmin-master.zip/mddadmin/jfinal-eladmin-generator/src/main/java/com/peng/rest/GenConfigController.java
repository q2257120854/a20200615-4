package com.peng.rest;

import com.alibaba.fastjson.JSONObject;
import com.jfinal.aop.Inject;
import com.jfinal.core.ActionKey;
import com.jfinal.core.Controller;
import com.jfinal.kit.HttpKit;
import com.peng.model.GenConfig;
import com.peng.service.GenConfigService;

/**
 * @author jie
 * @date 2019-01-14
 */
public class GenConfigController extends Controller{

    @Inject
    private GenConfigService genConfigService;

    /**
     * 查询生成器配置
     * @return
     */
    @ActionKey("api/genConfig/query")
    public void get(){
        GenConfig genConfig = (GenConfig)genConfigService.findById(1);
        renderJson(genConfig);
    }

    @ActionKey("api/genConfig/update")
    public void emailConfig(){
        String json = HttpKit.readData(getRequest());
        GenConfig genConfig = JSONObject.parseObject(json,GenConfig.class);
        genConfig.update();
        renderNull();
    }
}
