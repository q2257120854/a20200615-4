package com.peng.service.impl;

import com.jfinal.plugin.activerecord.Db;
import com.jfinal.plugin.activerecord.Page;
import com.jfinal.plugin.activerecord.Record;
import com.peng.domain.vo.ColumnInfo;
import com.peng.domain.vo.TableInfo;
import com.peng.model.GenConfig;
import com.peng.service.GeneratorService;
import com.peng.utils.GenUtil;
import com.peng.utils.PageUtil;
import org.apache.commons.lang3.StringUtils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class GeneratorServiceImpl implements GeneratorService {

    @Override
    public Object getTables(String name, Integer pageNumber,Integer size,String dataSource) {
        StringBuilder sql = new StringBuilder("from information_schema.tables where table_schema = (select database()) ");
        if(StringUtils.isNotBlank(name)){
            sql.append("and table_name like '%"+name+"%' ");
        }
        sql.append("order by table_name");

        System.out.println(sql.toString());
        Page<Record> page = Db.use(dataSource).paginate(pageNumber,size,"select table_name tableName,create_time createTime ",sql.toString());
        List<TableInfo> tableInfos = new ArrayList<>();
        for (Record obj : page.getList()) {
            tableInfos.add(new TableInfo(obj.getStr("tableName"),obj.getStr("createTime")));
        }
        Record query1 =  Db.use(dataSource).findFirst("SELECT COUNT(*) as count from information_schema.tables where table_schema = (select database())");
        Object totalElements = query1.get("count");
        return PageUtil.toPage(tableInfos,page.getTotalRow());
    }

    @Override
    public Object getColumns(String name,String dataSource) {
        StringBuilder sql = new StringBuilder("select column_name, is_nullable, data_type, column_comment, column_key from information_schema.columns where ");
        if(StringUtils.isNotBlank(name)){
            sql.append("table_name = '"+name+"' ");
        }
        sql.append("and table_schema = (select database()) order by ordinal_position");
        List<Record> result = Db.use(dataSource).find(sql.toString());
        List<ColumnInfo> columnInfos = new ArrayList<>();
        for (Record obj : result) {
            columnInfos.add(new ColumnInfo(obj.get("column_name"),obj.get("is_nullable"),obj.get("data_type"),obj.get("column_comment"),obj.get("column_key"),null,"true"));
        }
        return PageUtil.toPage(columnInfos,columnInfos.size());
    }

    @Override
    public void generator(List<ColumnInfo> columnInfos, GenConfig genConfig, String tableName) {
        if(genConfig.getId() == null){
            throw new RuntimeException("请先配置生成器");
        }
        try {
            GenUtil.generatorCode(columnInfos,genConfig,tableName);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
