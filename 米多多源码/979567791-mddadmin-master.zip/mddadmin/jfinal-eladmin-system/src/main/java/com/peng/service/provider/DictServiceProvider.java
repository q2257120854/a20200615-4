package com.peng.service.provider;

import com.jfinal.plugin.activerecord.Page;
import com.peng.model.Dict;
import com.peng.service.DictService;
import com.peng.service.dto.DictDTO;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.List;


public class DictServiceProvider extends BaseServiceProvider<Dict> implements DictService {

    @Override
    public Page<DictDTO> queryAll(String name, String remark, Integer pageNumber, Integer size) {
        StringBuffer sql = new StringBuffer("from dict where 1=1 ");
        List<Object> para = new ArrayList<>();
        if (StringUtils.isNotBlank(name)) {
            sql.append(" and name like ?");
            para.add("%"+name+"%");
        }
        if (StringUtils.isNotBlank(remark)) {
            sql.append(" and remark like ?");
            para.add("%"+remark+"%");
        }
        Page<Dict> page = DAO.paginate(pageNumber,size,"select *",sql.toString(),para.toArray());
        List<DictDTO> dtoList = new ArrayList<>();
        for (Dict arg0: page.getList()) {

            DictDTO dictDTO = new DictDTO();
            dictDTO.setId(arg0.getId());
            dictDTO.setName(arg0.getName());
            dictDTO.setRemark(arg0.getRemark());
            dtoList.add(dictDTO);
        }

        Page<DictDTO> page2 = new Page<>();
        page2.setList(dtoList);
        page2.setTotalRow(page.getTotalRow());
        return page2;
    }
}