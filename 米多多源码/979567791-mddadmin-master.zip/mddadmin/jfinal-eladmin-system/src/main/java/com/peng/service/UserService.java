package com.peng.service;

import com.jfinal.plugin.activerecord.Page;
import com.peng.model.RolesDepts;
import com.peng.model.User;
import com.peng.service.dto.UserDTO;

import java.util.List;

public interface UserService  extends BaseService{

    Page<UserDTO> queryAll(String username, String email, Boolean enabled, Integer pageNumber, Integer size);

    com.peng.model.User login(String username, String password);

    List<User> aa();
}