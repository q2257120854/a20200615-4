package com.peng.service.provider;

import com.jfinal.plugin.activerecord.Db;
import com.peng.model.UsersRoles;
import com.peng.service.UsersRolesService;


public class UsersRolesServiceProvider extends BaseServiceProvider<UsersRoles> implements UsersRolesService {

    @Override
    public void deleteByUserId(Long userId) {
        Db.update("delete from users_roles where user_id = ?",userId);
    }
}