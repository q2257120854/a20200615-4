package com.peng.service;

import com.jfinal.plugin.activerecord.Page;
import com.peng.service.dto.DictDetailDTO;

public interface DictDetailService<DictDetail>  extends BaseService {
    Page<DictDetailDTO> queryAll(String dictName, String label, Integer pageNumber, Integer size);
}