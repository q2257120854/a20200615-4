package com.peng.modules.system.rest;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.jfinal.aop.Inject;
import com.jfinal.core.ActionKey;
import com.jfinal.core.Controller;
import com.jfinal.kit.HttpKit;
import com.jfinal.plugin.activerecord.Page;
import com.peng.model.QuartzJob;
import com.peng.plugin.QuartzPlugin;
import com.peng.service.QuartzJobService;
import com.peng.utils.PageUtil;
import org.quartz.JobKey;
import org.quartz.SchedulerException;

import java.util.Date;

/**
 * Created by wupeng on 2019/4/19.
 */
public class QuartzJobController extends Controller {

    @Inject
    private QuartzJobService quartzJobService;

    /**
     * 查询定时任务
     */
    @ActionKey("api/jobs/query")
    public void query(){
        String jobName = getPara("jobName");
        Integer pageNumber = getParaToInt("page");
        Integer size = getParaToInt("size");
        Page<QuartzJob> page = quartzJobService.queryAll(jobName,pageNumber,size);
        renderJson(PageUtil.toPage(page));
    }

    /**
     * 新增定时任务
     */
    @ActionKey("api/jobs/add")
    public void add(){
        String json = HttpKit.readData(getRequest());
        JSONObject reqJson = JSON.parseObject(json);
        String beanName = reqJson.getString("beanName");
        String cronExpression = reqJson.getString("cronExpression");
        Boolean isPause = reqJson.getBoolean("isPause");
        String jobName = reqJson.getString("jobName");
        String methodName = reqJson.getString("methodName");
        String params = reqJson.getString("params");
        String remark = reqJson.getString("remark");

        QuartzJob job = new QuartzJob();
        job.setBeanName(beanName);
        job.setCronExpression(cronExpression);
        job.setIsPause(isPause);
        job.setMethodName(methodName);
        job.setParams(params);
        job.setJobName(jobName);
        job.setRemark(remark);
        job.setUpdateTime(new Date());

        job.save();
        renderJson(job);
    }

    /**
     * 修改定时任务
     */
    @ActionKey("api/jobs/update")
    public void update(){
        String json = HttpKit.readData(getRequest());
        JSONObject reqJson = JSON.parseObject(json);
        Long id = reqJson.getLong("id");
        String beanName = reqJson.getString("beanName");
        String cronExpression = reqJson.getString("cronExpression");
        Boolean isPause = reqJson.getBoolean("isPause");
        String jobName = reqJson.getString("jobName");
        String methodName = reqJson.getString("methodName");
        String params = reqJson.getString("params");
        String remark = reqJson.getString("remark");

        QuartzJob job = (QuartzJob) quartzJobService.findById(id);
        job.setBeanName(beanName);
        job.setCronExpression(cronExpression);
        job.setIsPause(isPause);
        job.setMethodName(methodName);
        job.setParams(params);
        job.setJobName(jobName);
        job.setRemark(remark);
        job.setUpdateTime(new Date());
        job.update();
        renderJson(job);
    }

    /**
     * 删除定时任务
     */
    @ActionKey("api/jobs/del")
    public void delete(){
        Long id = getParaToLong(0);
        quartzJobService.deleteById(id);
        renderJson("删除定时任务");
    }

    /**
     * 执行定时任务
     */
    @ActionKey("api/jobs/exec")
    public void execution(){
        Long id = getParaToLong(0);
        QuartzJob job = (QuartzJob) quartzJobService.findById(id);
        JobKey jobKey = JobKey.jobKey(job.getBeanName(), job.getBeanName());
        try {
            QuartzPlugin.scheduler.triggerJob(jobKey);
        } catch (SchedulerException e) {
            e.printStackTrace();
        }
        renderNull();
    }

    /**
     * 更改定时任务状态
     */
    @ActionKey("api/jobs/updatepause")
    public void updateIsPause(){
        Long id = getParaToLong(0);
        QuartzJob job = (QuartzJob) quartzJobService.findById(id);
        JobKey jobKey = JobKey.jobKey(job.getBeanName(), job.getBeanName());
        try {
            if (job.getIsPause()){
                QuartzPlugin.scheduler.resumeJob(jobKey);
                job.setIsPause(false);
            } else {
                QuartzPlugin.scheduler.pauseJob(jobKey);
                job.setIsPause(true);
            }
            job.update();
        } catch (SchedulerException e) {
            e.printStackTrace();
        }
        renderNull();
    }

}
