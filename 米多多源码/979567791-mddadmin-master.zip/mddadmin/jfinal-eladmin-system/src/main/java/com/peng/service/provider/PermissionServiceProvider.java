package com.peng.service.provider;

import com.jfinal.aop.Inject;
import com.peng.model.Permission;
import com.peng.model.Role;
import com.peng.model.User;
import com.peng.service.PermissionService;
import com.peng.service.RoleService;
import com.peng.service.RolesPermissionsService;
import com.peng.service.UserService;
import com.peng.service.dto.PermissionDTO;
import com.peng.service.dto.RoleDTO;
import org.apache.commons.lang3.StringUtils;

import java.util.*;


public class PermissionServiceProvider extends BaseServiceProvider<Permission> implements PermissionService {

    @Inject
    private UserService userService;

    @Inject
    private RoleService roleService;

    @Inject
    private RolesPermissionsService rolesPermissionsService;

    @Override
    public void untiedPermission(Long permissionId) {
        List<Role> roles = roleService.findByPermissionId(permissionId);
        for (Role role : roles) {
            rolesPermissionsService.deleteByRoleIdAndPermissionId(role.getId(),permissionId);
        }
    }

    @Override
    public List<PermissionDTO> findPermissionListByUserId(long userId) {
        Set<PermissionDTO> permissions = new HashSet<>();
        List<RoleDTO> roleDTOList = roleService.findByUserId(userId);
        for (RoleDTO role : roleDTOList) {
            List<PermissionDTO> rolePermissions = queryByRoleId(role.getId());
            if (rolePermissions != null) {
                permissions.addAll(rolePermissions);
            }
        }

        return new ArrayList<>(permissions);
    }

    @Override
    public boolean hasPermission(long userId, String actionKey) {
        User user = (User) userService.findById(userId);
        if (user.getIsAdmin() == 1l){
            return true;
        }
        if (user == null || user.getEnabled() == 0l) {
            return false;
        }

        List<PermissionDTO> permissions = findPermissionListByUserId(userId);
        if (permissions == null || permissions.isEmpty()) {
            return false;
        }

        for (PermissionDTO permission : permissions) {
            if (actionKey.equals(permission.getActionKey())) {
                return true;
            }
        }

        return false;
    }

    @Override
    public List<PermissionDTO> queryByRoleId(Long roleId) {
        List<Permission> list = DAO.find("select b.* from roles_permissions a left join permission b on a.permission_id = b.id where a.role_id = ?",roleId);
        List<PermissionDTO> dtoList = new ArrayList<>();
        for (Permission arg0: list) {
            PermissionDTO permissionDTO = new PermissionDTO();
            permissionDTO.setId(arg0.getId());
            permissionDTO.setName(arg0.getName());
            permissionDTO.setPid(arg0.getPid());
            permissionDTO.setAlias(arg0.getAlias());
            permissionDTO.setCreateTime(arg0.getCreateTime());
            permissionDTO.setChildren(new ArrayList<PermissionDTO>());
            permissionDTO.setActionKey(arg0.getActionKey());
            dtoList.add(permissionDTO);
        }
        return  dtoList;
    }

//    @Override
//    public Map buildTree(List permissionDTOS) {
//        return null;
//    }

    @Override
    public Map buildTree(List<PermissionDTO> permissionDTOS) {
        List<PermissionDTO> trees = new ArrayList<PermissionDTO>();

        for (PermissionDTO permissionDTO : permissionDTOS) {

            if ("0".equals(permissionDTO.getPid().toString())) {
                trees.add(permissionDTO);
            }

            for (PermissionDTO it : permissionDTOS) {
                if (it.getPid().equals(permissionDTO.getId())) {
                    if (permissionDTO.getChildren() == null) {
                        permissionDTO.setChildren(new ArrayList<PermissionDTO>());
                    }
                    permissionDTO.getChildren().add(it);
                }
            }
        }

        Integer totalElements = permissionDTOS!=null?permissionDTOS.size():0;

        Map map = new HashMap();
        map.put("content",trees.size() == 0?permissionDTOS:trees);
        map.put("totalElements",totalElements);
        return map;
    }

    @Override
    public List<PermissionDTO> queryAll(String name) {
        List<Object> para = new ArrayList<Object>();
        StringBuffer sql = new StringBuffer();
        sql.append("select * from permission where 1=1 ");
        if (StringUtils.isNotBlank(name)){
            sql.append(" and name like ?");
            para.add("%"+name+"%");
        }
        List<Permission> menus = DAO.find(sql.toString(),para.toArray());
        List<PermissionDTO> list = new ArrayList<>();
        for (Permission arg0 : menus) {
            PermissionDTO permissionDTO = new PermissionDTO();
            permissionDTO.setId(arg0.getId());
            permissionDTO.setName(arg0.getName());
            permissionDTO.setPid(arg0.getPid());
            permissionDTO.setAlias(arg0.getAlias());
            permissionDTO.setCreateTime(arg0.getCreateTime());
            list.add(permissionDTO);
        }
        return list;
    }

    @Override
    public List<Permission> findByPid(long pid) {
        return DAO.find("select * from permission where pid = ?",pid);
    }

//    @Override
//    public Object getPermissionTree(List list) {
//        return null;
//    }

    @Override
    public Object getPermissionTree(List<Permission> permissions) {
        List<Map<String,Object>> list = new LinkedList<>();
        permissions.forEach(permission -> {
                    if (permission!=null){
                        List<Permission> permissionList = findByPid(permission.getId());
                        Map<String,Object> map = new HashMap<>();
                        map.put("id",permission.getId());
                        map.put("label",permission.getAlias());
                        if(permissionList!=null && permissionList.size()!=0){
                            map.put("children",getPermissionTree(permissionList));
                        }
                        list.add(map);
                    }
                }
        );
        return list;
    }
}