package com.peng.modules.system.rest;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.jfinal.aop.Inject;
import com.jfinal.core.ActionKey;
import com.jfinal.core.Controller;
import com.jfinal.kit.HttpKit;
import com.jfinal.plugin.activerecord.Page;
import com.peng.model.Dict;
import com.peng.service.DictService;
import com.peng.service.dto.DictDTO;
import com.peng.utils.PageUtil;

/**
 * Created by wupeng on 2019/4/19.
 */
public class DictController extends Controller {

    @Inject
    private DictService dictService;

    /**
     * 查询字典
     */
    @ActionKey("api/dict/query")
    public void query(){
        String name = getPara("name");
        String remark = getPara("remark");
        Integer pageNumber = getParaToInt("page");
        Integer size = getParaToInt("size");
        Page<DictDTO> page = dictService.queryAll(name,remark,pageNumber,size);
        renderJson(PageUtil.toPage(page));
    }

    /**
     * 新增字典
     */
    @ActionKey("api/dict/add")
    public void add(){
        String json = HttpKit.readData(getRequest());
        JSONObject reqJson = JSON.parseObject(json);
        String name = reqJson.getString("name");
        String remark = reqJson.getString("remark");

        Dict dict = new Dict();
        dict.setName(name);
        dict.setRemark(remark);
        dict.save();
        renderJson(dict);
    }

    /**
     * 修改字典
     */
    @ActionKey("api/dict/update")
    public void update(){
        String json = HttpKit.readData(getRequest());
        JSONObject reqJson = JSON.parseObject(json);
        Long id = reqJson.getLong("id");
        String name = reqJson.getString("name");
        String remark = reqJson.getString("remark");

        Dict dict = (Dict) dictService.findById(id);
        dict.setName(name);
        dict.setRemark(remark);
        dict.update();
        renderJson(dict);
    }

    /**
     * 删除字典
     */
    @ActionKey("api/dict/del")
    public void delete(){
        Long id = getParaToLong(0);
        dictService.deleteById(id);
        renderJson("删除字典");
    }

}
