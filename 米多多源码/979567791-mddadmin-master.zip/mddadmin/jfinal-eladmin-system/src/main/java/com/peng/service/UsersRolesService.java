package com.peng.service;

import com.jfinal.plugin.activerecord.Page;
import com.peng.model.UsersRoles;

import java.util.List;

public interface UsersRolesService<UsersRoles>  extends BaseService  {
    void deleteByUserId(Long userId);
}