package com.peng.interceptor;

import com.auth0.jwt.JWT;
import com.jfinal.aop.Inject;
import com.jfinal.aop.Interceptor;
import com.jfinal.aop.Invocation;
import com.jfinal.core.Controller;
import com.peng.service.PermissionService;

import java.util.ArrayList;

/**
 * Created by wupeng on 2019/4/17.
 */
public class AuthInterceptor implements Interceptor {
    @Inject
    private PermissionService permissionService;

    public static ArrayList<String> excludes = new ArrayList<String>();

    static {
        excludes.add("/auth/login");
        excludes.add("/auth/info");
        excludes.add("/api/menus/build");
        excludes.add("/api/aliPay/return");
        excludes.add("/api/aliPay/notify");
    }

    public void intercept(Invocation inv) {

        String uri = inv.getActionKey();

        for (String pattern : excludes) {
            if (uri.contains(pattern)) {
                inv.invoke();
                return;
            }
        }

        Controller controller = inv.getController();
        String token = controller.getHeader("Authorization");
        if (token == null){
            controller.renderError(405);
            return;
        }
        Long userId = JWT.decode(token).getClaim("id").asLong();
        if (userId == null){
            controller.renderError(405);
            return;
        }

        if (!permissionService.hasPermission(userId, inv.getActionKey())) {
            controller.renderError(405);
            return;
        }

        inv.invoke();

    }
}
