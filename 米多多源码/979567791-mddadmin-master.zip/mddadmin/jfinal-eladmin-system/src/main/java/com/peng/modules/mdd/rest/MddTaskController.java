package com.peng.modules.mdd.rest;

import com.alibaba.fastjson.JSON;
import com.jfinal.aop.Inject;
import com.jfinal.core.ActionKey;
import com.jfinal.core.Controller;
import com.jfinal.kit.HttpKit;
import com.jfinal.plugin.activerecord.Page;
import com.peng.config.Constants;
import com.peng.enums.MyPublishEnum;
import com.peng.enums.MyTaskEnum;
import com.peng.mdd.model.*;
import com.peng.mdd.service.MddMyTaskService;
import com.peng.mdd.service.MddTaskService;
import com.peng.mdd.service.MddUserService;
import com.peng.utils.PageUtil;
import org.apache.commons.lang3.StringUtils;

import java.util.List;

/**
* @author jie1
* @date 2019-05-15
*/
public class MddTaskController extends Controller {

    @Inject
    private MddTaskService mddTaskService;
    @Inject
    private MddUserService userService;
    @Inject
    private MddMyTaskService myTaskService;

    /**
    * 查询
    */
    @ActionKey("api/mdd/task/query")
    public void query(){
        Long id = getParaToLong("id");
        String title = getPara("title");
        Integer state = getParaToInt("state");
        Integer pageNumber = getParaToInt("page");
        Integer pageSize = getParaToInt("size");
        Page<MddTask> page = mddTaskService.list(pageNumber,pageSize,title,state,id);
        renderJson(PageUtil.toPage(page));
    }

    /**
    * 新增
    */
    @ActionKey("api/mdd/task/add")
    public void add(){
        String json = HttpKit.readData(getRequest());
        MddTask mddTask = JSON.parseObject(json,MddTask.class);
        mddTask.save();

        renderJson(mddTask);
    }

    /**
    * 修改
    */
    @ActionKey("api/mdd/task/update")
    public void update(){
        String json = HttpKit.readData(getRequest());
        MddTask mddTask = JSON.parseObject(json,MddTask.class);
        //mddTask.setState(null);
        Boolean flag = mddTask.update();

        renderJson(mddTask);
    }

    /**
    * 删除
    */
    @ActionKey("api/mdd/task/del")
    public void delete(){
        Long id = getParaToLong(0);
        MddTask task = MddTask.dao.findById(id);
        task.setDelState(1);
        task.update();
        renderNull();
    }

    /**
     * 待审核统计
     */
    @ActionKey("api/mdd/task/statistics")
    public void statistics(){
        MddTask task = MddTask.dao.findFirst("select count(*) as count from mdd_task where state = 1 and del_state = 0");
        renderJson(task.getInt("count"));
    }

    /**
     * 任务详情
     */
    @ActionKey("api/mdd/task/detail")
    public void detail() {


        String task_id = getPara(0);
        MddTask task = MddTask.dao.findFirst("select a.*,b.name as type_name,c.phone from mdd_task a left join mdd_task_type b on a.task_type_id = b.id left join mdd_user c on a.uid = c.id where a.id = ?",task_id);
        if (task == null) {
            renderNull();
            return;
        }
        StringBuffer explainImgSb = new StringBuffer();
        String[] explainImgArr = task.getExplainImg().split(",");
        for (String img: explainImgArr) {
            explainImgSb.append(Constants.QINIU_DOMAIN+img+",");
        }
        explainImgSb.deleteCharAt(explainImgSb.length()-1);
        task.setExplainImg(explainImgSb.toString());



        List<MddTaskStep> stepList =  MddTaskStep.dao.find("select * from mdd_task_step where task_id = ?",task.getId());
        for (MddTaskStep step: stepList) {
            if (StringUtils.isNotBlank(step.getExplainImg())) {
                step.setExplainImg(Constants.QINIU_DOMAIN + step.getExplainImg());
            }
        }
        task.put("step_list", stepList);

        renderJson(task);
    }

    /**
     * 通过审核
     */
    @ActionKey("api/mdd/task/pass")
    public void pass() {
        String task_id = getPara(0);
        MddTask task = MddTask.dao.findById(task_id);
        task.setState(3);
        task.update();

        renderNull();
    }

    /**
     * 不通过审核
     */
    @ActionKey("api/mdd/task/fail")
    public void fail() {
        String task_id = getPara("task_id");
        String reason = getPara("reason");
        MddTask task = MddTask.dao.findById(task_id);
        task.setState(2);
        task.setRejectReason(reason);
        task.update();

        renderNull();
    }

    /**
     * 完成任务
     */
    @ActionKey("api/mdd/task/finish")
    public void finish() {
        String taskId = getPara("task_id");
        String user_id = getPara("uid");

        MddUser user = (MddUser) userService.findById(user_id);
        if (user == null) {
            renderNull();
            return;
        }

        //是否是这个人接的任务 并且任务状态正常
        MddMyTask mmt = myTaskService.findByTaskIdWithUid(taskId,user_id);
        if (mmt == null) {
            renderNull();
            return;
        }
        if (!(mmt.getState() == MyTaskEnum.待审核.getCode() || mmt.getState() == MyTaskEnum.未通过.getCode())) {
            renderNull();
            return;
        }

        //是否是这个人发布的任务  并且任务状态正常
        MddTask task = mddTaskService.findById(taskId);
        if (task == null || !(task.getState() == MyPublishEnum.进行中.getCode() || task.getState() == MyPublishEnum.已暂停.getCode())) {
            renderNull();
            return;
        }

        if (task.getUid().toString().equals(user_id)) {
            renderNull();
            return;
        }

        MddAppeal appeal = MddAppeal.dao.findFirst("select * from mdd_appeal where task_id = ? and uid = ? limit 1",taskId,user_id);
        appeal.setIsSolve(1);
        appeal.update();
        mddTaskService.finish(user, task, mmt);

        renderNull();
    }
}
