package com.peng.modules.mdd.rest;

import com.alibaba.fastjson.JSON;
import com.jfinal.aop.Inject;
import com.jfinal.core.ActionKey;
import com.jfinal.core.Controller;
import com.jfinal.kit.HttpKit;
import com.jfinal.plugin.activerecord.Page;
import com.peng.mdd.model.MddComplain;
import com.peng.mdd.service.MddComplainService;
import com.peng.utils.PageUtil;

/**
* @author jie1
* @date 2019-06-14
*/
public class MddComplainController extends Controller {

    @Inject
    private MddComplainService mddComplainService;

    /**
    * 查询
    */
    @ActionKey("api/mdd/complain/query")
    public void query(){
        Long task_id = getParaToLong("task_id");
        Long uid = getParaToLong("uid");
        Integer pageNumber = getParaToInt("page");
        Integer pageSize = getParaToInt("size");
        Page<MddComplain> page = mddComplainService.list(pageNumber,pageSize,task_id,uid);
        renderJson(PageUtil.toPage(page));
    }

    /**
    * 新增
    */
    @ActionKey("api/mdd/complain/add")
    public void add(){
        String json = HttpKit.readData(getRequest());
        MddComplain mddComplain = JSON.parseObject(json,MddComplain.class);
        mddComplain.save();

        renderJson(mddComplain);
    }

    /**
    * 修改
    */
    @ActionKey("api/mdd/complain/update")
    public void update(){
        String json = HttpKit.readData(getRequest());
        MddComplain mddComplain = JSON.parseObject(json,MddComplain.class);
        mddComplain.update();

        renderJson(mddComplain);
    }

    /**
    * 删除
    */
    @ActionKey("api/mdd/complain/del")
    public void delete(){
        Long id = getParaToLong(0);
        mddComplainService.deleteById(id);
        renderNull();
    }
}
