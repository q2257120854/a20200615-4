package com.peng.service;

import com.jfinal.plugin.activerecord.Page;
import com.peng.service.dto.DictDTO;

public interface DictService<Dict>  extends BaseService {
    Page<DictDTO> queryAll(String name, String remark, Integer pageNumber, Integer size);
}