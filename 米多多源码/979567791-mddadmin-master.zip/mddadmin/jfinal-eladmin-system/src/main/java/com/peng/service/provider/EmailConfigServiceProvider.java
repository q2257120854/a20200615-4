package com.peng.service.provider;

import com.peng.model.EmailConfig;
import com.peng.service.EmailConfigService;


public class EmailConfigServiceProvider extends BaseServiceProvider<EmailConfig> implements EmailConfigService {

}