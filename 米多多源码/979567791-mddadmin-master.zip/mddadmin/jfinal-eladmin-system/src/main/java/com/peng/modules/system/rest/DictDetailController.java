package com.peng.modules.system.rest;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.jfinal.aop.Inject;
import com.jfinal.core.ActionKey;
import com.jfinal.core.Controller;
import com.jfinal.kit.HttpKit;
import com.jfinal.plugin.activerecord.Page;
import com.peng.model.DictDetail;
import com.peng.service.DictDetailService;
import com.peng.service.dto.DictDetailDTO;
import com.peng.utils.PageUtil;

/**
 * Created by wupeng on 2019/4/19.
 */
public class DictDetailController extends Controller {

    @Inject
    private DictDetailService dictDetailService;

    /**
     * 查询字典详情
     */
    @ActionKey("api/dictDetail/query")
    public void query(){
        String dictName = getPara("dictName");
        String label = getPara("label");
        Integer pageNumber = getParaToInt("page");
        Integer size = getParaToInt("size");
        Page<DictDetailDTO> page = dictDetailService.queryAll(dictName,label,pageNumber,size);
        renderJson(PageUtil.toPage(page));
    }

    /**
     * 新增字典详情
     */
    @ActionKey("api/dictDetail/add")
    public void add(){
        String json = HttpKit.readData(getRequest());
        JSONObject reqJson = JSON.parseObject(json);
        String value = reqJson.getString("value");
        String label = reqJson.getString("label");
        String sort = reqJson.getString("sort");
        Long dictId = reqJson.getJSONObject("dict").getLong("id");

        DictDetail dictDetail = new DictDetail();
        dictDetail.setLabel(label);
        dictDetail.setValue(value);
        dictDetail.setSort(sort);
        dictDetail.setDictId(dictId);
        dictDetail.save();
        renderJson(dictDetail);
    }

    /**
     * 修改字典详情
     */
    @ActionKey("api/dictDetail/update")
    public void update(){
        String json = HttpKit.readData(getRequest());
        JSONObject reqJson = JSON.parseObject(json);
        Long id = reqJson.getLong("id");
        String value = reqJson.getString("value");
        String label = reqJson.getString("label");
        String sort = reqJson.getString("sort");
        Long dictId = reqJson.getJSONObject("dict").getLong("id");

        DictDetail dictDetail = (DictDetail) dictDetailService.findById(id);
        dictDetail.setLabel(label);
        dictDetail.setValue(value);
        dictDetail.setSort(sort);
        dictDetail.setDictId(dictId);
        dictDetail.update();
        renderJson(dictDetail);
    }

    /**
     * 删除字典详情
     */
    @ActionKey("api/dictDetail/del")
    public void delete(){
        Long id = getParaToLong(0);
        dictDetailService.deleteById(id);
        renderJson("删除字典详情");
    }

}
