
package com.peng.modules.security.rest;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.auth0.jwt.JWT;
import com.jfinal.aop.Before;
import com.jfinal.aop.Inject;
import com.jfinal.core.Controller;
import com.jfinal.ext.interceptor.GET;
import com.jfinal.kit.HttpKit;
import com.peng.model.JwtUser;
import com.peng.model.User;
import com.peng.service.PermissionService;
import com.peng.service.RoleService;
import com.peng.service.UserService;
import com.peng.service.dto.PermissionDTO;
import com.peng.service.dto.RoleDTO;
import com.peng.utils.JwtTokenUtil;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;

public class AuthenticationController extends Controller {
    @Inject
    private UserService userService;
    @Inject
    private RoleService roleService;
    @Inject
    private PermissionService permissionService;

    public AuthenticationController() {
    }

    public void login() {
        String json = HttpKit.readData(this.getRequest());
        JSONObject reqJson = JSON.parseObject(json);
        String username = reqJson.getString("username");
        String password = reqJson.getString("password");
        User user = this.userService.login(username, password);
        if(user == null) {
            this.renderJson("账号或者密码错误");
        } else {
            JwtUser jwtUser = new JwtUser();
            jwtUser.setId(user.getId());
            jwtUser.setUsername(user.getUsername());
            jwtUser.setPassword(user.getPassword());
            String token = JwtTokenUtil.createJWT(600000L, jwtUser);
            HashMap map = new HashMap();
            map.put("token", token);
            user.remove("password");
            HashSet roles = new HashSet();
            List<RoleDTO> roleDTOList = this.roleService.findByUserId(user.getId());
            for (RoleDTO dto : roleDTOList) {
                List<PermissionDTO> perList = this.permissionService.queryByRoleId(dto.getId());

                for (PermissionDTO perDto : perList) {
                    roles.add(perDto.getName());
                }
            }

            user.put("roles", roles);
            map.put("user", user);
            this.renderJson(map);
        }
    }

    @Before({GET.class})
    public void info() {
        String token = this.getHeader("Authorization");
        Long userId = JWT.decode(token).getClaim("id").asLong();
        User user = (User) this.userService.findById(userId);
        user.remove("password");
        HashSet roles = new HashSet();
        List<RoleDTO> roleDTOList = this.roleService.findByUserId(user.getId());
        Iterator var6 = roleDTOList.iterator();

        for (RoleDTO dto : roleDTOList) {
            List<PermissionDTO> perList = this.permissionService.queryByRoleId(dto.getId());

            for (PermissionDTO perDto : perList) {
                roles.add(perDto.getName());
            }
        }

        user.put("roles", roles);
        this.renderJson(user);
    }
}
