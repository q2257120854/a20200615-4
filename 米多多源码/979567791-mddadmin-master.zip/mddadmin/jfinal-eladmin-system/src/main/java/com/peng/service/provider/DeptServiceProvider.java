package com.peng.service.provider;

import com.peng.model.Dept;
import com.peng.service.DeptService;


public class DeptServiceProvider extends BaseServiceProvider<Dept> implements DeptService {

}