package com.peng.service;

public interface DeptService<Dept>  extends BaseService {


}