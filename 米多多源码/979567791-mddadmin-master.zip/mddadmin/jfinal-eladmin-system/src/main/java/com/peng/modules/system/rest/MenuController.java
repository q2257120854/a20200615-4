package com.peng.modules.system.rest;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.auth0.jwt.JWT;
import com.jfinal.aop.Before;
import com.jfinal.aop.Inject;
import com.jfinal.core.ActionKey;
import com.jfinal.core.Controller;
import com.jfinal.ext.interceptor.GET;
import com.jfinal.kit.HttpKit;
import com.peng.model.Menu;
import com.peng.model.User;
import com.peng.service.MenuService;
import com.peng.service.RoleService;
import com.peng.service.UserService;
import com.peng.service.dto.MenuDTO;
import com.peng.service.dto.RoleDTO;

import java.util.Date;
import java.util.List;

/**
 * Created by wupeng on 2019/4/16.
 */
public class MenuController extends Controller {

    @Inject
    private UserService userService;

    @Inject
    private MenuService menuService;

    @Inject
    private RoleService roleService;

    /**
     * 构建前端路由所需要的菜单
      */
    @ActionKey("api/menus/build")
    public void buildMenus(){
        String token = getHeader("Authorization");
        Long userId = JWT.decode(token).getClaim("id").asLong();
        User user = (User) userService.findById(userId);

        List<RoleDTO> roleList = roleService.findByUserId(userId);
        List<MenuDTO> menuDTOList =menuService.findByRoles(roleList);
        List<MenuDTO> menuDTOTree = (List<MenuDTO>)menuService.buildTree(menuDTOList).get("content");

        renderJson(menuService.buildMenus(menuDTOTree));
    }

    /**
     * 返回全部的菜单
     */
    @ActionKey("api/menus/tree")
    public void getMenuTree(){
        renderJson(menuService.getMenuTree(menuService.findByPid(0L)));
    }

    /**
     * 查询菜单
     */
    @ActionKey("api/menus/query")
    public void query(){
        String name = getPara("name");
        List<MenuDTO> menuDTOList = menuService.queryAll(name);
        renderJson(menuService.buildTree(menuDTOList));
    }

    /**
     * 新增菜单
     */
    @ActionKey("api/menus/add")
    public void add(){
        String json = HttpKit.readData(getRequest());
        JSONObject reqJson = JSON.parseObject(json);
        String name = reqJson.getString("name");
        String icon = reqJson.getString("icon");
        String component = reqJson.getString("component");
        Boolean iframe = reqJson.getBoolean("iframe");
        String path = reqJson.getString("path");
        Long pid = reqJson.getLong("pid");
        //String roles = reqJson.getString("roles");
        Long sort = reqJson.getLong("sort");

        Menu menu = new Menu();
        menu.setName(name);
        menu.setIcon(icon);
        menu.setComponent(component);
        menu.setIFrame(iframe);
        menu.setPath(path);
        menu.setPid(pid);
        menu.setSort(sort);
        menu.setCreateTime(new Date());
        menu.save();
        renderJson(menu);
    }

    /**
     * 修改菜单
     */
    @ActionKey("api/menus/update")
    public void update(){
        String json = HttpKit.readData(getRequest());
        JSONObject reqJson = JSON.parseObject(json);
        String id = reqJson.getString("id");
        String name = reqJson.getString("name");
        String icon = reqJson.getString("icon");
        String component = reqJson.getString("component");
        Boolean iframe = reqJson.getBoolean("iframe");
        String path = reqJson.getString("path");
        Long pid = reqJson.getLong("pid");
        //String roles = reqJson.getString("roles");
        Long sort = reqJson.getLong("sort");

        Menu menu = (Menu) menuService.findById(id);
        menu.setName(name);
        menu.setIcon(icon);
        menu.setComponent(component);
        menu.setIFrame(iframe);
        menu.setPath(path);
        menu.setPid(pid);
        menu.setSort(sort);
        menu.update();
        renderJson(menu);
    }

    /**
     * 删除菜单
     */
    @ActionKey("api/menus/del")
    public void delete(){
        Long id = getParaToLong(0);
        List<Menu> menuList = menuService.findByPid(id);

        // 特殊情况，对级联删除进行处理
        for (Menu menu : menuList) {
            menuService.untiedMenu(menu.getId());
            menuService.deleteById(menu.getId());
        }
        menuService.untiedMenu(id);
        menuService.deleteById(id);

        renderJson("删除菜单");
    }

}
