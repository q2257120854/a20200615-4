package com.peng.modules.mdd.rest;

import com.alibaba.fastjson.JSON;
import com.jfinal.aop.Inject;
import com.jfinal.core.ActionKey;
import com.jfinal.core.Controller;
import com.jfinal.kit.HttpKit;
import com.jfinal.plugin.activerecord.Page;
import com.peng.mdd.model.MddTaskType;
import com.peng.mdd.service.MddTaskTypeService;
import com.peng.utils.PageUtil;

/**
* @author jie1
* @date 2019-05-15
*/
public class MddTaskTypeController extends Controller {

    @Inject
    private MddTaskTypeService mddTaskTypeService;

    /**
    * 查询
    */
    @ActionKey("api/mdd/taskType/query")
    public void query(){
        String name = getPara("name");
        Integer pageNumber = getParaToInt("page");
        Integer pageSize = getParaToInt("size");
        Page<MddTaskType> page = mddTaskTypeService.list(pageNumber,pageSize,name);
        renderJson(PageUtil.toPage(page));
    }

    /**
    * 新增
    */
    @ActionKey("api/mdd/taskType/add")
    public void add(){
        String json = HttpKit.readData(getRequest());
        MddTaskType mddTaskType = JSON.parseObject(json,MddTaskType.class);
        mddTaskType.save();

        renderJson(mddTaskType);
    }

    /**
    * 修改
    */
    @ActionKey("api/mdd/taskType/update")
    public void update(){
        String json = HttpKit.readData(getRequest());
        MddTaskType mddTaskType = JSON.parseObject(json,MddTaskType.class);
        mddTaskType.update();

        renderJson(mddTaskType);
    }

    /**
    * 删除
    */
    @ActionKey("api/mdd/taskType/del")
    public void delete(){
        Long id = getParaToLong(0);
        mddTaskTypeService.deleteById(id);
        renderNull();
    }
}
