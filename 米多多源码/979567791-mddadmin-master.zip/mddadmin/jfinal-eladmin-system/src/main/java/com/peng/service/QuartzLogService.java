package com.peng.service;

import com.jfinal.plugin.activerecord.Page;
import com.peng.model.QuartzLog;

import java.util.List;

public interface QuartzLogService<QuartzLog>  extends BaseService  {



}