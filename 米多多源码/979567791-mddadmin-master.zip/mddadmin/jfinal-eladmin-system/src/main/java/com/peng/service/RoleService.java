package com.peng.service;

import com.jfinal.plugin.activerecord.Page;
import com.peng.model.Role;
import com.peng.service.dto.RoleDTO;

import java.util.List;

public interface RoleService<Role>  extends BaseService  {
    RoleDTO queryById(Long id);

    List<RoleDTO> queryAll();

    Page<RoleDTO> queryAll(String name, Integer pageNumber, Integer size);

    List<com.peng.model.Role> findByMenuId(Long id);

    List<com.peng.model.Role> findByPermissionId(Long id);

    List<RoleDTO> findByUserId(Object id);
}