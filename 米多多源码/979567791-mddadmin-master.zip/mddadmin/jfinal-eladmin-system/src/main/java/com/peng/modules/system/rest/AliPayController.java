package com.peng.modules.system.rest;

import com.alibaba.fastjson.JSON;
import com.jfinal.aop.Inject;
import com.jfinal.core.ActionKey;
import com.jfinal.core.Controller;
import com.jfinal.kit.HttpKit;
import com.jfinal.plugin.activerecord.Db;
import com.jfinal.plugin.activerecord.IAtom;
import com.peng.config.DataSource;
import com.peng.enums.AccountDetailEnum;
import com.peng.enums.AliPayStatusEnum;
import com.peng.mdd.model.MddAccountDetail;
import com.peng.mdd.model.MddTrade;
import com.peng.mdd.model.MddUser;
import com.peng.mdd.service.MddUserService;
import com.peng.model.AlipayConfig;
import com.peng.model.vo.TradeVo;
import com.peng.service.AlipayConfigService;
import com.peng.utils.AlipayUtils;
import com.peng.utils.PushUtils;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.Date;
import java.util.Map;

/**
 * 支付宝
 */
public class AliPayController extends Controller{


    @Inject
    private AlipayConfigService alipayConfigService;
    @Inject
    private MddUserService userService;

    @ActionKey("api/aliPay")
    public void get(){
        AlipayConfig alipayConfig = alipayConfigService.find();
        renderJson(alipayConfig);
    }

    /**
     * 配置支付宝
     */
    @ActionKey("api/config/aliPay")
    public void payConfig(){
        String json = HttpKit.readData(getRequest());
        AlipayConfig alipayConfig = JSON.parseObject(json,AlipayConfig.class);
        alipayConfig.setId(1L);
        alipayConfig.update();
        renderNull();
    }

    /**
     * 支付宝PC网页支付
     */
    @ActionKey("api/aliPay/toPayAsPC")
    public void toPayAsPC() throws Exception{
        String json = HttpKit.readData(getRequest());
        TradeVo trade = JSON.parseObject(json,TradeVo.class);
        AlipayConfig alipay = alipayConfigService.find();
        trade.setOutTradeNo(AlipayUtils.getOrderCode());
        String payUrl = alipayConfigService.toPayAsPC(alipay,trade);
        renderJson(payUrl);
    }

    /**
     * 支付宝手机网页支付
     */
    @ActionKey("api/aliPay/toPayAsWeb")
    public void toPayAsWeb() throws Exception{
        String json = HttpKit.readData(getRequest());
        TradeVo trade = JSON.parseObject(json,TradeVo.class);
        AlipayConfig alipay = alipayConfigService.find();
        trade.setOutTradeNo(AlipayUtils.getOrderCode());
        String payUrl = alipayConfigService.toPayAsWeb(alipay,trade);
        renderJson(payUrl);
    }

    /**
     * 支付之后跳转的链接
     */
    @ActionKey("api/aliPay/return")
    public void returnPage() throws Exception {
        HttpServletRequest request = getRequest();
        HttpServletResponse response = getResponse();
        AlipayConfig alipay = alipayConfigService.find();
        response.setContentType("text/html;charset=" + alipay.getCharset());
        //内容验签，防止黑客篡改参数
        if(AlipayUtils.rsaCheck(request,alipay)){
            //商户订单号
            String outTradeNo = new String(request.getParameter("out_trade_no").getBytes("ISO-8859-1"),"UTF-8");
            //支付宝交易号
            String tradeNo = new String(request.getParameter("trade_no").getBytes("ISO-8859-1"),"UTF-8");

            /**
             * 根据业务需要返回数据，这里统一返回OK
             */
//            MddTrade mddTrade = MddTrade.dao.findFirst("select * from mdd_trade where out_trade_no = ?",outTradeNo);
//            mddTrade.setTradeNo(tradeNo);
//            mddTrade.setState(0);
//            mddTrade.setSuccessTime(new Date());
//            mddTrade.update();
//
//            MddUser user = MddUser.dao.findById(mddTrade.getUid());
//            user.setMiCoin(user.getMiCoin() + Float.valueOf(mddTrade.getTotalAmount()));
//            user.update();
            renderJson("商户订单号"+outTradeNo+"  "+"第三方交易号"+tradeNo);
            return;
        }else{
            /**
             * 根据业务需要返回数据
             */
            renderError(405);
            return;
        }
    }

    /**
     * 支付异步通知(要公网访问)，接收异步通知，检查通知内容app_id、out_trade_no、total_amount是否与请求中的一致，根据trade_status进行后续业务处理
     */
    @ActionKey("api/aliPay/notify")
    public void notify1() throws Exception{
        HttpServletRequest request = getRequest();
        AlipayConfig alipay = alipayConfigService.find();
        Map<String, String[]> parameterMap = request.getParameterMap();
        StringBuilder notifyBuild = new StringBuilder("/****************************** pay notify ******************************/\n");
        parameterMap.forEach((key, value) -> notifyBuild.append(key + "=" + value[0] + "\n") );
        //内容验签，防止黑客篡改参数
        if (AlipayUtils.rsaCheck(request,alipay)) {
            //交易状态
            String tradeStatus = new String(request.getParameter("trade_status").getBytes("ISO-8859-1"),"UTF-8");
            // 商户订单号
            String outTradeNo = new String(request.getParameter("out_trade_no").getBytes("ISO-8859-1"),"UTF-8");
            //支付宝交易号
            String tradeNo = new String(request.getParameter("trade_no").getBytes("ISO-8859-1"),"UTF-8");
            //付款金额
            String totalAmount = new String(request.getParameter("total_amount").getBytes("ISO-8859-1"),"UTF-8");
            //验证
            if(tradeStatus.equals(AliPayStatusEnum.SUCCESS.getValue())||tradeStatus.equals(AliPayStatusEnum.FINISHED.getValue())){
                /**
                 * 验证通过后应该根据业务需要处理订单
                 */
                System.out.println("商户订单号"+outTradeNo+"  "+"第三方交易号"+tradeNo);

                Db.use(DataSource.MDD).tx(new IAtom() {
                    @Override
                    public boolean run() throws SQLException {
                        MddTrade mddTrade = MddTrade.dao.findFirst("select * from mdd_trade where out_trade_no = ?",outTradeNo);
                        if (mddTrade.getState().equals(0)){
                            return false;
                        }
                        mddTrade.setTradeNo(tradeNo);
                        mddTrade.setState(0);
                        mddTrade.setSuccessTime(new Date());
                        mddTrade.update();

                        if (mddTrade.getSubject().equals(AccountDetailEnum.米币充值.getMsg())){
                            MddUser user = MddUser.dao.findById(mddTrade.getUid());
                            user.setMiCoin(user.getMiCoin() + Float.valueOf(mddTrade.getTotalAmount()));
                            user.update();
                            MddUser pUser = MddUser.dao.findById(user.getPid());
                            if (pUser != null){
                                Float amount = new BigDecimal(mddTrade.getTotalAmount()).multiply(new BigDecimal(0.01)).setScale(2, BigDecimal.ROUND_HALF_UP).floatValue();
                                userService.income(pUser,amount,AccountDetailEnum.充值奖励.getMsg());
                                PushUtils.push(pUser.getId().toString(), "收入提醒", "充值分红:"+amount);
                            }
                            //添加账户明细
                            MddAccountDetail mad = new MddAccountDetail();
                            mad.setMoney(Float.valueOf(mddTrade.getTotalAmount()));
                            mad.setOp(AccountDetailEnum.米币充值.getMsg());
                            mad.setUid(user.getId());
                            mad.save();
                        }else if (mddTrade.getSubject().equals(AccountDetailEnum.保证金充值.getMsg())){
                            MddUser user = MddUser.dao.findById(mddTrade.getUid());
                            user.setEarnestMoney(user.getEarnestMoney() + Float.valueOf(mddTrade.getTotalAmount()));
                            user.update();
                            //添加账户明细
                            MddAccountDetail mad = new MddAccountDetail();
                            mad.setMoney(Float.valueOf(mddTrade.getTotalAmount()));
                            mad.setOp(AccountDetailEnum.保证金充值.getMsg());
                            mad.setUid(user.getId());
                            mad.save();
                        }
                        return true;
                    }
                });
            }
            renderNull();
            return;
        }
        renderError(405);
    }
}
