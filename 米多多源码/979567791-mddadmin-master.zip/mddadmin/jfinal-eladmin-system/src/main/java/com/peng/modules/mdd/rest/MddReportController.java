package com.peng.modules.mdd.rest;

import com.alibaba.fastjson.JSON;
import com.jfinal.aop.Inject;
import com.jfinal.core.ActionKey;
import com.jfinal.core.Controller;
import com.jfinal.kit.HttpKit;
import com.jfinal.plugin.activerecord.Page;
import com.peng.mdd.model.MddReport;
import com.peng.mdd.service.MddReportService;
import com.peng.utils.PageUtil;

/**
* @author jie1
* @date 2019-06-17
*/
public class MddReportController extends Controller {

    @Inject
    private MddReportService mddReportService;

    /**
    * 查询
    */
    @ActionKey("api/mdd/report/query")
    public void query(){
        Long uid = getParaToLong("uid");
        Long task_id = getParaToLong("task_id");
        Integer pageNumber = getParaToInt("page");
        Integer pageSize = getParaToInt("size");
        Page<MddReport> page = mddReportService.list(pageNumber,pageSize,uid,task_id);
        renderJson(PageUtil.toPage(page));
    }

    /**
    * 新增
    */
    @ActionKey("api/mdd/report/add")
    public void add(){
        String json = HttpKit.readData(getRequest());
        MddReport mddReport = JSON.parseObject(json,MddReport.class);
        mddReport.save();

        renderJson(mddReport);
    }

    /**
    * 修改
    */
    @ActionKey("api/mdd/report/update")
    public void update(){
        String json = HttpKit.readData(getRequest());
        MddReport mddReport = JSON.parseObject(json,MddReport.class);
        mddReport.update();

        renderJson(mddReport);
    }

    /**
    * 删除
    */
    @ActionKey("api/mdd/report/del")
    public void delete(){
        Long id = getParaToLong(0);
        mddReportService.deleteById(id);
        renderNull();
    }
}
