package com.peng.job;

import com.jfinal.plugin.activerecord.Db;
import com.peng.config.DataSource;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

/**
 * 每分钟执行
 *
 * @author Jieven
 * @date 2014-7-7
 */
public class EveryDayJob implements Job {

	@Override
	public void execute(JobExecutionContext jobExecutionContext) throws JobExecutionException {
		// 重置每日提现次数
        Db.use(DataSource.MDD).update("update mdd_user set advance_count = 0");

        // 重置每日暂停次数
        Db.use(DataSource.MDD).update("update mdd_task set pause_count = 0");
    }
}
