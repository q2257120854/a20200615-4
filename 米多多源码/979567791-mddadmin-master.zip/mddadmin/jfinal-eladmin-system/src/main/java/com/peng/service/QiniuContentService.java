package com.peng.service;

import com.jfinal.plugin.activerecord.Page;
import com.peng.model.QiniuContent;

import java.util.List;

public interface QiniuContentService<QiniuContent>  extends BaseService  {

}