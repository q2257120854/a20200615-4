package com.peng.service;

import com.peng.service.dto.PermissionDTO;

import java.util.List;
import java.util.Map;

public interface PermissionService  extends BaseService {

    void untiedPermission(Long permissionId);

    List<PermissionDTO> findPermissionListByUserId(long userId);

    boolean hasPermission(long userId, String actionKey);

    List<PermissionDTO> queryByRoleId(Long roleId);

    Map buildTree(List<PermissionDTO> permissionDTOS);

    List<PermissionDTO> queryAll(String name);

    List<com.peng.model.Permission> findByPid(long pid);

    Object getPermissionTree(List<com.peng.model.Permission> permissions);
}