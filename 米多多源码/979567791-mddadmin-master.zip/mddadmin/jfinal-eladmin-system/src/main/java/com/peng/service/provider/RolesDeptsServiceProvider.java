package com.peng.service.provider;

import com.peng.model.RolesDepts;
import com.peng.service.RolesDeptsService;


public class RolesDeptsServiceProvider extends BaseServiceProvider<RolesDepts> implements RolesDeptsService {

}