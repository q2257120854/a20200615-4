package com.peng.job;

import com.jfinal.aop.Aop;
import com.jfinal.aop.Inject;
import com.jfinal.plugin.activerecord.Db;
import com.jfinal.plugin.activerecord.IAtom;
import com.peng.config.DataSource;
import com.peng.enums.AccountDetailEnum;
import com.peng.enums.MyPublishEnum;
import com.peng.enums.MyTaskEnum;
import com.peng.mdd.model.MddMyTask;
import com.peng.mdd.model.MddTask;
import com.peng.mdd.model.MddUser;
import com.peng.mdd.service.MddMyTaskService;
import com.peng.mdd.service.MddTaskService;
import com.peng.mdd.service.MddUserService;
import org.apache.commons.lang3.time.DateUtils;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import java.sql.SQLException;
import java.util.Date;
import java.util.List;

/**
 * 每分钟执行
 *
 * @author Jieven
 * @date 2014-7-7
 */
public class EveryMinJob implements Job {

    @Inject
    private MddTaskService taskService = Aop.get(MddTaskService.class);
    @Inject
    private MddMyTaskService myTaskService = Aop.get(MddMyTaskService.class);
    @Inject
    private MddUserService userService = Aop.get(MddUserService.class);

	@Override
	public void execute(JobExecutionContext jobExecutionContext) throws JobExecutionException {

        Db.use(DataSource.MDD).tx(new IAtom() {

            @Override
            public boolean run() throws SQLException {

                // TODO 记得删除
                // 重置每日提现次数
                //Db.use(DataSource.MDD).update("update mdd_task set order_time_limit = 1");

                // 重置每日暂停次数
                //Db.use(DataSource.MDD).update("update mdd_task set check_time_limit = 2");

                // TODO 任务到期可以推送提醒发单人
                //任务到期
                List<MddTask> taskList = MddTask.dao.find("select * from mdd_task where end_time < now() and state <> ?",MyPublishEnum.已结束.getCode());
                for (final MddTask task : taskList) {

                    //接单者的任务改为已完成
//                    List<MddMyTask> mmtList = myTaskService.findByTaskId(task.getId());
//                    for (MddMyTask mmt:mmtList) {
//                        taskService.finish(MddUser.dao.findById(mmt.getUid()),task,mmt);
//                    }

                    List<MddMyTask> mmtList = myTaskService.findByTaskId(task.getId());
                    if (mmtList.isEmpty()){
                        MddUser user = MddUser.dao.findById(task.getUid());
                        if (task.getState().equals(MyPublishEnum.已暂停.getCode()) || task.getState().equals(MyPublishEnum.进行中.getCode())){
                            //退回剩余的钱给发布者
                            userService.micoin(user,task.getBalance(), AccountDetailEnum.任务退回.getMsg()+task.getTitle());
                        }else{
                            //退回剩余的钱给发布者
                            userService.micoin(user,task.getBalance() + task.getBalance() * task.getServiceCharge(),AccountDetailEnum.任务退回.getMsg()+task.getTitle());
                        }

                        //修改任务状态
                        task.setState(MyPublishEnum.已结束.getCode());
                        task.update();
                    }

                }

                taskList = MddTask.dao.find("select * from mdd_task where del_state = 0 and state = ?",MyPublishEnum.进行中.getCode());
                for (MddTask task:taskList) {
                    //Db.use(DataSource.MDD).update("delete from mdd_my_task where update_time <= date_sub(now(),interval "+task.getOrderTimeLimit()+" minute) and state = 1 and task_id = ?",task.getId());

                    List<MddMyTask> mmtList = MddMyTask.dao.find("select * from mdd_my_task where task_id = ? and state <> ?",task.getId(), MyTaskEnum.已完成.getCode());
                    for (MddMyTask mmt:mmtList) {
                        if (mmt.getState() == 1){
                            //接单20分钟没上传自动取消
                            Date date = DateUtils.addMinutes(mmt.getUpdateTime(),task.getOrderTimeLimit());
                            if (date.getTime() < new Date().getTime()) {
                                System.out.println("接单"+task.getOrderTimeLimit()+"分钟没上传自动取消"+task.getTitle()+",用户:"+mmt.getUid());
                                mmt.delete();
                            }
                        } else if (mmt.getState() == 2){
                            //24小时未审核自动通过
                            Date date = DateUtils.addHours(mmt.getUpdateTime(),task.getCheckTimeLimit());
                            if (date.getTime() < new Date().getTime()) {
                                taskService.finish(MddUser.dao.findById(mmt.getUid()),task,mmt);
                                System.out.println(task.getCheckTimeLimit()+"小时未审核自动通过"+task.getTitle());
                            }
                        } else if (mmt.getState() == 3){
                            //任务被驳回12小时没上传自动取消
                            Date date = DateUtils.addHours(mmt.getUpdateTime(),12);
                            if (date.getTime() < new Date().getTime()) {
                                System.out.println("任务被驳回24小时候没上传自动取消"+task.getTitle()+",用户:"+mmt.getUid());
                                mmt.delete();
                            }
                        }

                    }

                }

                return true;
            }
        });


		// context.getJobDetail().getJobDataMap().get("xx参数");
	}
}
