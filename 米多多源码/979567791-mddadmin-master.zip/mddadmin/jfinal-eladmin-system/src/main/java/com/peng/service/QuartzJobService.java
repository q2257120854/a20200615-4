package com.peng.service;

import com.jfinal.plugin.activerecord.Page;
import com.peng.model.QuartzJob;

import java.util.List;

public interface QuartzJobService<QuartzLog>  extends BaseService  {
    Page<QuartzJob> queryAll(String jobName, Integer pageNumber, Integer size);
}