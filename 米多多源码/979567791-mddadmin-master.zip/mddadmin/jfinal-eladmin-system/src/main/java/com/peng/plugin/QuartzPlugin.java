package com.peng.plugin;


import com.jfinal.aop.Aop;
import com.jfinal.aop.Inject;
import com.jfinal.kit.LogKit;
import com.jfinal.plugin.IPlugin;
import com.peng.model.QuartzJob;
import com.peng.service.QuartzJobService;
import com.peng.service.provider.QuartzJobServiceProvider;
import org.quartz.*;
import org.quartz.impl.StdSchedulerFactory;

import java.util.List;

/**
 * Created by wupeng on 2019/4/23.
 */
public class QuartzPlugin implements IPlugin {

    @Inject
    private QuartzJobService quartzJobService = Aop.get(QuartzJobServiceProvider.class);;

    private SchedulerFactory sf = null;

    public static Scheduler scheduler = null;

    /**
     * 启动Quartz
     */
    @Override
    @SuppressWarnings({ "rawtypes", "unchecked" })
    public boolean start() {
        // 创建调度工厂
        sf = new StdSchedulerFactory();

        try {
            scheduler = sf.getScheduler();

            List<QuartzJob> tasks = quartzJobService.findAll();
            for (QuartzJob task : tasks) {
                String jobClassName = task.getBeanName();
                String jobCronExp = task.getCronExpression();
                Boolean state = task.getIsPause();
                // String params = task.getInt("params");

                Class clazz;
                try {
                    clazz = Class.forName(jobClassName);
                } catch (ClassNotFoundException e) {
                    throw new RuntimeException(e);
                }

                JobDetail job = JobBuilder.newJob(clazz).withIdentity(jobClassName, jobClassName).build();
                // job.getJobDataMap().put("type", "eova");
                CronTrigger trigger = TriggerBuilder.newTrigger().withIdentity(jobClassName, jobClassName).withSchedule(CronScheduleBuilder.cronSchedule(jobCronExp)).build();

                try {
                    scheduler.scheduleJob(job, trigger);
                    if (state) {
                        // 暂停触发
                        scheduler.pauseTrigger(trigger.getKey());
                    }
                } catch (SchedulerException e) {
                    new RuntimeException(e);
                }

                LogKit.info(job.getKey() + " loading and exp: " + trigger.getCronExpression());
            }

            scheduler.start();

        } catch (SchedulerException e) {
            new RuntimeException(e);
        }

        return true;

    }

    /**
     * 停止Quartz
     */
    @Override
    public boolean stop() {
        try {
            scheduler.shutdown();
        } catch (SchedulerException e) {
            LogKit.error("shutdown error", e);
            return false;
        }
        return true;
    }

}
