package com.peng.service.provider;

import com.peng.model.QiniuConfig;
import com.peng.service.QiniuConfigService;


public class QiniuConfigServiceProvider extends BaseServiceProvider<QiniuConfig> implements QiniuConfigService {

}