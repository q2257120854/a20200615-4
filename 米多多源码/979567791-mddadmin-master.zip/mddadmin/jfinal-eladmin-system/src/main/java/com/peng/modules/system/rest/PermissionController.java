package com.peng.modules.system.rest;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.jfinal.aop.Before;
import com.jfinal.aop.Inject;
import com.jfinal.core.ActionKey;
import com.jfinal.core.Controller;
import com.jfinal.ext.interceptor.GET;
import com.jfinal.kit.HttpKit;
import com.peng.model.Permission;
import com.peng.service.PermissionService;
import com.peng.service.dto.PermissionDTO;

import java.util.Date;
import java.util.List;

/**
 * Created by wupeng on 2019/4/18.
 */
public class PermissionController extends Controller {

    @Inject
    private PermissionService permissionService;

    /**
     * 返回全部的权限
     */
    @ActionKey("api/permissions/tree")
    public void getTree(){
        renderJson(permissionService.getPermissionTree(permissionService.findByPid(0L)));
    }

    /**
     * 查询权限
     */
    @ActionKey("api/permissions/query")
    public void query(){
        String name = getPara("name");
        List<PermissionDTO> menuDTOList = permissionService.queryAll(name);
        renderJson(permissionService.buildTree(menuDTOList));
    }

    /**
     * 新增权限
     */
    @ActionKey("api/permissions/add")
    public void add(){
        String json = HttpKit.readData(getRequest());
        JSONObject reqJson = JSON.parseObject(json);
        String name = reqJson.getString("name");
        Long pid = reqJson.getLong("pid");
        String alias = reqJson.getString("alias");

        Permission permission = new Permission();
        permission.setName(name);
        permission.setPid(pid);
        permission.setAlias(alias);
        permission.setCreateTime(new Date());
        permission.save();
        renderJson(permission);
    }

    /**
     * 修改权限
     */
    @ActionKey("api/permissions/update")
    public void update(){
        String json = HttpKit.readData(getRequest());
        JSONObject reqJson = JSON.parseObject(json);
        Long id = reqJson.getLong("id");
        String name = reqJson.getString("name");
        Long pid = reqJson.getLong("pid");
        String alias = reqJson.getString("alias");

        Permission permission = (Permission) permissionService.findById(id);
        permission.setName(name);
        permission.setPid(pid);
        permission.setAlias(alias);
        permission.update();
        renderJson(permission);
    }

    /**
     * 删除权限
     */
    @ActionKey("api/permissions/del")
    public void delete(){
        Long id = getParaToLong(0);
        List<Permission> permissionList = permissionService.findByPid(id);
        // 特殊情况，对级联删除进行处理
        for (Permission permission : permissionList) {
            permissionService.untiedPermission(permission.getId());
            permissionService.deleteById(permission.getId());
        }
        permissionService.untiedPermission(id);
        permissionService.deleteById(id);
        renderJson("删除菜单");
    }

}
