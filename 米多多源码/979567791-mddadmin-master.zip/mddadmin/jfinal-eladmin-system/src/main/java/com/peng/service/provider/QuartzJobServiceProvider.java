package com.peng.service.provider;

import com.jfinal.plugin.activerecord.Page;
import com.peng.model.QuartzJob;
import com.peng.service.QuartzJobService;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.List;


public class QuartzJobServiceProvider extends BaseServiceProvider<QuartzJob> implements QuartzJobService {

    @Override
    public Page<QuartzJob> queryAll(String jobName, Integer pageNumber, Integer size) {
        StringBuffer sql = new StringBuffer("from quartz_job where 1=1 ");
        List<Object> para = new ArrayList<>();
        if (StringUtils.isNotBlank(jobName)) {
            sql.append(" and job_name like ?");
            para.add("%"+jobName+"%");
        }
        Page<QuartzJob> page = DAO.paginate(pageNumber,size,"select *",sql.toString(),para.toArray());
        return page;
    }
}