package com.peng.service.provider;

import com.jfinal.plugin.activerecord.Db;
import com.peng.model.RolesMenus;
import com.peng.service.RolesMenusService;


public class RolesMenusServiceProvider extends BaseServiceProvider<RolesMenus> implements RolesMenusService {

    @Override
    public void deleteByRoleId(Long roleId) {
        Db.update("delete from roles_menus where role_id = ?",roleId);
    }

    @Override
    public void deleteByRoleIdAndMenuId(Long roleId, Long menuId) {
        Db.update("delete from roles_menus where role_id = ? and menu_id = ?",roleId,menuId);
    }
}