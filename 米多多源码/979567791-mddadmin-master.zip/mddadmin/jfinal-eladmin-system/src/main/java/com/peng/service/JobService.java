package com.peng.service;

public interface JobService<Job>  extends BaseService {


}