package com.peng.service.provider;

import com.peng.model.Picture;
import com.peng.service.PictureService;


public class PictureServiceProvider extends BaseServiceProvider<Picture> implements PictureService {

}