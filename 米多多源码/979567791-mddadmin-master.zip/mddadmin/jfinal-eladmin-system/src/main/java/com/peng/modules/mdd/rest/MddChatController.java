package com.peng.modules.mdd.rest;

import com.jfinal.aop.Inject;
import com.jfinal.core.ActionKey;
import com.jfinal.core.Controller;
import com.peng.mdd.model.MddChat;
import com.peng.mdd.model.MddMyTask;
import com.peng.mdd.service.MddChatService;
import com.peng.mdd.service.MddMyTaskService;

import java.util.List;

/**
* @author jie1
* @date 2019-06-14
*/
public class MddChatController extends Controller {

    @Inject
    private MddMyTaskService myTaskService;
    @Inject
    private MddChatService chatService;

    /**
    * 查询
    */
    @ActionKey("api/mdd/chat/list")
    public void query(){
        Long taskId = getParaToLong("task_id");
        Long uid = getParaToLong("uid");
        MddMyTask mmt = myTaskService.findByTaskIdWithUid(taskId,uid);
        List<MddChat> chatList = chatService.list(mmt.getId());
        renderJson(chatList);
    }

}
