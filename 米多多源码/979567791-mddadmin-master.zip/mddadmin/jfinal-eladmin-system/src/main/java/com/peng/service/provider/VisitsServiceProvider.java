package com.peng.service.provider;

import com.peng.model.Visits;
import com.peng.service.VisitsService;


public class VisitsServiceProvider extends BaseServiceProvider<Visits> implements VisitsService {

}