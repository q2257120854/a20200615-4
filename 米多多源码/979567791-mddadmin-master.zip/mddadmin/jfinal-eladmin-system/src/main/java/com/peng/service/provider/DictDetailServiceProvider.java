package com.peng.service.provider;

import com.jfinal.plugin.activerecord.Page;
import com.peng.model.DictDetail;
import com.peng.service.DictDetailService;
import com.peng.service.dto.DictDetailDTO;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.List;


public class DictDetailServiceProvider extends BaseServiceProvider<DictDetail> implements DictDetailService {

    @Override
    public Page<DictDetailDTO> queryAll(String dictName, String label, Integer pageNumber, Integer size) {
        StringBuffer sql = new StringBuffer("from dict_detail a left join dict b on a.dict_id = b.id where b.name = ? ");
        List<Object> para = new ArrayList<>();
        para.add(dictName);
        if (StringUtils.isNotBlank(label)) {
            sql.append(" and label like ?");
            para.add("%"+label+"%");
        }
        Page<DictDetail> page = DAO.paginate(pageNumber,size,"select a.*",sql.toString(),para.toArray());
        List<DictDetailDTO> dtoList = new ArrayList<>();
        for (DictDetail arg0: page.getList()) {

            DictDetailDTO dictDetailDTO = new DictDetailDTO();
            dictDetailDTO.setId(arg0.getId());
            dictDetailDTO.setLabel(arg0.getLabel());
            dictDetailDTO.setValue(arg0.getValue());
            dictDetailDTO.setSort(arg0.getSort());
            dtoList.add(dictDetailDTO);
        }

        Page<DictDetailDTO> page2 = new Page<>();
        page2.setList(dtoList);
        page2.setTotalRow(page.getTotalRow());
        return page2;
    }
}