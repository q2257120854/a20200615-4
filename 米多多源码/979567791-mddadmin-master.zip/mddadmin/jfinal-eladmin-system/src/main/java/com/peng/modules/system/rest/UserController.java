package com.peng.modules.system.rest;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.jfinal.aop.Inject;
import com.jfinal.core.ActionKey;
import com.jfinal.core.Controller;
import com.jfinal.kit.HttpKit;
import com.jfinal.plugin.activerecord.Page;
import com.peng.model.User;
import com.peng.model.UsersRoles;
import com.peng.service.UserService;
import com.peng.service.UsersRolesService;
import com.peng.service.dto.UserDTO;
import com.peng.utils.PageUtil;

import java.util.Date;

/**
 * Created by wupeng on 2019/4/16.
 */
public class UserController extends Controller {

    @Inject
    private UserService userService;

    @Inject
    private UsersRolesService usersRolesService;

    /**
     * 查询用户
     */
    @ActionKey("api/users/query")
    public void query(){
        String username = getPara("username");
        String email = getPara("email");
        Boolean enabled = getParaToBoolean("enabled");
        Integer pageNumber = getParaToInt("page");
        Integer size = getParaToInt("size");
        Page<UserDTO> page = userService.queryAll(username,email,enabled,pageNumber,size);
        renderJson(PageUtil.toPage(page));
    }

    /**
     * 新增用户
     */
    @ActionKey("api/users/add")
    public void add(){
        String json = HttpKit.readData(getRequest());
        JSONObject reqJson = JSON.parseObject(json);
        String username = reqJson.getString("username");
        String email = reqJson.getString("email");
        Boolean enabled = reqJson.getBoolean("enabled");
        String phone = reqJson.getString("phone");
        JSONArray roles = reqJson.getJSONArray("roles");

        User user = new User();
        user.setUsername(username);
        user.setEmail(email);
        user.setEnabled(enabled?1l:0l);
        user.setPhone(phone);
        user.setCreateTime(new Date());
        user.save();

        usersRolesService.deleteByUserId(user.getId());
        for (Object obj: roles) {
            JSONObject jsonObj = (JSONObject)obj;
            Long roleId = jsonObj.getLong("id");
            UsersRoles ur = new UsersRoles();
            ur.setUserId(user.getId());
            ur.setRoleId(roleId);
            ur.save();
        }

        renderJson(user);
    }

    /**
     * 修改用户
     */
    @ActionKey("api/users/update")
    public void update(){
        String json = HttpKit.readData(getRequest());
        JSONObject reqJson = JSON.parseObject(json);
        Long id = reqJson.getLong("id");
        String username = reqJson.getString("username");
        String email = reqJson.getString("email");
        Boolean enabled = reqJson.getBoolean("enabled");
        String phone = reqJson.getString("phone");
        JSONArray roles = reqJson.getJSONArray("roles");

        User user = (User) userService.findById(id);
        user.setUsername(username);
        user.setEmail(email);
        user.setEnabled(enabled?1l:0l);
        user.setPhone(phone);
        user.update();

        usersRolesService.deleteByUserId(user.getId());
        for (Object obj: roles) {
            JSONObject jsonObj = (JSONObject)obj;
            Long roleId = jsonObj.getLong("id");
            UsersRoles ur = new UsersRoles();
            ur.setUserId(user.getId());
            ur.setRoleId(roleId);
            ur.save();
        }

        renderJson(user);
    }

    /**
     * 删除用户
     */
    @ActionKey("api/users/del")
    public void delete(){
        Long id = getParaToLong(0);
        usersRolesService.deleteByUserId(id);
        userService.deleteById(id);
        renderJson("删除用户");
    }
}
