package com.peng.modules.mdd.rest;

import com.alibaba.fastjson.JSON;
import com.jfinal.aop.Inject;
import com.jfinal.core.ActionKey;
import com.jfinal.core.Controller;
import com.jfinal.kit.HttpKit;
import com.jfinal.plugin.activerecord.Page;
import com.peng.enums.AccountDetailEnum;
import com.peng.mdd.model.MddEarnestMoneyBack;
import com.peng.mdd.model.MddUser;
import com.peng.mdd.service.MddEarnestMoneyBackService;
import com.peng.mdd.service.MddUserService;
import com.peng.utils.PageUtil;

/**
* @author jie1
* @date 2019-06-05
*/
public class MddEarnestMoneyBackController extends Controller {

    @Inject
    private MddEarnestMoneyBackService mddEarnestMoneyBackService;
    @Inject
    private MddUserService mddUserService;

    /**
    * 查询
    */
    @ActionKey("api/mdd/earnestMoneyBack/query")
    public void query(){
        Long uid = getParaToLong("uid");
        Integer state = getParaToInt("state");
        Integer pageNumber = getParaToInt("page");
        Integer pageSize = getParaToInt("size");
        Page<MddEarnestMoneyBack> page = mddEarnestMoneyBackService.list(pageNumber,pageSize,uid,state);
        renderJson(PageUtil.toPage(page));
    }

    /**
    * 新增
    */
    @ActionKey("api/mdd/earnestMoneyBack/add")
    public void add(){
        String json = HttpKit.readData(getRequest());
        MddEarnestMoneyBack mddEarnestMoneyBack = JSON.parseObject(json,MddEarnestMoneyBack.class);
        mddEarnestMoneyBack.save();

        renderJson(mddEarnestMoneyBack);
    }

    /**
    * 修改
    */
    @ActionKey("api/mdd/earnestMoneyBack/update")
    public void update(){
        String json = HttpKit.readData(getRequest());
        MddEarnestMoneyBack mddEarnestMoneyBack = JSON.parseObject(json,MddEarnestMoneyBack.class);
        mddEarnestMoneyBack.update();

        renderJson(mddEarnestMoneyBack);
    }

    /**
    * 删除
    */
//    @ActionKey("api/mdd/earnestMoneyBack/del")
//    public void delete(){
//        Long id = getParaToLong(0);
//        mddEarnestMoneyBackService.deleteById(id);
//        renderNull();
//    }

    /**
     * 通过
     */
    @ActionKey("api/mdd/earnestMoneyBack/pass")
    public void delete(){
        Long id = getParaToLong(0);
        MddEarnestMoneyBack emb = MddEarnestMoneyBack.dao.findById(id);
        if (!"0".equals(String.valueOf(emb.getState()))){
            renderNull();
            return;
        }
        emb.setState(2);
        emb.update();

        MddUser user = MddUser.dao.findById(emb.getUid());
        mddUserService.micoin(user,emb.getAmount(), AccountDetailEnum.保证金退回.getMsg());
        renderNull();
    }

    /**
     * 不通过
     */
    @ActionKey("api/mdd/earnestMoneyBack/fail")
    public void fail(){
        Long id = getParaToLong(0);

        MddEarnestMoneyBack emb = MddEarnestMoneyBack.dao.findById(id);
        if (!"0".equals(String.valueOf(emb.getState()))){
            renderNull();
            return;
        }
        emb.setState(1);
        emb.update();

        MddUser user = MddUser.dao.findById(emb.getUid());
        user.setEarnestMoney(user.getEarnestMoney() + emb.getAmount());
        user.update();
        renderNull();
    }
}
