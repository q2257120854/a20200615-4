/**
 * Copyright (c) 2013-2016, Jieven. All rights reserved.
 *
 * Licensed under the GPL license: http://www.gnu.org/licenses/gpl.txt
 * To use it on other terms please contact us at 1623736450@qq.com
 */
package com.peng;

import com.alibaba.druid.util.JdbcUtils;
import com.alibaba.druid.wall.WallFilter;
import com.jfinal.aop.AopManager;
import com.jfinal.config.*;
import com.jfinal.kit.JsonKit;
import com.jfinal.kit.PathKit;
import com.jfinal.kit.Prop;
import com.jfinal.kit.PropKit;
import com.jfinal.plugin.activerecord.ActiveRecordPlugin;
import com.jfinal.plugin.activerecord.CaseInsensitiveContainerFactory;
import com.jfinal.plugin.activerecord.dialect.MysqlDialect;
import com.jfinal.plugin.druid.DruidPlugin;
import com.jfinal.plugin.druid.DruidStatViewHandler;
import com.jfinal.render.*;
import com.jfinal.server.undertow.UndertowServer;
import com.jfinal.template.Engine;
import com.peng.config.DataSource;
import com.peng.enums.ReturnCodeEnum;
import com.peng.interceptor.AuthInterceptor;
import com.peng.interceptor.CORSInterceptor;
import com.peng.mdd.model.MddAppeal;
import com.peng.mdd.model.MddInviteCode;
import com.peng.mdd.model.Mdd_MappingKit;
import com.peng.mdd.service.*;
import com.peng.mdd.service.provider.*;
import com.peng.model.Main_MappingKit;
import com.peng.modules.mdd.rest.*;
import com.peng.modules.security.rest.AuthenticationController;
import com.peng.modules.system.rest.*;
import com.peng.plugin.QuartzPlugin;
import com.peng.rest.GenConfigController;
import com.peng.rest.GeneratorController;
import com.peng.service.*;
import com.peng.service.impl.GenConfigServiceImpl;
import com.peng.service.impl.GeneratorServiceImpl;
import com.peng.service.provider.*;
import com.peng.utils.FileUtil;

import java.io.File;
import java.sql.Connection;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

public class SystemConfig extends JFinalConfig {

	/** 配置属性 **/
	//public static Map<String, String> props = new HashMap<String, String>();

	/**
	 * Run Server
	 * 
	 * @param args
	 */
//	public static void main(String[] args) {
//		JFinal.start("src/main/webapp", 8686, "/", 0);
//	}

	public static void main(String[] args) {
		UndertowServer.start(SystemConfig.class, 8080, true);
	}
	
	@Override
	public void configRoute(Routes me) {
		// 自定义的路由配置往这里加。。。
		me.add("alipay",AliPayController.class);
        me.add("genconfig",GenConfigController.class);
        me.add("generator",GeneratorController.class);
        me.add("qiniu",QiniuAction.class);
		me.add("auth",AuthenticationController.class);
		me.add("dict",DictController.class);
		me.add("users",UserController.class);
		me.add("dictDetail",DictDetailController.class);
		me.add("menu",MenuController.class);
		me.add("permissions",PermissionController.class);
		me.add("jobs",QuartzJobController.class);
		me.add("role",RoleController.class);
        me.add("wxpay",WxPayController.class);
		me.add("mdd/users",MddUserController.class);
		me.add("mdd/tasktype",MddTaskTypeController.class);
        me.add("mdd/task",MddTaskController.class);
        me.add("mdd/banner",MddBannerController.class);
        me.add("mdd/notice",MddNoticeController.class);
        me.add("mdd/config", MddConfigController.class);
        me.add("mdd/earnestMoneyBack", MddEarnestMoneyBackController.class);
		me.add("mdd/report", MddReportController.class);
        me.add("mdd/complain", MddComplainController.class);
        me.add("mdd/appeal", MddAppealController.class);
        me.add("mdd/invitecode", MddInviteCodeController.class);
        me.add("mdd/chat", MddChatController.class);

	}

	@Override
	public void configPlugin(Plugins me) {
		// 添加数据源
		
		ActiveRecordPlugin admin = addDataSource(DataSource.ADMIN,me);
        Main_MappingKit.mapping(admin);
        ActiveRecordPlugin mdd = addDataSource(DataSource.MDD,me);
		Mdd_MappingKit.mapping(mdd);

		QuartzPlugin quartz = new QuartzPlugin();
		me.add(quartz);
        
        //配置缓存插件
        //me.add(new EhCachePlugin());

		// ...
	}

	private ActiveRecordPlugin addDataSource(String name,Plugins me) {
		String url, user, pwd;
		Prop props = PropKit.use("jdbc.config");
        url = props.get(name+"_url");
		user = props.get(name+"_user");
		pwd = props.get(name+"_pwd");
		
		WallFilter wall = new WallFilter();
        wall.setDbType(JdbcUtils.MYSQL);
         
        DruidPlugin dp = new DruidPlugin(url, user, pwd);
        dp.setFilters("stat,wall");
         
        ActiveRecordPlugin arp = new ActiveRecordPlugin(name,dp);
        // 方言
        arp.setDialect(new MysqlDialect());
        // 事务级别
        arp.setTransactionLevel(Connection.TRANSACTION_REPEATABLE_READ);
        // 统一全部默认小写
        arp.setContainerFactory(new CaseInsensitiveContainerFactory(true));
        // 是否显示SQL
        arp.setShowSql(false);
        System.out.println("load data source:" + url + "/" + user);
 
        me.add(dp).add(arp);
         
		return arp;
	}
	
	@Override
	public void configInterceptor(Interceptors me) {
//		me.add(new TxByMethodRegex("(.*save.*|.*update.*)"));
//		me.add(new TxByMethods("save", "update","sign"));
//		me.add(new TxByActionKeyRegex("/trans.*"));
//		me.add(new TxByActionKeys("/tx/save", "/tx/update"));
		me.add(new CORSInterceptor());
		me.add(new AuthInterceptor());
		//me.add(new APIInterceptor());
	}

	@Override
	public void configHandler(Handlers me) {
		// 添加DruidHandler
		DruidStatViewHandler dvh = new DruidStatViewHandler("/druid");
		me.add(dvh);
	}

	@Override
	public void configConstant(Constants me) {
        PropKit.use("config.txt");
		me.setViewType(ViewType.VELOCITY);
		
		RenderManager.me().setRenderFactory(new MyRenderFactory());
		
//		me.setError404View("/404.html");
//		me.setError500View("/500.html");
		
//		String resPath = PathKit.getRootClassPath() + File.separator;
//		loadConfig(resPath);
		
//		String headimgUploadPath = props.get("headimg_upload_path");
//		me.setBaseUploadPath(headimgUploadPath);

		// 开启对 jfinal web 项目组件 Controller、Interceptor、Validator 的注入
		me.setInjectDependency(true);

		// 开启对超类的注入。不开启时可以在超类中通过 Aop.get(...) 进行注入
		//me.setInjectSuperClass(true);
		AopManager.me().addMapping(AlipayConfigService.class, AlipayConfigServiceProvider.class);
		AopManager.me().addMapping(DeptService.class, DeptServiceProvider.class);
		AopManager.me().addMapping(DictDetailService.class, DictDetailServiceProvider.class);
		AopManager.me().addMapping(DictService.class, DictServiceProvider.class);
		AopManager.me().addMapping(JobService.class, JobServiceProvider.class);
		AopManager.me().addMapping(MenuService.class, MenuServiceProvider.class);
		AopManager.me().addMapping(PermissionService.class, PermissionServiceProvider.class);
		AopManager.me().addMapping(QuartzJobService.class, QuartzJobServiceProvider.class);
		AopManager.me().addMapping(QuartzLogService.class, QuartzLogServiceProvider.class);
		AopManager.me().addMapping(RoleService.class, RoleServiceProvider.class);
		AopManager.me().addMapping(RolesMenusService.class, RolesMenusServiceProvider.class);
		AopManager.me().addMapping(RolesPermissionsService.class, RolesPermissionsServiceProvider.class);
		AopManager.me().addMapping(UserService.class, UserServiceProvider.class);
		AopManager.me().addMapping(UsersRolesService.class, UsersRolesServiceProvider.class);

        AopManager.me().addMapping(MddUserService.class, MddUserServiceProvider.class);
		AopManager.me().addMapping(MddTaskTypeService.class, MddTaskTypeServiceProvider.class);
        AopManager.me().addMapping(MddTaskService.class, MddTaskServiceProvider.class);
        AopManager.me().addMapping(MddMyTaskService.class, MddMyTaskServiceProvider.class);
        AopManager.me().addMapping(MddBannerService.class, MddBannerServiceProvider.class);
		AopManager.me().addMapping(MddNoticeService.class, MddNoticeServiceProvider.class);
        AopManager.me().addMapping(MddConfigService.class, MddConfigServiceProvider.class);
		AopManager.me().addMapping(MddEarnestMoneyBackService.class, MddEarnestMoneyBackServiceProvider.class);
        AopManager.me().addMapping(MddReportService.class, MddReportServiceProvider.class);
        AopManager.me().addMapping(MddComplainService.class, MddComplainServiceProvider.class);
        AopManager.me().addMapping(MddAppealService.class, MddAppealServiceProvider.class);
        AopManager.me().addMapping(MddInviteCodeService.class, MddInviteCodeServiceProvider.class);
        AopManager.me().addMapping(MddChatService.class, MddChatServiceProvider.class);

        AopManager.me().addMapping(GenConfigService.class, GenConfigServiceImpl.class);
        AopManager.me().addMapping(GeneratorService.class, GeneratorServiceImpl.class);

	}
	
	public class MyRenderFactory extends RenderFactory {
		@Override
		public Render getErrorRender(int errorCode) {
			if (errorCode == 500) {
				return new JsonRender(renderInfo(ReturnCodeEnum.服务器异常));
			}else if (errorCode == 404){
				// return new RedirectRender("/");
				return new JsonRender(renderInfo(ReturnCodeEnum.找不到地址));
			}else if (errorCode == 400){
				return new JsonRender(renderInfo(ReturnCodeEnum.服务器异常));
			}
			return super.getErrorRender(errorCode);
		}
	}
	
	/**
	 * 返回信息
	 * @param returnCodeEnum 返回码枚举
	 */
	public String renderInfo(ReturnCodeEnum returnCodeEnum) {
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("code", returnCodeEnum.getCode());
		map.put("msg", returnCodeEnum.getMsg());
		
		return JsonKit.toJson(map);
	}
	
	/**
	 * 加载配置
	 * 
	 * @param path
	 * @return
	 */
//	public static boolean loadConfig(String path) {
//		if (!FileUtil.isDir(path)) {
//			return false;
//		}
//		File[] files = FileUtil.getFiles(path);
//		for (File file : files) {
//			if (!file.getName().endsWith(".config")) {
//				continue;
//			}
//			Properties properties = FileUtil.getProp(file);
//			Set<Object> keySet = properties.keySet();
//			for (Object ks : keySet) {
//				String key = ks.toString();
//				props.put(key, properties.getProperty(key));
//				//System.out.println(key);
//			}
//			//System.out.println(file.getName());
//		}
//		return true;
//	}

	@Override
	public void configEngine(Engine me) {
		// TODO Auto-generated method stub
		
	}

}