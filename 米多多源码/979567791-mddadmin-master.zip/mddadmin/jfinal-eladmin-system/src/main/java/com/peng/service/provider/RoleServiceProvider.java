package com.peng.service.provider;

import com.jfinal.aop.Inject;
import com.jfinal.plugin.activerecord.Page;
import com.peng.model.Role;
import com.peng.service.MenuService;
import com.peng.service.PermissionService;
import com.peng.service.RoleService;
import com.peng.service.dto.MenuDTO;
import com.peng.service.dto.PermissionDTO;
import com.peng.service.dto.RoleDTO;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.List;


public class RoleServiceProvider extends BaseServiceProvider<Role> implements RoleService {

    @Inject
    private PermissionService permissionService;

    @Inject
    private MenuService menuService;

    @Override
    public RoleDTO queryById(Long id) {
        Role arg0 = DAO.findById(id);
        List<PermissionDTO> perList = permissionService.queryByRoleId(arg0.getId());
        List<MenuDTO> menuList = menuService.queryByRoleId(arg0.getId());

        RoleDTO roleDTO = new RoleDTO();
        roleDTO.setId(arg0.getId());
        roleDTO.setName(arg0.getName());
        roleDTO.setDataScope(arg0.getDataScope());
        roleDTO.setRemark(arg0.getRemark());
        roleDTO.setPermissions(perList);
        roleDTO.setMenus(menuList);
        roleDTO.setDepts(new ArrayList<>());
        roleDTO.setCreateTime(arg0.getCreateTime());
        return roleDTO;
    }

    @Override
    public List<RoleDTO> queryAll() {
        StringBuffer sql = new StringBuffer(" where 1=1 ");
        List<Role> list = DAO.find("select * from role");
        List<RoleDTO> dtoList = new ArrayList<>();
        for (Role arg0: list) {
            List<PermissionDTO> perList = permissionService.queryByRoleId(arg0.getId());
            List<MenuDTO> menuList = menuService.queryByRoleId(arg0.getId());

            RoleDTO roleDTO = new RoleDTO();
            roleDTO.setId(arg0.getId());
            roleDTO.setName(arg0.getName());
            roleDTO.setDataScope(arg0.getDataScope());
            roleDTO.setRemark(arg0.getRemark());
            roleDTO.setPermissions(perList);
            roleDTO.setMenus(menuList);
            roleDTO.setDepts(new ArrayList<>());
            roleDTO.setCreateTime(arg0.getCreateTime());
            dtoList.add(roleDTO);
        }
        return dtoList;
    }

    @Override
    public Page<RoleDTO> queryAll(String name, Integer pageNumber, Integer size) {
        StringBuffer sql = new StringBuffer("from role where 1=1 ");
        List<Object> para = new ArrayList<>();
        if (StringUtils.isNotBlank(name)) {
            sql.append(" and name like ?");
            para.add("%"+name+"%");
        }
        Page<Role> page = DAO.paginate(pageNumber,size,"select *",sql.toString(),para.toArray());
        List<RoleDTO> dtoList = new ArrayList<>();
        for (Role arg0: page.getList()) {
            List<PermissionDTO> perList = permissionService.queryByRoleId(arg0.getId());
            List<MenuDTO> menuList = menuService.queryByRoleId(arg0.getId());

            RoleDTO roleDTO = new RoleDTO();
            roleDTO.setId(arg0.getId());
            roleDTO.setName(arg0.getName());
            roleDTO.setDataScope(arg0.getDataScope());
            roleDTO.setRemark(arg0.getRemark());
            roleDTO.setPermissions(perList);
            roleDTO.setMenus(menuList);
            roleDTO.setDepts(new ArrayList<>());
            roleDTO.setCreateTime(arg0.getCreateTime());
            dtoList.add(roleDTO);
        }

        Page<RoleDTO> page2 = new Page<>();
        page2.setList(dtoList);
        page2.setTotalRow(page.getTotalRow());
        return page2;
    }

    @Override
    public List<Role> findByMenuId(Long id) {
        return DAO.find("select b.* from roles_menus a left join role b on a.role_id = b.id where a.menu_id = ?",id);
    }

    @Override
    public List<Role> findByPermissionId(Long id) {
        return DAO.find("select b.* from roles_permissions a left join role b on a.role_id = b.id where a.permission_id = ?",id);
    }

    @Override
    public List<RoleDTO> findByUserId(Object id) {
        List<RoleDTO> dtoList = new ArrayList<>();
        List<Role> list = DAO.find("select b.* from users_roles a left join role b on a.role_id = b.id where a.user_id = ?",id);
        for (Role arg0: list) {
            List<PermissionDTO> perList = permissionService.queryByRoleId(arg0.getId());
            List<MenuDTO> menuList = menuService.queryByRoleId(arg0.getId());

            RoleDTO roleDTO = new RoleDTO();
            roleDTO.setId(arg0.getId());
            roleDTO.setName(arg0.getName());
            roleDTO.setDataScope(arg0.getDataScope());
            roleDTO.setRemark(arg0.getRemark());
            roleDTO.setPermissions(perList);
            roleDTO.setMenus(menuList);
            roleDTO.setDepts(new ArrayList<>());
            roleDTO.setCreateTime(arg0.getCreateTime());
            dtoList.add(roleDTO);
        }
        return dtoList;
    }
}