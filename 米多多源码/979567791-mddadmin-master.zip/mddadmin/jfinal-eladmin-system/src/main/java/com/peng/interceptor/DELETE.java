package com.peng.interceptor;

import com.jfinal.aop.Interceptor;
import com.jfinal.aop.Invocation;
import com.jfinal.core.Controller;

/**
 * Created by wupeng on 2019/4/17.
 */
public class DELETE implements Interceptor {
    public void intercept(Invocation inv) {
        Controller controller = inv.getController();
        if("DELETE".equalsIgnoreCase(controller.getRequest().getMethod())) {
            inv.invoke();
        } else {
            controller.renderError(405);
        }

    }
}
