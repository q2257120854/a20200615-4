package com.peng.service;

public interface LogService<Log>  extends BaseService {


}