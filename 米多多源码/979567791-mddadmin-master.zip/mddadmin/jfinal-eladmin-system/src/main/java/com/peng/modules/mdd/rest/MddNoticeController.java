package com.peng.modules.mdd.rest;

import com.alibaba.fastjson.JSON;
import com.jfinal.aop.Inject;
import com.jfinal.core.ActionKey;
import com.jfinal.core.Controller;
import com.jfinal.kit.HttpKit;
import com.jfinal.plugin.activerecord.Page;
import com.peng.mdd.model.MddNotice;
import com.peng.mdd.service.MddNoticeService;
import com.peng.utils.PageUtil;

/**
* @author jie1
* @date 2019-05-15
*/
public class MddNoticeController extends Controller {

    @Inject
    private MddNoticeService mddNoticeService;

    /**
    * 查询
    */
    @ActionKey("api/mdd/notice/query")
    public void query(){
        String content = getPara("content");
        Integer pageNumber = getParaToInt("page");
        Integer pageSize = getParaToInt("size");
        Page<MddNotice> page = mddNoticeService.list(pageNumber,pageSize,content);
        renderJson(PageUtil.toPage(page));
    }

    /**
    * 新增
    */
    @ActionKey("api/mdd/notice/add")
    public void add(){
        String json = HttpKit.readData(getRequest());
        MddNotice mddNotice = JSON.parseObject(json,MddNotice.class);
        mddNotice.save();

        renderJson(mddNotice);
    }

    /**
    * 修改
    */
    @ActionKey("api/mdd/notice/update")
    public void update(){
        String json = HttpKit.readData(getRequest());
        MddNotice mddNotice = JSON.parseObject(json,MddNotice.class);
        mddNotice.update();

        renderJson(mddNotice);
    }

    /**
    * 删除
    */
    @ActionKey("api/mdd/notice/del")
    public void delete(){
        Long id = getParaToLong(0);
        mddNoticeService.deleteById(id);
        renderNull();
    }
}
