package com.peng.service;

import com.jfinal.plugin.activerecord.Page;
import com.peng.model.Picture;

import java.util.List;

public interface PictureService<Picture>  extends BaseService  {


}