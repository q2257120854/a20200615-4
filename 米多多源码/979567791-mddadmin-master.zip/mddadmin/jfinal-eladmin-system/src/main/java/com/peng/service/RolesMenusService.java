package com.peng.service;

import com.jfinal.plugin.activerecord.Page;
import com.peng.model.RolesMenus;

import java.util.List;

public interface RolesMenusService<RolesMenus>  extends BaseService  {

    void deleteByRoleId(Long roleId);

    void deleteByRoleIdAndMenuId(Long roleId, Long menuId);
}