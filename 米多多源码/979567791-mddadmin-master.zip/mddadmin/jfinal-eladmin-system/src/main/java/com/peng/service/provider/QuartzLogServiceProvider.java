package com.peng.service.provider;

import com.peng.model.QuartzLog;
import com.peng.service.QuartzLogService;


public class QuartzLogServiceProvider extends BaseServiceProvider<QuartzLog> implements QuartzLogService {

}