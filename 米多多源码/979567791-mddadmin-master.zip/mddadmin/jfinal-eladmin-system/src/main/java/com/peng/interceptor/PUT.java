package com.peng.interceptor;

import com.jfinal.aop.Interceptor;
import com.jfinal.aop.Invocation;
import com.jfinal.core.Controller;

/**
 * Created by wupeng on 2019/4/17.
 */
public class PUT implements Interceptor {
    public void intercept(Invocation inv) {
        Controller controller = inv.getController();
        if("PUT".equalsIgnoreCase(controller.getRequest().getMethod())) {
            inv.invoke();
        } else {
            controller.renderError(405);
        }

    }
}
