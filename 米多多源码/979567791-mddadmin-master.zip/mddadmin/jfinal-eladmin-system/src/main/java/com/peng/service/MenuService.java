package com.peng.service;

import com.peng.model.Menu;
import com.peng.service.dto.MenuDTO;
import com.peng.service.dto.RoleDTO;
import com.peng.vo.MenuVo;

import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;

public interface MenuService  extends BaseService {
    List<MenuDTO> queryByRoleId(Long roleId);

    void untiedMenu(Long menuId);

    List<MenuDTO> queryAll(String name);

    Object getMenuTree(List<com.peng.model.Menu> menus);

    List<com.peng.model.Menu> findByPid(long pid);

    List<MenuVo> buildMenus(List<MenuDTO> menuDTOS);

    Map buildTree(List<MenuDTO> menuDTOS);

    LinkedHashSet<Menu> findByRoles_IdOrderBySortAsc(Long id);

    List<MenuDTO> findByRoles(List<RoleDTO> roles);
}