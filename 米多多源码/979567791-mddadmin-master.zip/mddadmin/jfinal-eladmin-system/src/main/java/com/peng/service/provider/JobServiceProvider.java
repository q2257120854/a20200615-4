package com.peng.service.provider;

import com.peng.model.Job;
import com.peng.service.JobService;


public class JobServiceProvider extends BaseServiceProvider<Job> implements JobService {

}