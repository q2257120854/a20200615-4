package com.peng.service.provider;

import com.jfinal.plugin.activerecord.Db;
import com.peng.model.RolesPermissions;
import com.peng.service.RolesPermissionsService;


public class RolesPermissionsServiceProvider extends BaseServiceProvider<RolesPermissions> implements RolesPermissionsService {

    @Override
    public void deleteByRoleIdAndPermissionId(Long roleId, Long PermissionId) {
        Db.update("delete from roles_permissions where role_id = ? and permission_id = ?",roleId,PermissionId);
    }

    @Override
    public void deleteByRoleId(Long roleId) {
        Db.update("delete from roles_permissions where role_id = ?",roleId);
    }
}