package com.peng.modules.mdd.rest;

import com.alibaba.fastjson.JSON;
import com.jfinal.aop.Inject;
import com.jfinal.core.ActionKey;
import com.jfinal.core.Controller;
import com.jfinal.kit.HttpKit;
import com.jfinal.plugin.activerecord.Page;
import com.peng.mdd.model.MddAppeal;
import com.peng.mdd.service.MddAppealService;
import com.peng.utils.PageUtil;

/**
* @author jie1
* @date 2019-06-14
*/
public class MddAppealController extends Controller {

    @Inject
    private MddAppealService mddAppealService;

    /**
    * 查询
    */
    @ActionKey("api/mdd/appeal/query")
    public void query(){
        Long uid = getParaToLong("uid");
        Long task_id = getParaToLong("task_id");
        Integer is_solve = getParaToInt("is_solve");
        Integer pageNumber = getParaToInt("page");
        Integer pageSize = getParaToInt("size");
        Page<MddAppeal> page = mddAppealService.list(pageNumber,pageSize,uid,task_id,is_solve);
        renderJson(PageUtil.toPage(page));
    }

    /**
    * 新增
    */
    @ActionKey("api/mdd/appeal/add")
    public void add(){
        String json = HttpKit.readData(getRequest());
        MddAppeal mddAppeal = JSON.parseObject(json,MddAppeal.class);
        mddAppeal.save();

        renderJson(mddAppeal);
    }

    /**
    * 修改
    */
    @ActionKey("api/mdd/appeal/update")
    public void update(){
        String json = HttpKit.readData(getRequest());
        MddAppeal mddAppeal = JSON.parseObject(json,MddAppeal.class);
        mddAppeal.update();

        renderJson(mddAppeal);
    }

    /**
    * 删除
    */
    @ActionKey("api/mdd/appeal/del")
    public void delete(){
        Long id = getParaToLong(0);
        mddAppealService.deleteById(id);
        renderNull();
    }
}
