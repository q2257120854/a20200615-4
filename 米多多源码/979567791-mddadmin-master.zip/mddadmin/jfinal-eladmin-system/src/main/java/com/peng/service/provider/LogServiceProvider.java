package com.peng.service.provider;

import com.peng.model.Log;
import com.peng.service.LogService;


public class LogServiceProvider extends BaseServiceProvider<Log> implements LogService {

}