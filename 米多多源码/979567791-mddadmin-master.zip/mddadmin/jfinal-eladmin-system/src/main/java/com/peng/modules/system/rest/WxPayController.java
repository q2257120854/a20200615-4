package com.peng.modules.system.rest;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.jfinal.core.ActionKey;
import com.jfinal.core.Controller;
import com.jfinal.kit.HttpKit;
import com.jfinal.weixin.sdk.utils.HttpUtils;
import com.peng.utils.MD5Helper;

/**
 * Created by wupeng on 2019/4/19.
 */
public class WxPayController extends Controller {

    /**
     * 微信付款到零钱
     */
    @ActionKey("api/wxpay/pay")
    public void pay(){
        String json = HttpKit.readData(getRequest());
        JSONObject reqJson = JSON.parseObject(json);
        String appid = reqJson.getString("appid");
        String openid = reqJson.getString("openid");
        String amount = reqJson.getString("amount");
        String transnote = reqJson.getString("transnote");


        String cerPath = this.getClass().getResource("/apiclient_cert.p12").getPath();



        String str = "amount="+amount+"&check_name=NO_CHECK"+"&desc="+transnote+"&mch_appid="+appid+"&mchid=1504042931"+"&nonce_str=3PG2J4ILTKCH16CQ2502SI8ZNMTM67VS"+"&openid="+openid+"&partner_trade_no=100000982014120919616"+"&spbill_create_ip=192.168.0.222";

        String signTemp=str+"&key=sdjeiwudhwjeuuuuskkduejdufjwoure"; //注：key为商户平台设置的密钥key

        String sign= MD5Helper.encoderByMD5(signTemp).toUpperCase();

        String data = "<xml>"+
                "<mch_appid>"+appid+"</mch_appid>"+
                "<mchid>1504042931</mchid>"+
                "<nonce_str>3PG2J4ILTKCH16CQ2502SI8ZNMTM67VS</nonce_str>"+
                "<partner_trade_no>100000982014120919616</partner_trade_no>"+
                "<openid>"+openid+"</openid>"+
                "<check_name>NO_CHECK</check_name>"+
//                "<re_user_name>张三</re_user_name>"+
                "<amount>"+amount+"</amount>"+
                "<desc>"+transnote+"</desc>"+
                "<spbill_create_ip>192.168.0.222</spbill_create_ip>"+
                "<sign>"+sign+"</sign>"+
                "</xml>";

        String response = HttpUtils.postSSL("https://api.mch.weixin.qq.com/mmpaymkttransfers/promotion/transfers",data,cerPath,"1504042931");




        renderJson(response);
    }

}
