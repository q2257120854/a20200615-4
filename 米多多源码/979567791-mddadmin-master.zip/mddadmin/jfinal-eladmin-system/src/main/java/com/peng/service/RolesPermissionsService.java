package com.peng.service;

import com.jfinal.plugin.activerecord.Page;
import com.peng.model.RolesPermissions;

import java.util.List;

public interface RolesPermissionsService<RolesPermissions>  extends BaseService  {
    void deleteByRoleIdAndPermissionId(Long roleId, Long PermissionId);

    void deleteByRoleId(Long roleId);
}