package com.peng.service.provider;

import com.jfinal.aop.Inject;
import com.peng.model.Menu;
import com.peng.model.Role;
import com.peng.service.MenuService;
import com.peng.service.RoleService;
import com.peng.service.RolesMenusService;
import com.peng.service.dto.MenuDTO;
import com.peng.service.dto.RoleDTO;
import com.peng.vo.MenuMetaVo;
import com.peng.vo.MenuVo;
import org.apache.commons.lang3.StringUtils;

import java.util.*;
import java.util.stream.Collectors;


public class MenuServiceProvider extends BaseServiceProvider<Menu> implements MenuService {

    @Inject
    private RoleService roleService;

    @Inject
    private RolesMenusService rolesMenusService;

    @Override
    public List<MenuDTO> queryByRoleId(Long roleId) {
        List<Menu> list = DAO.find("select b.* from roles_menus a left join menu b on a.menu_id = b.id where a.role_id = ?",roleId);
        List<MenuDTO> dtoList = new ArrayList<>();
        for (Menu arg0: list) {
            MenuDTO menuDTO = new MenuDTO();
            menuDTO.setId(arg0.getId());
            menuDTO.setName(arg0.getName());
            menuDTO.setSort(arg0.getSort());
            menuDTO.setPath(arg0.getPath());
            menuDTO.setComponent(arg0.getComponent());
            menuDTO.setPid(arg0.getPid());
            menuDTO.setiFrame(arg0.getIFrame());
            menuDTO.setIcon(arg0.getIcon());
            menuDTO.setCreateTime(arg0.getCreateTime());
            dtoList.add(menuDTO);
        }
        return  dtoList;
    }

    @Override
    public void untiedMenu(Long menuId) {
        List<Role> roles = roleService.findByMenuId(menuId);
        for (Role role : roles) {
            rolesMenusService.deleteByRoleIdAndMenuId(role.getId(),menuId);
        }
    }

    @Override
    public List<MenuDTO> queryAll(String name) {
        List<Object> para = new ArrayList<Object>();
        StringBuffer sql = new StringBuffer();
        sql.append("select * from menu where 1=1 ");
        if (StringUtils.isNotBlank(name)){
            sql.append(" and name like ?");
            para.add("%"+name+"%");
        }
        sql.append(" order by sort");
        List<Menu> menus = DAO.find(sql.toString(),para.toArray());
        List<MenuDTO> list = new ArrayList<>();
        for (Menu arg0 : menus) {
            MenuDTO menuDTO = new MenuDTO();
            menuDTO.setId(arg0.getId());
            menuDTO.setName(arg0.getName());
            menuDTO.setSort(arg0.getSort());
            menuDTO.setPath(arg0.getPath());
            menuDTO.setComponent(arg0.getComponent());
            menuDTO.setPid(arg0.getPid());
            menuDTO.setiFrame(arg0.getIFrame());
            menuDTO.setIcon(arg0.getIcon());
            menuDTO.setCreateTime(arg0.getCreateTime());
            list.add(menuDTO);
        }
        return list;
    }

    @Override
    public Object getMenuTree(List<Menu> menus) {
        List<Map<String,Object>> list = new LinkedList<>();
        menus.forEach(menu -> {
                    if (menu!=null){
                        List<Menu> menuList = findByPid(menu.getId());
                        Map<String,Object> map = new HashMap<>();
                        map.put("id",menu.getId());
                        map.put("label",menu.getName());
                        if(menuList!=null && menuList.size()!=0){
                            map.put("children",getMenuTree(menuList));
                        }
                        list.add(map);
                    }
                }
        );
        return list;
    }

    @Override
    public List<Menu> findByPid(long pid) {
        return DAO.find("select * from menu where pid = ?",pid);
    }

    @Override
    public List<MenuVo> buildMenus(List<MenuDTO> menuDTOS) {
        List<MenuVo> list = new LinkedList<>();
        menuDTOS.forEach(menuDTO -> {
            if (menuDTO!=null){
                List<MenuDTO> menuDTOList = menuDTO.getChildren();
                MenuVo menuVo = new MenuVo();
                menuVo.setName(menuDTO.getName());
                menuVo.setPath(menuDTO.getPath());

                // 如果不是外链
                if(!menuDTO.getiframe()){
                    if(menuDTO.getPid().equals(0L)){
                        //一级目录需要加斜杠，不然访问 会跳转404页面
                        menuVo.setPath("/" + menuDTO.getPath());
                        menuVo.setComponent(StringUtils.isBlank(menuDTO.getComponent())?"Layout":menuDTO.getComponent());
                    }else if(!StringUtils.isBlank(menuDTO.getComponent())){
                        menuVo.setComponent(menuDTO.getComponent());
                    }
                }
                menuVo.setMeta(new MenuMetaVo(menuDTO.getName(),menuDTO.getIcon()));
                if(menuDTOList!=null && menuDTOList.size()!=0){
                    menuVo.setAlwaysShow(true);
                    menuVo.setRedirect("noredirect");
                    menuVo.setChildren(buildMenus(menuDTOList));
                    // 处理是一级菜单并且没有子菜单的情况
                } else if(menuDTO.getPid().equals(0L)){
                    MenuVo menuVo1 = new MenuVo();
                    menuVo1.setMeta(menuVo.getMeta());
                    // 非外链
                    if(!menuDTO.getiframe()){
                        menuVo1.setPath("index");
                        menuVo1.setName(menuVo.getName());
                        menuVo1.setComponent(menuVo.getComponent());
                    } else {
                        menuVo1.setPath(menuDTO.getPath());
                    }
                    menuVo.setName(null);
                    menuVo.setMeta(null);
                    menuVo.setComponent("Layout");
                    List<MenuVo> list1 = new ArrayList<MenuVo>();
                    list1.add(menuVo1);
                    menuVo.setChildren(list1);
                }
                list.add(menuVo);
            }
        }
        );
        return list;
    }

    @Override
    public Map buildTree(List<MenuDTO> menuDTOS) {
        List<MenuDTO> trees = new ArrayList<MenuDTO>();

        for (MenuDTO menuDTO : menuDTOS) {

            if ("0".equals(menuDTO.getPid().toString())) {
                trees.add(menuDTO);
            }

            for (MenuDTO it : menuDTOS) {
                if (it.getPid().equals(menuDTO.getId())) {
                    if (menuDTO.getChildren() == null) {
                        menuDTO.setChildren(new ArrayList<MenuDTO>());
                    }
                    menuDTO.getChildren().add(it);
                }
            }
        }
        Map map = new HashMap();
        map.put("content",trees.size() == 0?menuDTOS:trees);
        map.put("totalElements",menuDTOS!=null?menuDTOS.size():0);
        return map;
    }

    @Override
    public LinkedHashSet<Menu> findByRoles_IdOrderBySortAsc(Long id) {
        List<Menu> list =  DAO.find("select * from roles_menus a left join menu b on a.menu_id = b.id where a.role_id = ? order by sort asc",id);
        return new LinkedHashSet<Menu>(list);
    }

    @Override
    public List<MenuDTO> findByRoles(List<RoleDTO> roles) {
        Set<Menu> menus = new LinkedHashSet<>();
        for (RoleDTO role : roles) {
            List<Menu> menus1 = this.findByRoles_IdOrderBySortAsc(role.getId()).stream().collect(Collectors.toList());
            menus.addAll(menus1);
        }

        List<MenuDTO> list = new ArrayList<>();
        for (Menu arg0 : menus) {
            MenuDTO menuDTO = new MenuDTO();
            menuDTO.setId(arg0.getId());
            menuDTO.setName(arg0.getName());
            menuDTO.setSort(arg0.getSort());
            menuDTO.setPath(arg0.getPath());
            menuDTO.setComponent(arg0.getComponent());
            menuDTO.setPid(arg0.getPid());
            menuDTO.setiFrame(arg0.getIFrame());
            menuDTO.setIcon(arg0.getIcon());
            menuDTO.setCreateTime(arg0.getCreateTime());
            list.add(menuDTO);
        }
        return list;
    }
}