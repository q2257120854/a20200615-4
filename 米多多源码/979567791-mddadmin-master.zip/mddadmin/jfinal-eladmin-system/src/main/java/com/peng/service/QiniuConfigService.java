package com.peng.service;

import com.jfinal.plugin.activerecord.Page;
import com.peng.model.QiniuConfig;

import java.util.List;

public interface QiniuConfigService<QiniuConfig>  extends BaseService  {

}