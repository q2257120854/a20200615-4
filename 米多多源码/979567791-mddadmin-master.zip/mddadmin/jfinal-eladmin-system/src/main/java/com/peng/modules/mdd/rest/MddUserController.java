package com.peng.modules.mdd.rest;

import com.alibaba.fastjson.JSON;
import com.jfinal.aop.Inject;
import com.jfinal.core.ActionKey;
import com.jfinal.core.Controller;
import com.jfinal.kit.HttpKit;
import com.jfinal.plugin.activerecord.Page;
import com.peng.mdd.model.MddUser;
import com.peng.mdd.service.MddUserService;
import com.peng.utils.PageUtil;

/**
* @author jie1
* @date 2019-05-15
*/
public class MddUserController extends Controller {

    @Inject
    private MddUserService mddUserService;

    /**
    * 查询
    */
    @ActionKey("api/mdd/user/query")
    public void query(){
        Long id = getParaToLong("id");
        Long pid = getParaToLong("pid");
        String phone = getPara("phone");
        Integer state = getParaToInt("state");
        Integer pageNumber = getParaToInt("page");
        Integer pageSize = getParaToInt("size");
        Page<MddUser> page = mddUserService.list(pageNumber,pageSize,id,phone,state,pid);
        renderJson(PageUtil.toPage(page));
    }

    /**
    * 新增
    */
    @ActionKey("api/mdd/user/add")
    public void add(){
        String json = HttpKit.readData(getRequest());
        MddUser mddUser = JSON.parseObject(json,MddUser.class);
        mddUser.save();

        renderJson(mddUser);
    }

    /**
    * 修改
    */
    @ActionKey("api/mdd/user/update")
    public void update(){
        String json = HttpKit.readData(getRequest());
        MddUser mddUser = JSON.parseObject(json,MddUser.class);
        mddUser.update();

        renderJson(mddUser);
    }

    /**
    * 删除
    */
    @ActionKey("api/mdd/user/del")
    public void delete(){
        Long id = getParaToLong(0);
        mddUserService.deleteById(id);
        renderNull();
    }
}
