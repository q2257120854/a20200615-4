package com.peng.service.provider;

import com.peng.model.QiniuContent;
import com.peng.service.QiniuContentService;


public class QiniuContentServiceProvider extends BaseServiceProvider<QiniuContent> implements QiniuContentService {

}