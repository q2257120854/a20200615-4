package com.peng.modules.mdd.rest;

import com.alibaba.fastjson.JSON;
import com.jfinal.aop.Inject;
import com.jfinal.core.ActionKey;
import com.jfinal.core.Controller;
import com.jfinal.kit.HttpKit;
import com.jfinal.plugin.activerecord.Page;
import com.peng.mdd.model.MddConfig;
import com.peng.mdd.service.MddConfigService;
import com.peng.utils.PageUtil;

/**
* @author jie1
* @date 2019-05-15
*/
public class MddConfigController extends Controller {

    @Inject
    private MddConfigService mddConfigService;

    /**
    * 查询
    */
    @ActionKey("api/mdd/config/query")
    public void query(){
        String mc_desc = getPara("mc_desc");
        Integer pageNumber = getParaToInt("page");
        Integer pageSize = getParaToInt("size");
        Page<MddConfig> page = mddConfigService.list(pageNumber,pageSize,mc_desc);
        renderJson(PageUtil.toPage(page));
    }

    /**
    * 新增
    */
    @ActionKey("api/mdd/config/add")
    public void add(){
        String json = HttpKit.readData(getRequest());
        MddConfig mddConfig = JSON.parseObject(json,MddConfig.class);
        mddConfig.save();

        renderJson(mddConfig);
    }

    /**
    * 修改
    */
    @ActionKey("api/mdd/config/update")
    public void update(){
        String json = HttpKit.readData(getRequest());
        MddConfig mddConfig = JSON.parseObject(json,MddConfig.class);
        mddConfig.update();

        renderJson(mddConfig);
    }

    /**
    * 删除
    */
    @ActionKey("api/mdd/config/del")
    public void delete(){
        Long id = getParaToLong(0);
        mddConfigService.deleteById(id);
        renderNull();
    }
}
