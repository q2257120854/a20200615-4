package com.peng.service.provider;

import com.jfinal.aop.Inject;
import com.jfinal.plugin.activerecord.Page;
import com.peng.model.User;
import com.peng.service.RoleService;
import com.peng.service.UserService;
import com.peng.service.dto.RoleDTO;
import com.peng.service.dto.UserDTO;
import com.peng.utils.MD5Helper;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.List;

public class UserServiceProvider extends BaseServiceProvider<User> implements UserService {

    @Inject
    private RoleService roleService;

    @Override
    public Page<UserDTO> queryAll(String username, String email, Boolean enabled, Integer pageNumber, Integer size) {
        StringBuffer sql = new StringBuffer("from user where 1=1 ");
        List<Object> para = new ArrayList<>();
        if (StringUtils.isNotBlank(username)) {
            sql.append(" and username like ?");
            para.add("%"+username+"%");
        }
        if (StringUtils.isNotBlank(email)) {
            sql.append(" and email like ?");
            para.add("%"+email+"%");
        }
        if (enabled != null) {
            sql.append(" and enabled = ?");
            para.add(enabled?1:0);
        }
        Page<User> page = DAO.paginate(pageNumber,size,"select *",sql.toString(),para.toArray());
        List<UserDTO> dtoList = new ArrayList<>();
        for (User arg0: page.getList()) {
            List<RoleDTO> roleList = roleService.findByUserId(arg0.getId());
            UserDTO userDTO = new UserDTO();
            userDTO.setId(arg0.getId());
            userDTO.setUsername(arg0.getUsername());
            userDTO.setAvatar(arg0.getAvatar());
            userDTO.setEmail(arg0.getEmail());
            userDTO.setPhone(arg0.getPhone());
            userDTO.setEnabled(arg0.getEnabled()==0?false:true);
            userDTO.setPassword(arg0.getPassword());
            userDTO.setCreateTime(arg0.getCreateTime());
            userDTO.setLastPasswordResetTime(arg0.getLastPasswordResetTime());
            userDTO.setRoles(roleList);
            dtoList.add(userDTO);
        }

        Page<UserDTO> page2 = new Page<>();
        page2.setList(dtoList);
        page2.setTotalRow(page.getTotalRow());
        return page2;
    }

    public User login(String username, String password) {
        User user = DAO.findFirst("select * from user where username = ? and password = ? and enabled = 1 limit 1",username, MD5Helper.encoderByMD5Salt(password));
        return user;
    }

    @Override
    public List<User> aa() {
        List<User> o = DAO.find("select b.* from users_roles a left join role b on a.role_id = b.id where a.user_id = ?",1);
        return o;
    }
}