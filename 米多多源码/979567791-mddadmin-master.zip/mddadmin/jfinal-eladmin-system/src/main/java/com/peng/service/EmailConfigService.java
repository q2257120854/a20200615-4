package com.peng.service;

public interface EmailConfigService<EmailConfig>  extends BaseService {



}