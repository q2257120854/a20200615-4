package com.peng.service.provider;

import com.peng.model.VerificationCode;
import com.peng.service.VerificationCodeService;


public class VerificationCodeServiceProvider extends BaseServiceProvider<VerificationCode> implements VerificationCodeService {

}