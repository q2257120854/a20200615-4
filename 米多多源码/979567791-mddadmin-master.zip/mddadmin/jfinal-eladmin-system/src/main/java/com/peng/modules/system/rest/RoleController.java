package com.peng.modules.system.rest;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.jfinal.aop.Before;
import com.jfinal.aop.Inject;
import com.jfinal.core.ActionKey;
import com.jfinal.core.Controller;
import com.jfinal.ext.interceptor.GET;
import com.jfinal.kit.HttpKit;
import com.jfinal.plugin.activerecord.Page;
import com.peng.interceptor.PUT;
import com.peng.model.Role;
import com.peng.model.RolesMenus;
import com.peng.model.RolesPermissions;
import com.peng.service.RoleService;
import com.peng.service.RolesMenusService;
import com.peng.service.RolesPermissionsService;
import com.peng.service.dto.RoleDTO;
import com.peng.utils.PageUtil;

import java.util.Date;
import java.util.List;

/**
 * Created by wupeng on 2019/4/18.
 */
public class RoleController extends Controller {

    @Inject
    private RoleService roleService;
    @Inject
    private RolesMenusService rolesMenusService;
    @Inject
    private RolesPermissionsService rolesPermissionsService;

    @ActionKey("api/getroles")
    public void getRoles(){
        Long id = getParaToLong(0);
        renderJson(roleService.queryById(id));
    }

    /**
     * 返回全部的角色，新增用户时下拉选择
     */
    @ActionKey("api/roles/all")
    @Before(GET.class)
    public void getAll() {
        List<RoleDTO> list = roleService.queryAll();
        renderJson(list);
    }

    /**
     * 修改角色权限
     */
    @ActionKey("api/roles/permission")
    @Before(PUT.class)
    public void updatePermission(){
        String json = HttpKit.readData(getRequest());
        JSONObject reqJson = JSON.parseObject(json);
        Long id = reqJson.getLong("id");
        JSONArray permissions = reqJson.getJSONArray("permissions");
        rolesPermissionsService.deleteByRoleId(id);
        for (Object obj: permissions) {
            JSONObject jsonObj = (JSONObject)obj;
            Long perId = jsonObj.getLong("id");
            RolesPermissions rp = new RolesPermissions();
            rp.setRoleId(id);
            rp.setPermissionId(perId);
            rp.save();
        }
        renderJson("");
    }

    /**
     * 修改角色菜单
     */
    @ActionKey("api/roles/menu")
    @Before(PUT.class)
    public void updateMenu(){
        String json = HttpKit.readData(getRequest());
        JSONObject reqJson = JSON.parseObject(json);
        Long id = reqJson.getLong("id");
        JSONArray permissions = reqJson.getJSONArray("menus");
        rolesMenusService.deleteByRoleId(id);
        for (Object obj: permissions) {
            JSONObject jsonObj = (JSONObject)obj;
            Long menuId = jsonObj.getLong("id");
            RolesMenus rm = new RolesMenus();
            rm.setRoleId(id);
            rm.setMenuId(menuId);
            rm.save();
        }
        renderJson("");
    }

    /**
     * 查询角色
     */
    @ActionKey("api/roles/query")
    public void query(){
        String name = getPara("name");
        Integer pageNumber = getParaToInt("page");
        Integer size = getParaToInt("size");
        Page<RoleDTO> page = roleService.queryAll(name,pageNumber,size);
        renderJson(PageUtil.toPage(page));
    }

    /**
     * 新增角色
     */
    @ActionKey("api/roles/add")
    public void add(){
        String json = HttpKit.readData(getRequest());
        JSONObject reqJson = JSON.parseObject(json);
        String name = reqJson.getString("name");
        String dataScope = reqJson.getString("dataScope");
        String remark = reqJson.getString("remark");

        Role role = new Role();
        role.setName(name);
        role.setDataScope(dataScope);
        role.setRemark(remark);
        role.setCreateTime(new Date());
        role.save();
        renderJson(role);
    }

    /**
     * 修改角色
     */
    @ActionKey("api/roles/update")
    public void update(){
        String json = HttpKit.readData(getRequest());
        JSONObject reqJson = JSON.parseObject(json);
        Long id = reqJson.getLong("id");
        String name = reqJson.getString("name");
        String dataScope = reqJson.getString("dataScope");
        String remark = reqJson.getString("remark");

        Role role = (Role) roleService.findById(id);
        role.setName(name);
        role.setDataScope(dataScope);
        role.setRemark(remark);
        role.update();
        renderJson(role);
    }

    /**
     * 删除角色
     */
    @ActionKey("api/roles/del")
    public void delete(){
        Long id = getParaToLong(0);
        roleService.deleteById(id);
        renderJson("删除角色");
    }

}
