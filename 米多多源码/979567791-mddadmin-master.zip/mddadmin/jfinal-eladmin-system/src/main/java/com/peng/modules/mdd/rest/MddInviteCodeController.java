package com.peng.modules.mdd.rest;

import com.alibaba.fastjson.JSON;
import com.jfinal.aop.Inject;
import com.jfinal.core.ActionKey;
import com.jfinal.core.Controller;
import com.jfinal.kit.HttpKit;
import com.jfinal.plugin.activerecord.Page;
import com.peng.mdd.model.MddInviteCode;
import com.peng.mdd.service.MddInviteCodeService;
import com.peng.utils.PageUtil;
import org.apache.commons.lang3.RandomStringUtils;

/**
* @author jie1
* @date 2019-06-17
*/
public class MddInviteCodeController extends Controller {

    @Inject
    private MddInviteCodeService mddInviteCodeService;

    /**
    * 查询
    */
    @ActionKey("api/mdd/inviteCode/query")
    public void query(){
        Integer is_use = getParaToInt("is_use");
        Integer pageNumber = getParaToInt("page");
        Integer pageSize = getParaToInt("size");
        Page<MddInviteCode> page = mddInviteCodeService.list(pageNumber,pageSize,is_use);
        renderJson(PageUtil.toPage(page));
    }

    /**
    * 新增
    */
    @ActionKey("api/mdd/inviteCode/add")
    public void add(){
        String json = HttpKit.readData(getRequest());
        MddInviteCode mddInviteCode = JSON.parseObject(json,MddInviteCode.class);
        mddInviteCode.save();

        renderJson(mddInviteCode);
    }

    /**
    * 修改
    */
    @ActionKey("api/mdd/inviteCode/update")
    public void update(){
        String json = HttpKit.readData(getRequest());
        MddInviteCode mddInviteCode = JSON.parseObject(json,MddInviteCode.class);
        mddInviteCode.update();

        renderJson(mddInviteCode);
    }

    /**
    * 删除
    */
    @ActionKey("api/mdd/inviteCode/del")
    public void delete(){
        Long id = getParaToLong(0);
        mddInviteCodeService.deleteById(id);
        renderNull();
    }

    /**
     * 生成邀请码
     */
    @ActionKey("api/mdd/inviteCode/generate")
    public void generate(){
        Integer id = getParaToInt(0);
        for (int i = 0;i < id;i++){
            String code = RandomStringUtils.randomNumeric(6);
            MddInviteCode inviteCode = mddInviteCodeService.findByCode(code);
            if (inviteCode != null){
                i--;
                continue;
            }
            inviteCode = new MddInviteCode();
            inviteCode.setCode(code);
            inviteCode.save();
        }

        renderNull();
    }
}
