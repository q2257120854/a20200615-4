package com.peng.service.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * @author jie
 * @date 2018-12-03
 */
public class PermissionDTO implements Serializable{

	private Long id;

	private String name;

	private Long pid;

	private String alias;

	private Date createTime;

	private String actionKey;

	private List<PermissionDTO>  children;

	@Override
	public String toString() {
		return "Permission{" +
				"id=" + id +
				", name='" + name + '\'' +
				", pid=" + pid +
				", alias='" + alias + '\'' +
				", createTime=" + createTime +
				'}';
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Long getPid() {
		return pid;
	}

	public void setPid(Long pid) {
		this.pid = pid;
	}

	public String getAlias() {
		return alias;
	}

	public void setAlias(String alias) {
		this.alias = alias;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public List<PermissionDTO> getChildren() {
		return children;
	}

	public void setChildren(List<PermissionDTO> children) {
		this.children = children;
	}

	public String getActionKey() {
		return actionKey;
	}

	public void setActionKey(String actionKey) {
		this.actionKey = actionKey;
	}
}
