import Vue from 'vue';
import Vuex from 'vuex';
Vue.use(Vuex);

// vuex 设置
const ADD_COUNT = 'ADD_COUNT'; // 用常量代替事件类型，使得代码更清晰
const REMOVE_COUNT = 'REMOVE_COUNT';
//注册状态管理全局参数
const state = {
    token:'',
    userID:'123',
}

const mutations = {
    [ADD_COUNT] (state, token) { // 第一个参数为 state 用于变更状态 登录
      sessionStorage.setItem("token", token);
      state.token = token;
      
    },
    [REMOVE_COUNT] (state, token) { // 退出登录
 
      sessionStorage.removeItem("token", token);
 
      state.token = token;
    },
}

export default new Vuex.Store({
    state,
    mutations
})