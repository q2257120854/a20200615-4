
export const popupToggle ={
    data() {
        return {
            popupMod:{
                isShow:false
            }
        }
    },
    methods:{
        toggleShow(pop){
            this.popupMod[pop] = !this.popupMod[pop]
        }
    }
}

