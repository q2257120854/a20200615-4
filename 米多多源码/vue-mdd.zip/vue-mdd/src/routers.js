
const Index =resolve => require(['@/views/Index'], resolve);
const Information =resolve => require(['@/views/Information'], resolve);
const Register =resolve => require(['@/views/Register'], resolve);
const Login =resolve => require(['@/views/Login'], resolve);

// 任务大厅，任务详情，任务验证，任务发布
const TaskHall =resolve => require(['@/views/TaskHall'], resolve);
const TaskDetails =resolve => require(['@/views/TaskDetails'], resolve);
const TaskVerify =resolve => require(['@/views/TaskVerify'], resolve);
const TaskPublish =resolve => require(['@/views/TaskPublish'], resolve);
// 空白页，刷新用
const EmptyPage =resolve => require(['@/views/EmptyPage'], resolve);

// 我的任务，我的记录，我的发布，  我的发布审核列表
const MyTask =resolve => require(['@/views/MyTask'], resolve);
const MyTaskTask =resolve => require(['@/views/MyTask-Task'], resolve);
const MyTaskRecord =resolve => require(['@/views/MyTask-Record'], resolve);
const MyTaskPublish =resolve => require(['@/views/MyTask-Publish'], resolve);

//  任务审核
const TaskAudit =resolve => require(['@/views/TaskAudit'], resolve);
//  任务失败原因
const TaskFail =resolve => require(['@/views/TaskFail'], resolve);
//  任务申诉页面
const TaskAppeal =resolve => require(['@/views/TaskAppeal'], resolve);

// 个人中心
const UserCenter =resolve => require(['@/views/my/UserCenter'], resolve);
// 保证金
const CashDeposit =resolve => require(['@/views/my/CashDeposit'], resolve);
// 保证金充值
const CashDepositBuy =resolve => require(['@/views/my/CashDepositBuy'], resolve);
// 申退保证金
const EarnestMoneyBack =resolve => require(['@/views/my/EarnestMoneyBack'], resolve);
// 我的战队
const MyTeam =resolve => require(['@/views/my/MyTeam'], resolve);
// 充值
const Buy =resolve => require(['@/views/my/Buy'], resolve);
// 充值成功
const BuySucceed =resolve => require(['@/views/my/BuySucceed'], resolve);
// 收支账单
const Bill =resolve => require(['@/views/my/Bill'], resolve);
// 我的二维码
const QrCode =resolve => require(['@/views/my/QrCode'], resolve);
// 米币提现
const MiCash =resolve => require(['@/views/my/MiCash'], resolve);
// 绑定支付宝
const BindAlipay =resolve => require(['@/views/my/BindAlipay'], resolve);
// 推广提现
const ShareCash =resolve => require(['@/views/my/ShareCash'], resolve);
// 粉丝关注
const Followers =resolve => require(['@/views/my/Followers'], resolve);
const FollowersChildren =resolve => require(['@/views/my/FollowersChildren'], resolve);
// 店铺
const Shop =resolve => require(['@/views/my/Shop'], resolve);
const ShopTop =resolve => require(['@/views/my/ShopTop'], resolve);

// 常见问题
const FAQ =resolve => require(['@/views/my/FAQ'], resolve);
const FAQDetail =resolve => require(['@/views/my/FAQDetail'], resolve);
// 意见反馈
const Feedback =resolve => require(['@/views/my/Feedback'], resolve);




const routers =[{
    path:'/index',
    name:'index',
    component:Index,
    meta:{index: 0, nav:true}
}, {
    path:'/information',
    name:'information',
    component:Information,
    meta:{index: 0,requireAuth: true, nav:true,keepAlive:true}
}, { 
    path:'/register',
    name:'register',
    component:Register,
    meta:{index: 0,keepAlive:true}
}, { 
    path:'/login',
    name:'login',
    component:Login,
    meta:{index: 0,keepAlive:true}
}, { 
    path:'/taskhall',
    name:'taskhall',
    component:TaskHall,
    meta:{index: 1,requireAuth: true,keepAlive:true}
},{ 
    path:'/taskdetails/:task_id',
    name:'taskdetails',
    component:TaskDetails,
    meta:{index: 2,requireAuth: true,keepAlive:true}
},{ 
    path:'/taskverify',
    name:'taskverify',
    component:TaskVerify,
    meta:{index: 3,requireAuth: true,keepAlive:true}
}, { 
    path:'/taskpublish',
    name:'taskpublish',
    component:TaskPublish,
    meta:{index: 2,requireAuth: true,keepAlive:true}
}, { 
    path:'/mytask',
    // name:'mytask',
    component:MyTask,
    // meta:{index: 1,requireAuth: true, nav:true},
    children: [
        { path: '',redirect:'t',component: MyTaskTask,  meta:{requireAuth: true, nav:true}},
        { path: 't',component: MyTaskTask, meta:{requireAuth: true,keepAlive:true, nav:true}},
        { path: 'r',component: MyTaskRecord, meta:{requireAuth: true,keepAlive:true, nav:true}},
        { path: 'p', component: MyTaskPublish, meta:{requireAuth: true,keepAlive:true, nav:true} }

      ]
}, { 
    path:'/taskaudit',
    name:'taskaudit',
    component:TaskAudit,
    meta:{index: 1,requireAuth: true,keepAlive:true}
}, { 
    path:'/emptyPage',
    name:'emptyPage',
    component:EmptyPage,
    meta:{index: 1,requireAuth: true,keepAlive:true}
}, { 
    path:'/taskfail',
    name:'taskfail',
    component:TaskFail,
    meta:{index: 2,requireAuth: true,keepAlive:true}
}, { 
    path:'/taskappeal',
    name:'taskappeal',
    component:TaskAppeal,
    meta:{index: 3,requireAuth: true,keepAlive:true}
}, { 
    path:'/usercenter',
    name:'usercenter',
    component:UserCenter,
    meta:{index: 1,requireAuth: true,keepAlive:true, nav:true}
}, { 
    path:'/cashdeposit',
    name:'cashdeposit',
    component:CashDeposit,
    meta:{index: 2,requireAuth: true,keepAlive:true}
}, { 
    path:'/cashdepositbuy',
    name:'cashdepositbuy',
    component:CashDepositBuy,
    meta:{index: 3,requireAuth: true,keepAlive:true}
}, { 
    path:'/earnestmoneyback',
    name:'earnestmoneyback',
    component:EarnestMoneyBack,
    meta:{index: 2,requireAuth: true,keepAlive:true}
}, { 
    path:'/myteam',
    name:'myteam',
    component:MyTeam,
    meta:{index: 2,requireAuth: true,keepAlive:true}
}, { 
    path:'/buy',
    name:'buy',
    component:Buy,
    meta:{index: 2,requireAuth: true,keepAlive:true}
}, { 
    path:'/buysucceed',
    name:'buysucceed',
    component:BuySucceed,
    meta:{index: 3,requireAuth: true,keepAlive:true}
}, { 
    path:'/bill',
    name:'bill',
    component:Bill,
    meta:{index: 2,requireAuth: true,keepAlive:true}
}, { 
    path:'/qrcode',
    name:'qrcode',
    component:QrCode,
    meta:{index: 2,requireAuth: true,keepAlive:true}
}, { 
    path:'/micash',
    name:'micash',
    component:MiCash,
    meta:{index: 2,requireAuth: true,keepAlive:true}
}, { 
    path:'/bindalipay',
    name:'bindalipay',
    component:BindAlipay,
    meta:{index: 2,requireAuth: true,keepAlive:true}
}, { 
    path:'/sharecash',
    name:'sharecash',
    component:ShareCash,
    meta:{index: 2,requireAuth: true,keepAlive:true}
}, { 
    path:'/followers',
    // name:'followers',
    component:Followers,
    meta:{index: 2,requireAuth: true},
    children: [
        { path: '',redirect:'t',component: FollowersChildren,  meta:{requireAuth: true}},
        { path: 't',component: FollowersChildren, meta:{requireAuth: true,keepAlive:true}},
        { path: 'r',component: FollowersChildren, meta:{requireAuth: true,keepAlive:true}}

      ]
}, { 
    path:'/shop',
    name:'shop',
    component:Shop,
    meta:{index: 2,requireAuth: true,keepAlive:true}
}, { 
    path:'/shoptop',
    name:'shoptop',
    component:ShopTop,
    meta:{index: 2,requireAuth: true,keepAlive:true}
}, { 
    path:'/faq',
    name:'faq',
    component:FAQ,
    meta:{index: 2,requireAuth: true,keepAlive:true}
}, { 
    path:'/faqdetail',
    name:'faqdetail',
    component:FAQDetail,
    meta:{index: 3,requireAuth: true,keepAlive:true}
}, { 
    path:'/feedback',
    name:'feedback',
    component:Feedback,
    meta:{index: 2,requireAuth: true,keepAlive:true}
}, { 
    path:'/',
    redirect:'/index',
    meta:{index: 0}
}]

export default routers;