<template>
    <div id="app">
        <!-- <transition :name="transitionName" > -->
            <keep-alive>
              <!-- 1 -->
                <router-view v-if="!$route.meta.keepAlive" :class="{'router-view':$route.meta.nav}" />
            </keep-alive>
            <router-view v-if="$route.meta.keepAlive" :class="{'router-view':$route.meta.nav}" />
            

            <CNav v-if="$route.meta.nav" />
        <!-- </transition> -->

       <!--  <transition :name="transitionName" >
         2
       </transition> -->
    </div>
</template>

<script>

import CNav from '@/components/CNav'

export default {
    name: 'App',
    components: {
        CNav
    },
    data (){
        return {
            transitionName:null
        }
    },
    created(){
        // console.log()
        const _this = this

        // 判断是否在APP,并且查看剪贴板内容
        if (/LT-APP/.test(navigator.userAgent)) {
            jsBridge.ready(function () { 
                // 打开app查看剪贴板内容
                _this.getClip()
                // 当App被激活，回到前台时触发。查看剪贴板内容
                jsBridge.onAppEnterForeground(function(){
                    jsBridge.getClipboardText(function(text) {
                        _this.getClip()
                    });
                });
            });
        }
    },
    watch: {
        $route(to,from) {
            if(to.meta.index > from.meta.index){
                this.transitionName = 'slide-left';
            }else{
                this.transitionName = 'slide-right';
            }
        }
    },
    methods:{
        // 查看剪贴板
        getClip(){
            const _this = this
            jsBridge.getClipboardText(function(text) {
                let tId = text.slice(text.indexOf('￥')+1,text.lastIndexOf('￥'))
                let tTit =text.slice(text.indexOf('【')+1,text.indexOf('赏'))
                _this.axios.get('/task/detail',{params:{task_id:tId}})
                    .then((response) => {
                        jsBridge.setClipboardText(' ');
                        if(response.data.code == 0 ){
                            _this.$dialog.confirm({
                                title: '注意',
                                message: '是否打开 "'+tTit+'" 这个任务？'
                            }).then(() => {
                                _this.$router.push('/taskdetails/'+tId)
                            }).catch(() => {
                            // on cancel
                            });
                        }
                    })
            });
        }
    }
}
</script>

<style>
#app {font-size: 12px; color: #333;width: 100%;box-sizing: border-box;}
.rowtop{
  box-sizing: border-box;
}
.van-row{
  box-sizing: border-box;
}
.mytask{
  width: 100%;
  box-sizing: border-box;
}
#login{
  box-sizing: border-box;
  width: 100%;
}
.from-register input{
  width: 80%  !important;
}
.from-register{
  padding: 10.625rem 0 1.25rem !important;
  box-sizing: border-box !important;
}
@media screen and (min-width: 700px) {
  html {
     font-size: 15px !important;
  }
  .page,#nav-yx,#index,#page,.mytask,#login ,#register{
    width: 500px !important;
    margin-left: 35% !important;
  }
  .list-task,.tag-slection,.rowtop,.task-hall-tit,.wgd,.tit,.van-row,.van-cell,.upload-img,.explain-img,.step-list,.content{
    width: 500px !important;
  }
}
.router-view{
    position: absolute; width: 100%; top: 0;  bottom: 48px; overflow-y: scroll; 
    -webkit-overflow-scrolling: touch
}

lg-pre .lg-preview-img{ width: 76% }

.slide-right-enter-active,
.slide-right-leave-active,
.slide-left-enter-active,
.slide-left-leave-active {
  will-change: transform;
  transition-timing-function: linear;
  background: #f4f4f4;
  transition: all 500ms;
  position: absolute;top: 0;left: 0;bottom: 0;

  z-index: 99;
  /* background: #fff; */
  width: 20rem;
}
.slide-right-enter {
  opacity: 1;
  transform: translate3d(-100%, 0, 0);
}

.slide-right-leave-active {
  opacity: 0;
  z-index: 7;
  transform: translate3d(20%, 0, 0);
}

.slide-left-enter {
  opacity: 1;
  transform: translate3d(100%, 0, 0);
}
.slide-left-leave-active {
  opacity: 0;
  z-index: 7;
  transform: translate3d(-20%, 0, 0);
}
</style>
