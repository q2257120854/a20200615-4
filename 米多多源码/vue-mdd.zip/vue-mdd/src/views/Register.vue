<template>
    <div id="register" class="register">
        <div class="from-register">
            
            <van-field class="text" v-model="phone" type="number" placeholder="请输入手机号" >
                <i slot="left-icon" class="lft-icon" ><img src="@/common/images/i_phone.png" alt=""></i>
            </van-field>
            <van-field class="text" v-model="authCode"  placeholder="请输入验证码" >
                <i slot="left-icon" class="lft-icon" ><img src="@/common/images/i_yzm.png" alt=""></i>
                <timerBtn slot="button" class="btn" :start='start' @countDown ='start=false' @click.native='sendSms' />
                <!-- <van-button size="small" @click="getCode" type="primary">发送</van-button> -->
            </van-field>
            <van-field class="text" v-model="pwd" type="password" placeholder="请输入密码" >
                <i slot="left-icon" class="lft-icon" ><img src="@/common/images/i_mm.png" alt=""></i>
            </van-field>
            <div  v-if="forget" >
            <van-field class="text"v-model="nickname"  placeholder="请输入昵称" >
                <i slot="left-icon" class="lft-icon" ><img src="@/common/images/i_nc.png" alt=""></i>
            </van-field>
            <van-field class="text" v-if="$route.query.code"  type="number" v-model="invitePhone"  disabled>
                <i slot="left-icon" class="lft-icon" ><img src="@/common/images/i_yqr.png" alt=""></i>
            </van-field>
            <van-field class="text" v-else  type="number" v-model="invitePhone" placeholder="请输入邀请人手机号" >
                <i slot="left-icon" class="lft-icon" ><img src="@/common/images/i_yqr.png" alt=""></i>
            </van-field>

            <div class="row-protocol"><van-checkbox v-model="protocol">我同意<i @click.stop="toggleShow('loginProtocol')">《注册协议》</i>的全部内容</van-checkbox></div>
            </div>

            <!-- <p>{{pwd}}</p> -->
            <p class="link" v-if="isApp"><router-link :to="{name:'login'}" tag="a" >返回登录</router-link></p>
            <van-button class="btn-yellow" @click="registerSubmit" type="primary">{{ forget | fontChange}}</van-button>

                <!-- <timerBtn slot="button" /> -->
        </div>
        <!-- 注册协议 -->
        <van-popup class="popup-mod" v-model="popupMod.loginProtocol">
            <TopBar :title="'注册协议'" >
                <i slot="lft" class="iconfont  icon-iconfont-edu11" @click="toggleShow('loginProtocol')"></i>
            </TopBar>
            <div class="bd">
                <iframe  class="p-scroll" src="../../static/html/zcxy.html"   frameborder="0"></iframe>
            </div>
        </van-popup>
    </div>
</template>

<script>
import timerBtn from '@/components/timerBtn'
import TopBar from '@/components/TopBar'
import { popupToggle } from '@/mixin/popupToggle'
// import axios from 'axios';
export default {
    name: 'Register',
    data() {
        return {
            phone:'',
            authCode:'',
            pwd:'',
            nickname:'',
            invitePhone:'',
            inviteCode:'',
            start:false,
            forget:true,
            isApp:true,
            protocol:false,
            popupMod:{
                loginProtocol:false
            }
        }
    },
    components: {
        timerBtn, TopBar
    },
    mixins:[popupToggle],
    filters:{
        fontChange:function(val){
            return val ? '立即注册' : '确认修改'
        }
    },
    created(){
        // console.log(this.popupMod)
        if(localStorage.getItem('token')){
            this.$router.push('/')
        }
        if(this.$route.query.code){
            this.invitePhone=this.$route.query.code;
        }
        if(this.$route.query.type){
            this.forget = false
        }
        if (/LT-APP/.test(navigator.userAgent )== false) {
            this.isApp = false
        }
        // console.log(this.$route.query.code)
    },
    methods: {
        sendSms() {
            this.axios.get('/user/sendsms',{params:{phone:this.phone}})
                .then((response) => {
                    if(response.data.code == 0){
                        this.start = true;
                        this.$toast(response.data.msg)
                    }else{

                        this.$toast(response.data.msg)
                    }
                })
            
        },
        getCode() {
            if( this.phone == ''){ 
                this.$toast('手机号不能为空')
                return false;
            }
            this.axios.get('/user/sendsms',{params:{'phone':this.phone}})
                .then((response) => {
                    // console.log(response.data.msg)
                    this.$toast(response.data.msg)
                }),(error) => {
                    console.log(error)
                    
                }
        },
        registerSubmit() {


            if( this.phone == '') {
                this.$toast('手机号不能为空')
                return false;
            }else if( this.authCode == '') {
                this.$toast('验证码不能为空')
                return false;
            }else if( this.pwd == '') {
                this.$toast('密码不能为空')
                return false;
            }

            let loading = this.$toast.loading({
                forbidClick:true,
                duration:0,
                message: '加载中...'
            })

            let api
            if(this.forget){
                api ='/user/reg'
                if( this.nickname == ''){
                    this.$toast('昵称不能为空')
                    return false;
                }else if( this.protocol == false) {
                    this.$toast('请同意《注册协议》')
                    return false;
                }
            }else{
                api ='/user/forgetpwd'
            }
            this.axios.post(api,this.qs.stringify({'phone':this.phone, 'auth_code':this.authCode, 'pwd':this.pwd, 'invite_phone':this.invitePhone, 'invite_code':this.inviteCode,'nickname':this.nickname}),{emulateJSON: true})
            // this.axios.post('/user/reg',{params:{'phone':this.phone, 'authCode':this.authCode, 'pwd':this.pwd, 'invitePhone':this.invitePhone}},{emulateJSON: true})
            // this.axios.post('/user/reg',{'phone':this.phone, 'authCode':this.authCode, 'pwd':this.pwd, 'invitePhone':this.invitePhone},{emulateJSON: true})
                .then(reponse => {
                        if(reponse.data.code == 0 ){
                            loading.clear()

                            if (this.isApp == false) {
                                window.location.href ="https://dibaqu.com/yyiQ"
                            }else if( this.forget){
                                // 注册成功后 登录
                                this.axios.post('/user/login',this.qs.stringify({'phone':this.phone, 'pwd':this.pwd}),{emulateJSON: true})
                                    .then(reponse => {
                                        if(reponse.data.code == 0){
                                            localStorage.setItem('token',reponse.data.token);
                                            localStorage.setItem('phone',reponse.data.info.phone);
                                            localStorage.setItem('id',reponse.data.info.id);
                                            localStorage.setItem('head_img',reponse.data.info.head_img);
                                            localStorage.setItem('nickname',reponse.data.info.nickname);

                                            // 判断是否在APP,并且发送用户id
                                            
                                            if (/LT-APP/.test(navigator.userAgent)) {
                                                jsBridge.ready(function () { 

                                                    let idS =reponse.data.info.id.toString()
                                                    jsBridge.jiguang.setAlias(idS, function(alias){
                                                        // alert("设置的别名"+alias);
                                                    });
                                                });
                                            }

                                            let url =this.$route.query.redirect;
                                            if( url != undefined ){
                                                this.$router.push(url)
                                            }else{
                                                this.$router.push('/')
                                            }
                                            
                                            // this.$router.push({name:'login'})
                                        }else{
                                           // console.log(reponse.data.msg);
                                            this.$toast(reponse.data.msg);
                                            // console.log(this.$store)
                                        }
                                        
                                    })
                            }else {
                                
                                this.$router.push('/login')
                            }
                            // this.$router.push({name:'login'})
                        }else{
                           // console.log(reponse.data.msg);
                            this.$toast(reponse.data.msg);
                        }
                })
        }
    }
}
</script>

<style lang="scss">
#register{
    width: 100%; min-height: 100vh; background:url('../common/images/bg_logo.jpg') no-repeat center  -30px #fff; background-size: 100% auto;

    .btn { padding:0 20px; }
    .from-register{
        padding: 170px 30px 20px;
        .link {text-align: right; color: #999; line-height: 40px; padding-right: 10px;}
        .btn-yellow { margin-top: 10px;}
    }


    .row-protocol {
        font-size: 12px; text-align: center; margin: 10px 0;
        .van-checkbox__icon--round .van-icon {
            color:#fff;
        }
        i {
            color:#1989fa;
        }
    }
}
</style>
