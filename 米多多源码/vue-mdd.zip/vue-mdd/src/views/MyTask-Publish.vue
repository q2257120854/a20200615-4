<template>
    <div class="mytaskpublish">
        <Scroll class="scroll-wrapper" :pullup="true" ref="listScroll"  v-on:scrollToEnd="upData(paramsPublish)"  >
            <div class="scroll">

                <div class="list-publish">
                    <ul>
                        <router-link v-for="(item,idx) in myPublishList" :key="idx" tag="li"   :to="'/taskdetails/'+item.id ">
                            <div class="hd">
                                {{item.type_name}}<span>{{item.id}} <i>{{item.title}}</i></span>
                            </div>
                            <div class="bd">
                                <span>单&nbsp;&nbsp;&nbsp;价：{{item.price}}元</span>
                                <span>总&nbsp;&nbsp;&nbsp;量：{{item.total_count}}</span>
                                <span>进行中：{{item.unsubmit_count+item.fail_count}}</span>
                                <span>剩&nbsp;&nbsp;&nbsp;余：{{item.total_count-(item.finish_count+item.submit_count+item.unsubmit_count+item.fail_count)}}</span>
                                <span>已完成：{{item.finish_count}}</span>
                                <span>待审核：{{item.submit_count}}</span>
                            </div>
                            
                            <!-- 状态:1=待审核,2=未通过,3=进行中,4=已暂停,5=已结束 -->
                            <!-- 刚发布任务，等待平台审核  @click="delTask()" 1 -->
                            <div v-if="item.state == 1 " class="ft-btn">
                                <i class="delete" @click.stop="delTask(item,idx)" >删&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;除</i>
                                <i class="no">待&nbsp;审&nbsp;核</i>
                            </div>

                            <!-- 未通过审核的任务   2 -->
                            <div v-else-if="item.state == 2 " class="ft-btn">
                                <i class="delete" @click.stop="delTask(item,idx)">删&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;除</i>
                                <router-link tag="i" :to="{path:'/taskpublish',query:{type:'xg',task_id:item.id}}" class="delete">修&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;改</router-link>
                                <i class="no">审核失败</i>
                                <p v-if="item.reject_reason  ">失败原因:{{item.reject_reason}}</p>
                            </div>
                            
                            <!-- 进行中的任务 3-->
                            <div v-else-if="item.state == 3 " class="ft-btn">
                                <i class="send" v-if="item.submit_count == 0" @click.stop>审&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;核</i>
                                <router-link v-else tag="i" :to="{path:'/taskaudit',query:{task_id:item.id}}"  class="send" >审&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;核</router-link>
                                <i class="send" v-show="item.is_end == 0" @click.stop="addCount(item)">追加数量</i>
                                <i class="send" v-show="item.is_end == 0"  @click.stop="addPrice(item)">上调价格</i>
                                <i class="send" v-show="item.is_end == 0"  @click.stop="pauseTask(item)">暂&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;停</i>
                                <i class="send" @click.stop="closeTask(item)">下&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;架</i>
                                <!-- <i class="send">刷&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;新</i>
                                <i class="send">推&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;荐</i> -->
                                <i class="send" v-show="item.is_end == 0"  @click.stop="stickTask(item)">置&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;顶</i>
                            </div>

                            <!-- 暂停中的任务 4 -->
                            <div v-else-if="item.state == 4 " class="ft-btn">
                                <i class="send" v-if="item.submit_count == 0" @click.stop>审&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;核</i>
                                <router-link v-else tag="i" :to="{path:'/taskaudit',query:{task_id:item.id}}"  class="send" >审&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;核</router-link>
                                <i class="send" v-show="item.is_end == 0" @click.stop="addCount(item)">追加数量</i>
                                <i class="send" v-show="item.is_end == 0" @click.stop="addPrice(item)">上调价格</i>
                                <i class="send" v-show="item.is_end == 0" @click.stop="openTask(item)">开&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;启</i>
                                <i class="send" @click.stop="closeTask(item)">下&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;架</i>
                            </div>

                            <!--  结束的任务  5-->                
                            <div v-else="item.state == 5 " class="ft-btn">
                                <i class="delete" @click.stop="delTask(item,idx)" >删&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;除</i>
                                <router-link tag="i" :to="{path:'/taskpublish',query:{type:'cf',task_id:item.id}}" class="delete" >重发任务</router-link>
                                <i class="no">已&nbsp;结&nbsp;束</i>
                            </div>
                                

                            <div class="time">
                                <!-- <div class="lft">发布：{{item.add_time}}</div>
                                <div class="rgt">截止：{{item.end_time}}</div> -->
                                <div>发布：{{item.add_time}}</div>
                                <div>截止：{{item.end_time}}</div>
                                <div v-if="item.top_expire_time">置顶到期时间：{{item.top_expire_time}}</div>
                            </div>
                        </router-link>

                    </ul>
                </div>
                <div v-if="paramsPublish.dataNo" style="text-align: center">无数据</div>
                <div v-else style="position: absolute;width:100%; height: 30px; line-height: 30px; text-align: center; bottom: -30px">上拉加载</div>
            </div>
        </Scroll>

        <!-- 追加数量和上调价格  弹窗 -->
        <van-dialog  v-model="popupAdd.addShow"  :title="popupAdd.title"   show-cancel-button @confirm="sendPopupVal" >
            <van-field v-model="popupAdd.addVal" type="number" :placeholder="popupAdd.placeholder" />
        </van-dialog>


        <!-- 置顶弹窗 -->
        <van-popup class="popup_stick" v-model="popupStick.stickShop">
            <div class="hd">
                <h3>请输入置顶时长</h3>
                <p>注:置顶功能收费标准为15元/小时</p>
                <p>价格较高，请充分评估后再选择使用</p>
            </div>
            <div class="bd">
                <van-field v-model="popupStick.stickTime" type="number" input-align="right" label-width="50"  placeholder="" ><i slot="label">置顶</i><i slot="icon">小时</i></van-field>
            </div>
            <div class="row-btn">
                <i @click="colseStickPop">取消</i>
                <i @click="getStick">确认</i>
            </div>
            <div class="ft">
                <p>1.推荐或置顶成功后未到期前可以续期，时间自动累加；</p>
                <p>2.推荐或置顶只针对本任务有效，任务不能中途更换；</p>
                <p>3.任务中途暂停，推荐或置顶时间不会暂停；</p>
                <p>4.提前下架或置顶未到期任务提前完成，剩余推荐或置顶时间不会保留也不会折算成任务币返还；</p>  
            </div>
        </van-popup>
    </div>
</template>

<script>
import ListMission from '@/components/ListMission'
import ListPublish from '@/components/ListPublish'

import Scroll from '@/components/Scroll'
// import axios from 'axios';
export default {
    name: 'MyTaskPublish',
    data() {
        return {
            paramsPublish:{
                state:'',
                pageNumber:1,
                pageSize:10,
                url:'/task/mypublish',
                add:true,
                dataNo:false
            },

            myPublishList:[],

            popupStick:{
                stickShop:false,
                taskObj:null,
                stickTime:''
            },
            popupAdd:{
                title:'',
                placeholder:'',
                addVal:NaN,
                addShow:false,
                taskObj:'',
                apiUrl:''
            }
        }
    },
    components: {
        ListMission, Scroll,ListPublish
    },
    created(){
        
        this.axios.get('/task/mypublish',{params:this.paramsPublish})
            .then((response) => {
                // console.log(response)
                this.myPublishList = response.data.data
            })
    },
    methods:{
        // // 计算未完成任务
        // getResidue(total_count,finish_count,submit_count,unsubmit_count,){
        //     return total_count - finish_count
        // },
        // 删除任务
        delTask(obj,idx){
            this.$dialog.confirm({
                title: '注意',
                message: '确认要删除任务吗？'
            }).then(() => {
                // on confirm
                this.axios.get('/task/delete',{params:{'task_id':obj.id}})
                    .then((response) => {
                        // console.log(response)
                        if(response.data.code == 0){
                            this.myPublishList.splice(idx,1)
                        }else{
                            this.$toast(response.data.msg)
                        }
                    })
            }).catch(() => {
              // on cancel
            })
        },
        // 暂停任务
        pauseTask(obj){
            let msg
            if(obj.pause_count > 1){
                msg = '每天可以免费暂停2次您已用完，本次暂停收费2元，您确认要暂停任务吗？'
            } else{
                msg ='确认要暂停任务吗？'
            }
            this.$dialog.confirm({
                title: '注意',
                message: msg
            }).then(() => {
                this.axios.get('/task/pause',{params:{'task_id':obj.id}})
                    .then((response) => {
                        if(response.data.code == 0) {
                            obj.pause_count +=1
                            obj.state = 4
                        }else{
                            this.$toast(response.data.msg)
                        }
                        // console.log(response)
                    })
            }).catch(() => {
              // on cancel
            })
        },
        // 开启任务
        openTask(obj){

            this.$dialog.confirm({
                title: '注意',
                message: '确认要开启任务吗？'
            }).then(() => {
                this.axios.get('/task/open',{params:{'task_id':obj.id}})
                    .then((response) => {
                        if(response.data.code == 0) {
                            obj.state = 3
                        }else{
                            this.$toast(response.data.msg)
                        }
                        // console.log(response)
                    })
            }).catch(() => {
              // on cancel
            })
        },

        // 追加数量
        addCount(obj){
            this.popupAdd.addShow = true
            this.popupAdd.addVal = ''
            this.popupAdd.title='追加数量'
            this.popupAdd.placeholder='请输入数量'
            this.popupAdd.apiUrl = '/task/addcount'
            this.popupAdd.taskObj = obj
        },
        // 上调价格
        addPrice(obj){
            if(obj.state != 4){
                this.$dialog.alert({
                    message: '请先暂停任务，方能进行加价操作。'
                })
            }else if( obj.unsubmit_count !=0) {
                this.$dialog.alert({
                    message: '有尚未提交审核的数据，暂时不能调整价格，请稍后再试!'
                })
            }else{

                this.popupAdd.addShow = true
                this.popupAdd.addVal = ''
                this.popupAdd.title='上调价格'
                this.popupAdd.placeholder='请输入上调后的价格'
                this.popupAdd.apiUrl = '/task/addprice'
                this.popupAdd.taskObj = obj

            }
        },
        // 提交添加数量和上调价格
        sendPopupVal(){

            // 判断 添加数量还是上调价格
            if(this.popupAdd.apiUrl == '/task/addcount'){

                this.axios.get(this.popupAdd.apiUrl,{params:{ 'count' :this.popupAdd.addVal,'task_id':this.popupAdd.taskObj.id}})
                    .then((response) => {
                        if(response.data.code == 0){
                            this.popupAdd.taskObj.total_count += parseInt(this.popupAdd.addVal)
                        }else{
                            this.$toast(response.data.msg)
                        }

                        this.popupAdd.addVal = ''
                    })
            }else{

                if( this.popupAdd.addVal <= this.popupAdd.taskObj.price ){
                    this.$dialog.alert({
                        message: '上调后的价格要大于原价！'
                    })
                }else if( this.popupAdd.taskObj.submit_count != 0 ) {
                    this.$dialog.confirm({
                        message: '实施任务加价，您当前进行中及未审核的任务都将视为合格，且不可返回，您确认加价吗？'
                    }).then(() => {
                        this.axios.get(this.popupAdd.apiUrl,{params:{ 'price' :this.popupAdd.addVal,'task_id':this.popupAdd.taskObj.id}})
                            .then((response) => {
                                if(response.data.code == 0){
                                    this.popupAdd.taskObj.price = this.popupAdd.addVal
                                }else{
                                    this.$toast(response.data.msg)
                                }
                                // console.log(response)
                                this.popupAdd.addVal = ''
                            })
                    }).catch(() => {
                      // on cancel
                    })
                }else{
                    this.axios.get(this.popupAdd.apiUrl,{params:{ 'price' :this.popupAdd.addVal,'task_id':this.popupAdd.taskObj.id}})
                        .then((response) => {
                            if(response.data.code == 0){
                                this.popupAdd.taskObj.price = this.popupAdd.addVal
                            }else{
                                this.$toast(response.data.msg)
                            }
                            // console.log(response)
                            this.popupAdd.addVal = ''
                        })
                }
               
            }
        },
        // 下架任务
        closeTask(obj){

            if(obj.state == 4){
                this.$dialog.confirm({
                        message: '下架后当前任务进行中及未审核的任务都将视为合格，您确认下架吗？'
                    }).then(() => {
                        
                        this.getClose(obj)
                    }).catch(() => {
                      // on cancel
                    })
            }else{
                this.getClose(obj)
            }
            
        },
        // 下架任务请求
        getClose(obj){
            this.axios.get('/task/close',{params:{'task_id':obj.id}})
                .then((response) => {
                    if(response.data.code == 0 ){
                        obj.state = 5
                    }else{
                        this.$toast(response.data.msg)
                    }
                })
        },
        // 置顶任务 
        stickTask(obj) {
            this.popupStick.stickShop=true
            this.popupStick.taskObj = obj
        },
        // 置顶任务 请求
        getStick() {
            if(this.popupStick.stickTime <= 0){
                this.$dialog.alert({message:'时间不能为空！'})
            }else{
                this.axios.get("/task/top",{params:{task_id:this.popupStick.taskObj.id,hour:this.popupStick.stickTime}})
                    .then((response) => {
                        if(response.data.code == 0){
                            this.popupStick.stickShop=false
                            this.popupStick.taskObj = null
                            this.popupStick.stickTime =null

                            this.$toast('置顶成功!')

                        }else{
                            this.$toast(response.data.msg)
                        }
                    })
            }
        },
        // 置顶任务取消
        colseStickPop(){
            this.popupStick.stickShop=false
            this.popupStick.taskObj = null
            this.popupStick.stickTime =null
        },
        // 上拉加载
        upData(obj) {
            // console.log(this.pullup)
            const _this = this;
            if(obj.add){
                obj.add=false;
                obj.pageNumber +=1;

                this.$toast.loading({
                    duration: 0,       // 持续展示 toast
                    forbidClick: true, // 禁用背景点击
                    loadingType: 'spinner',
                    message: '加载中...'
                });

                // console.log(obj.pageNumber)

                
                this.axios.get(obj.url,{params:obj})
                    .then((response) => {
                        // console.log(response+'ddd')
                        if(response.data.count == 0) {
                            this.$toast.clear();
                            obj.dataNo = true;
                            this.$toast('没有新数据了')
                        }else{

                            

                            response.data.data.forEach(function(item){
                                _this.myPublishList.push(item)
                            })
                            
                            setTimeout(() => {
                                _this.$refs.listScroll.refresh()
                                _this.$toast.clear();
                                obj.add=true
                                // console.log(obj.add)
                        },500)
                            
                        }
                    })
            }
            
        }

    }
}
</script>

<style lang="scss" scoped>
.scroll-wrapper {position: absolute; top: 0; bottom: 0px;width: 100%;  overflow: hidden; }


.list-publish {
    background: #fff;
    li {
        min-height: 90px; color: #666; padding: 10px 2%; border-bottom: 1Px solid #f2f2f2; line-height: 1.5;
        .hd { 
            font-size: 14px; color: #222; 
            span { 
                font-size: 12px; margin-left: 5px; color: #999; 
                i { color: #666; }
            } 
        }
        .bd { overflow: hidden;
            span { display: block; float: left; width: 33%; color: #999; }
        }
        .ft-btn {
            overflow: hidden;
            i { 
                display: block; float: left; width: 60px;  text-align: center; line-height: 20px; border-radius: 4px; margin:5px 10px 5px 0; border: 1Px solid #dedede; 
                &.send { color: #56b1ff; }
                &.delete { color: #f66364; }
                &.no { color: #555; background-color: #f1f1f1; }
            }
            p{display: block; clear: both; color:#f66364; padding:5px 0;}
        }
        .time { overflow: hidden; color: #999; padding-right: 10px; }
    }
}

// 弹窗
.popup_stick {
    width: 238px; background-color: #f66364; border-radius:6px; color: #fff; line-height:18px;
    .hd { 
        text-align: center;
        h3 { font-size: 14px; line-height:38px; }
    }
    .bd {
        padding: 11px 17px 0;
        .van-cell { 
            padding:3px 15px; border-radius: 6px; 
        }
    }
    .row-btn {
        display: flex; justify-content: space-between; padding-top: 15px;
        i{ display: block; width: 49%; background-color: #f88283; color: #fff; text-align: center; line-height:36px;}
    }
    .ft { padding:8px 17px; }
}

.mytask {
   
}
</style>
