<template>
    <div id="page">
        <TopBar :title="tit" />
        
        
        <Scroll class="scroll-wrapper"  ref="listScroll">
            <div class="scroll">
                <div class="project-from">
                    <div class="tit" v-if="$route.query.type != 'cf'">
                        <span  class="t-lft" @click.stop="toggleShow('typeShow')">类别说明</span><span class="" @click.stop="toggleShow('auditShow')">审核标准</span><span class="t-rgt" @click.stop="toggleShow('publishShow')">发布规则</span>
                    </div>
                    <van-row  v-if="$route.query.type != 'cf'">
                        <van-radio-group v-model="param.type" >
                            <van-radio v-for="(type,idx) in taskType" @click="changeType(idx)" :name="type.id" :key="type.id" >{{type.name}}</van-radio>
                        </van-radio-group>
                    </van-row>
                    <div v-if="newType.name == '长单'">
                        <van-field v-model="param.order_time_limit" type="number"  label="接单限时"   placeholder="完成任务限定时间(默认20分钟)" ><i slot="icon">分钟</i></van-field>
                        <van-field v-model="param.check_time_limit" type="number"  label="审核限时"  placeholder="超时未审核系统默认合格(默认24小时)" ><i slot="icon">时</i></van-field>

                        <div class="font-red " style="padding: 14px 10px; font-size: 12px; line-height:17px; border-bottom: 1Px solid #ccc">提示！平台禁止发布黄赌毒及涉政等一切法律所禁止的内容，另外与本平台有同类性质功能的软件或平台禁止在本平台发布推广任务，如发现将查封账户，余款不退，敬请周知。</div>
                        </div>
                    <div class="tit">选择平台</div>
                    <van-row>
                        <van-radio-group v-model="param.device">
                            <van-radio  :name="0" >全部</van-radio>
                            <van-radio  :name="1" >安卓</van-radio>
                            <van-radio  :name="2" >苹果</van-radio>
                        </van-radio-group>
                    </van-row>
                    <van-field v-model="param.title" label="标题" placeholder="请输入标题" />
                    <van-field v-model="param.end_time" label="截止时间" @click="timeShow=true" placeholder="" readonly is-link />            
                    <van-field v-model="param.price" type="number"  label="出价" v-if="taskType != ''"  :placeholder="'最低出价'+newType.min_price+'元'" ><i slot="icon">元</i></van-field>
                    <van-field v-model="param.total_count" type="number"  label="数量" v-if="taskType != ''" :placeholder="'最少'+newType.min_count+'单'" ><i slot="icon">单</i></van-field>
                    <van-field v-model="total" label="合计" :placeholder="'服务费:成交额的'+newType.service_charge*100+'%'"  readonly><i slot="icon">元</i></van-field>
                    <!-- <van-field v-model=""  v-if="taskType != '' && total " label="服务费" placeholder="服务费" readonly><i slot="icon">元</i></van-field> -->
           
                    
                    <van-row v-if=" op != 'cf'">
                        <van-col span="24">
                            说明图
                        </van-col>
                    </van-row>
                    
                    <div  v-if=" op != 'cf'" class="explain-img">
                        <div class="img" v-show="img != ''" v-for="(img,index) in explain_img_json" :key="index"><img  :src="GLOBAL.QiNiu + img" alt=""><i class="iconfont icon-cha1" @click="delImg(index,explain_img_json)" ></i></div>
                        <UploadImg class="up-explain" v-show="explain_img_json.length < 5" v-on:addImg="addExplainImg"  :font-tit="fontTit" />
                        
                    </div>

                    <van-row  v-if=" op != 'cf' ">
                        <van-col span="24">
                            操作步骤
                        </van-col>
                    </van-row>
                    
                    <div  v-if=" op != 'cf' " class="step-list">
                        <van-row v-for="(step,index) in step_json" :key="index" style="background-color: #f4f4f4;" type="flex" align="center" >
                            <van-col span="3">
                                <span>{{index+1}}</span>
                                <i @click="delStep(index)">删除</i>
                            </van-col>
                            <van-col offset="1" span="5">

                                <UploadImg  :imgurl="step.explain_img | upImgUrl" class="up-step"  v-on:addImg="addStepImg($event,index)"  :font-tit="fontTit2" />
                                <!-- <UploadImg v-else :imgurl="GLOBAL.QiNiu + step.explain_img" class="up-step"  v-on:addImg="addStepImg($event,index)"  :font-tit="fontTit2" /> -->
                            </van-col>
                            <van-col span="15">
                                <textarea class="textarea" placeholder="请输入文字说明" v-model="step.description"  ></textarea>
                            </van-col>
                        </van-row>

                        <van-button class="add-step"  v-show="step_json.length < 10"  @click="addStep" >添加步骤</van-button>
                    </div>

    
                    <van-field v-model="param.url" label="链接" placeholder="请输入链接" />
                    <van-field v-model="param.word_verify" label="文字验证" type="textarea" rows="1" autosize placeholder="请输入文字验证" />
                    <van-field v-model="param.remark"  label="备注" type="textarea" autosize rows="1" placeholder="请输入备注" />

                    <div  v-if=" op != 'cf' "  class="row-protocol"><van-checkbox v-model="param.protocol">我已阅读、理解并同意<i  @click.stop="toggleShow('publishShow')">《发布规则》</i>的全部内容</van-checkbox></div>

                    <van-button type="info"  @click="subPublish" class="sub-btn">提交</van-button>

                    <div class="font-red" style="padding: 14px 10px; font-size: 12px; line-height:17px;">提示！平台禁止发布黄赌毒及涉政等一切法律所禁止的内容，另外与本平台有同类性质功能的软件或平台禁止在本平台发布推广任务，如发现将查封账户，余款不退，敬请周知。</div>
                </div>
            </div>
        </Scroll>

        
        <!-- 时间弹窗 -->
        <van-popup v-model="timeShow" position="bottom " >
            <van-datetime-picker  v-model="dataTime.currentDate" @cancel="timeShow = false" type="datetime"  @confirm="getTime" :min-date="dataTime.minDate"  :max-date="dataTime.maxDate" />
        </van-popup>

        <!-- 类别说明 -->
        <van-popup v-model="popupMod.typeShow" class="popup-mod" position="bottom " >
            <TopBar :title="'类别说明'" >
                <i slot="lft" class="iconfont  icon-iconfont-edu11" @click="toggleShow('typeShow')"></i>
            </TopBar>
            <div class="bd">
                <iframe  class="p-scroll" src="../../static/html/lbsm.html"   frameborder="0"></iframe>
            </div>
        </van-popup>


        <!-- 审核标准 -->
        <van-popup v-model="popupMod.auditShow" class="popup-mod" position="bottom " >
            <TopBar :title="'审核标准'" >
                <i slot="lft" class="iconfont  icon-iconfont-edu11" @click="toggleShow('auditShow')"></i>
            </TopBar>
            <div class="bd">
                <iframe  class="p-scroll" src="../../static/html/shbz.html"   frameborder="0"></iframe>
            </div>
        </van-popup>


        <!-- 发布规则 -->
        <van-popup v-model="popupMod.publishShow" class="popup-mod" position="bottom " >
            <TopBar :title="'发布规则'" >
                <i slot="lft" class="iconfont  icon-iconfont-edu11" @click="toggleShow('publishShow')"></i>
            </TopBar>
            <div class="bd">
                <iframe  class="p-scroll" src="../../static/html/fbgz.html"   frameborder="0"></iframe>
            </div>
        </van-popup>
        <!-- <div style="position: absolute; top:0;height:0">{{explain_img_json}}</div> -->
        <!-- <CNav /> -->
    </div>
</template>

<script>
// import CNav from '@/components/CNav'

import TopBar from '@/components/TopBar'
import Scroll from '@/components/Scroll'


import UploadImg from '@/components/UploadImg'
import {urlReplace} from '@/common/js/common'

import { popupToggle } from '@/mixin/popupToggle'
// import axios from 'axios';
export default {
    name: 'page',
    components: {
        TopBar,Scroll,UploadImg
    },    
    data() {
        return {
            tit:'新建任务',
            fontTit:'请上传验证图',
            fontTit2:'',
            taskType:[],
            newType:{},
            // service_charge:'',
            param:{
                type:1,
                device:0,
                title:'',
                end_time:'',
                price:'',
                total_count:'',                
                explain_img_json:null,
                step_json:[],
                url:'',
                remark:'',
                word_verify:'',
                order_time_limit:'',
                check_time_limit:'',
                protocol:false
            },
            
            explain_img_json:[],
            step_json:[],
            timeShow:false,
            dataTime:{
                minHour: 10,
                maxHour: 20,
                minDate: new Date(),
                maxDate: new Date(2028,1,1),
                currentDate: new Date()
            },

            popupMod:{
                typeShow:false,
                auditShow:false,
                publishShow:false
            },
            op:''
        }
    },
    mixins:[popupToggle],
    created(){
        if(this.$route.query.type == null){
            this.axios.get('/task/type/list')
                .then((response) => {
                    console.log(response)
                    this.taskType=response.data.data
                    // 当前类别信息
                    this.taskType.forEach(item =>{
                        if(this.param.type == item.id){
                           this.newType = item 
                       }
                    })
                })
        }else{
            const task_id =this.$route.query.task_id
            this.op = this.$route.query.type
            this.axios.all([
                this.axios.get('/task/type/list'),
                this.axios.get('/task/detail',{params:{task_id:task_id}})
                ])        
                .then(this.axios.spread((response1,response2) =>{
                    // console.log(response2)
                    const data = response2.data.data

                    this.param.type=data.task_type_id
                    this.param.title=data.title
                    this.param.device=data.device,
                    this.param.end_time='',
                    this.param.price = data.price
                    this.param.total_count = data.total_count
                    this.param.url=data.url
                    this.param.remark=data.remark
                    this.param.word_verify=data.word_verify
                    this.param.protocol=true

                    // 类别列表
                    this.taskType=response1.data.data
                    // 当前类别信息
                    this.taskType.forEach(item =>{
                        if(this.param.type == item.id){
                           this.newType = item 
                       }
                    })
                    // console.log(this.newType)
                    // 使用正则
                    let reg = new RegExp(this.GLOBAL.QiNiu, "g")
                    this.explain_img_json = (data.explain_img.replace(reg,'')).split(",")
                    // this.step_json = data.step_list.toJSONString().replace(reg,'').parseJSON();

                    this.step_json = JSON.parse(JSON.stringify(data.step_list).replace(reg,''))

                    // 修改任务添加任务id参数
                    if(this.$route.query.type == "xg"){
                        this.param['task_id'] = task_id
                    }
                },(error) => {
                    console.log(error)
                }))
        }
    },
    computed:{
        total:function () {
            // 合计
            if(this.taskType.length !=0){
                let tot =this.param.price * this.param.total_count
                if(tot == 0){
                    return ''
                }else{
                    return Math.round((tot+(tot * this.newType.service_charge ))*100)/100;
                }
            }
        }
    },
    methods:{
        // 类别说明切换
        changeType(val){
            // this.service_charge = this.taskType[val]['service_charge']
            
            // 当前类别信息
            this.taskType.forEach(item =>{
                if(this.param.type == item.id){
                   this.newType = item 
               }
            })
            // console.log(this.newType)
            this.param.price = ''
            this.param.total_count = ''
        },
        // 提交发布
        subPublish() {
            if(this.param.title =='') {
                this.$toast('标题不能为空')
            }else if(this.param.end_time =='') {
                this.$toast('截止时间不能为空')
            }else if(this.param.price < this.taskType[this.param.type-1].min_price ) {
                this.$toast('出价不能小于'+this.taskType[this.param.type-1].min_price)
            }else if(this.param.total_count < this.taskType[this.param.type-1].min_count) {
                this.$toast('单数不能小于'+this.taskType[this.param.type-1].min_count)
            }else if(this.explain_img_json == '') {
                this.$toast('说明图不能为空')
            }else if(this.step_json == '' || this.step_json[this.step_json.length-1].description =='') {
                this.$toast('操作步骤不能为空')
            }else if(this.param.protocol == false){

                this.$toast('请同意《发布规则》')
            }else{
                // this.show = true
                this.param.explain_img_json = this.explain_img_json.join(',')
                // this.param.step_json = this.step_json
                this.param.step_json =JSON.stringify(this.step_json);

                if(this.param.order_time_limit == '' ){
                    this.param.order_time_limit =20
                }
                if(this.param.check_time_limit == ''){
                    this.param.check_time_limit = 24
                }

                this.axios.post('/task/publish',this.qs.stringify(this.param),{emulateJSON: true})
                    .then((response) => {
                        // console.log(response)
                        if(response.data.code === 0){
                            // this.$toast(response.data.msg);
                            this.$router.push('/mytask/p')
                            
                        }else {
                            this.$toast(response.data.msg)
                        }
                        this.param.pay_pwd = ''
                    },(error) => {
                        console.log(error)
                    })
            }

        },
        // 获取时间
        getTime(value) {
            var date = new Date(value);  
            this.param.end_time = date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate() + ' ' + date.getHours() + ':' + date.getMinutes() ; 
            this.timeShow = false;
        },
        // 说明图添加
        addExplainImg(img) {
            // alert(img)
            this.explain_img_json.push(img);
        },
        // 说明图删除
        delImg(key,arr) {
            let imgKey=arr[key]

            this.axios.get('/qiniu/manage',{params:{op:'delete',filename:imgKey}})
                .then((response) => {
                    // console.log(response)
                    arr.splice(key,1);
                })
            // arr.splice(key,1);
        },
        // 步骤图添加
        addStepImg(img,key) {
            if(this.step_json[key].explain_img === ""){
                this.step_json[key].explain_img=img
            }else{
                // let imgKey=this.step_json[key].explain_img.replace('http://qiniu.68m42.cn/','')
                this.axios.get('/qiniu/manage',{params:{op:'delete',filename:imgKey}})
                    .then((response) => {
                        // console.log(response)
                        this.step_json[key].explain_img=img
                    })

            }
            // this.step_json[key].explain_img=img;
        },
        // 步骤添加
        addStep() {
            let steps=this.step_json;
            let step ={description:"",explain_img:""};
            if(steps.length ==0 ){
                steps.push(step)
            }else {
                if(steps[steps.length-1].description == '' ) {
                    this.$toast('请填写步骤说明')
                }else{
                    steps.push(step)
                }
            }
        },
        // 步骤删除
        delStep(idx){
            if(this.step_json[idx].explain_img === ""){
                this.step_json.splice(idx,1);
            }else{
                let imgKey=this.step_json[idx].explain_img.replace('http://qiniu.68m42.cn/','')
                this.axios.get('/qiniu/manage',{params:{op:'delete',filename:imgKey}})
                    .then((response) => {
                        // console.log(response)
                        this.step_json.splice(idx,1);
                    })
            }
                

        }
    }
}
</script>

<style lang="scss" scoped>

.scroll-wrapper {
    position: absolute; width: 100%; top: 38px; bottom: 0;    overflow: hidden;
}


.project-from {
    overflow: hidden; 
    .tit { 
        padding: 0 10px; line-height: 43px; background: #f4f4f4; 
        span { 
            display: inline-block; width: 33%; color: #f66364; text-align: center;
            &.t-lft{ text-align:left; color: #00aeff;}
            &.t-rgt{ text-align:right; }

        }
    }
    .van-row { 
        line-height: 43px; overflow: hidden; padding:  0 10px; border-bottom: 1px solid #f4f4f4; background: #fff;
    }
    .explain-img { 
        background: #f4f4f4; border-top: 1px solid #ccc;  overflow: hidden;
        .img {
            position: relative;  width: 40%; margin-left: 30%; margin-top: 20px; margin-bottom: 20px;
            i { position: absolute; font-size: 14px; display: block; width: 24px; height: 24px;line-height: 24px; text-align: center; border-radius:50%; color: #fff; background: #f00; right: -12px; top: -12px;} 
        }
    }
    .up-explain {border-top: 0;}
    .step-list {
        background: #f4f4f4; border-top: 1px solid #ccc; overflow: hidden;
        .add-step { height: 30px; line-height: 28px; margin: 20px auto; display: block;}
        .van-row {
            padding: 10px 10px; border-bottom: 1px solid #ccc;
            span {display: block; margin: 0 auto; width: 20px; height: 20px; background: #18aff0; line-height: 20px; border-radius:50%; text-align: center; color: #fff;}
            i {display:inline-block; padding:0 5px; background: #18aff0;line-height: 20px; color: #fff; border-radius:3px}
            .up-step { padding:10px 0; border: 1px solid #ccc;width:4rem !important; }
            .textarea { background:#f4f4f4;width:80%; vertical-align: middle; margin-left:10px;line-height: 20px;height: 60px; border: none;}
        }
    }
    .row-protocol {
        font-size: 12px; text-align: center; margin: 10px 0;
        .van-checkbox__icon--round .van-icon {
            background:#fff;
        }
        i {
            color:#1989fa;
        }
    }
    .sub-btn { height: 32px; line-height: 32px; display: block; margin: 10px auto; width:106px;  }
}

</style>
