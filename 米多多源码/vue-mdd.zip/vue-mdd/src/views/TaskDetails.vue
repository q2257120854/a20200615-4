<template>
    <div id="taskdetails">
        <TopBar :title="tit" >
            <em class="i-rgt" slot="rgt" @click.stop="toggleShow('orderShow')">接单规则</em>
        </TopBar>
        
        <!-- 接单规则 -->
        <van-popup class="popup-mod" v-model="popupMod.orderShow">
            <TopBar :title="'接单规则'" >
                <i slot="lft" class="iconfont  icon-iconfont-edu11" @click="toggleShow('orderShow')"></i>
            </TopBar>
            <div class="bd">
                <iframe  class="p-scroll" src="../../static/html/jdgz.html"   frameborder="0"></iframe>
            </div>
        </van-popup>

        <!-- 返回首页 -->
        <router-link tag="a" class="btn_back" to="index"><img src="../common/images/right_hovering.png" alt=""></router-link>

        <!-- 接单操作 -->
        <div class="btn-col">
            <div class="btn-red" v-if="taskDetails.state ==0" @click="changeRop">抢单</div>
            <router-link tag="div" v-else-if="taskDetails.state == 1" class="btn-red" :to="{path:'/taskverify',query:{task_id:task_id}}" style="line-height:14px; ">上传<br>图片</router-link tag="div">

            <div class="btn-red"  @click="shareTask">分享</div>
            <!-- <div class="btn-red"  @click="ckl">1</div> -->
            <!-- <div class="btn-red" v-if="taskDetails.state == 0">丢弃</div> -->
        </div>
        
        <div class="scroll">

            <TaskDescribe :taskDescribe="taskDetails" v-on:follow-state="changeFollow" />

            <!-- 验证图 -->
            <div class="task-verification-img">
                <div class="hd">验证图<span class="font-red">共{{explain_img.length}}张</span></div>
                <div class="bd">
                    <div v-for="(item,idx) in explain_img" :key="idx">
                        <img :src="item" alt="" v-image-preview>
                        <span>图 {{idx+1}}</span>
                    </div>
                </div>
            </div>

            <!--  操作说明 -->
            <div class="task-run-book">
                <div class="borderT"></div>
                <div class="hd">
                    <div class="title_line"></div>
                    <div class="title_font" style="z-index:0">操作说明</div>
                </div>
                <ul class="bd">
                    <li v-for="(item,idx) in taskDetails.step_list" :key="idx">
                        <div class="desc">
                                <i>{{idx +1}}</i>
                                {{item.description}}
                        </div>
                        <img :src="item.explain_img" v-if="item.explain_img" alt="" v-image-preview>
                    </li>
                    <!-- <li>
                        <div class="desc">
                                <i>2</i>
                                扫码进群，添加工作人员
                        </div>
                        <img src="http://www.aliyunqifu.com/goods/task/2019-04-10/2019_4_10_1833611439.png" alt="">
                    </li> -->
                </ul>
            </div>

            <!-- 提示信息 -->
            <div class="footer_msg_wrap">
                <p class="font-red">完成任务后，请回到平台【我的任务】上传任务截图</p>
                <p>平台禁止发布一切法律所禁止的内容，如发现请 <router-link tag="a" :to="{path:'/feedback',query:{task_id:task_id}}">举报</router-link></p>
            </div>



        </div>
        <!-- 任务详情 -->
        <!-- <Scroll class="scroll-wrapper"  ref="listScroll">
            <div class="scroll">
                任务描述
                
            </div>
        </Scroll> -->
        <!-- <CNav /> -->
    </div>
</template>

<script>
// import CNav from '@/components/CNav'
import TopBar from '@/components/TopBar'
import Scroll from '@/components/Scroll'

// 任务描述
import TaskDescribe from '@/components/TaskDescribe'

import { popupToggle } from '@/mixin/popupToggle'
// import axios from 'axios';
export default {
    name: 'taskdetails',
    components: {
        TopBar,Scroll,TaskDescribe
    },    
    data() {
        return {
            tit:'任务详情',
            rulePopup:false,
            // status:1,
            taskDetails:{},
            task_id:null,
            explain_img:[],
            popupMod:{
                orderShow:false
            }
        }
    },
    mixins:[popupToggle],
    created(){
        // this.task_id =this.$route.query.task_id
        this.task_id =this.$route.params.task_id
        // console.log('created')
        this.axios.get('/task/detail',{params:{task_id:this.task_id}})
            .then((response) => {
                console.log(response)
                
                this.taskDetails = response.data.data
                // 验证图
                this.explain_img = this.taskDetails.explain_img.split(',')
            })
    },
    beforeRouteUpdate (to, from, next) {
    // 在当前路由改变，但是该组件被复用时调用
    // 举例来说，对于一个带有动态参数的路径 /foo/:id，在 /foo/1 和 /foo/2 之间跳转的时候，
    // 由于会渲染同样的 Foo 组件，因此组件实例会被复用。而这个钩子就会在这个情况下被调用。
    // 可以访问组件实例 `this`
        
        this.task_id =to.params.task_id

        this.axios.get('/task/detail',{params:{task_id:this.task_id}})
            .then((response) => {
                // console.log(response)
                
                this.taskDetails = response.data.data
                // 验证图
                this.explain_img = this.taskDetails.explain_img.split(',')
            })
        next()
    },
    methods:{
        rulePopupChange() {
            this.rulePopup= !this.rulePopup;
        },
        // 关注状态
        changeFollow(val) {
            // console.log(val)
            this.taskDetails.is_follow = val
        },
        // 接单状态
        changeRop() {
            this.isRop=false;
            this.axios.post('/task/begin',this.qs.stringify({task_id:this.task_id}))
                .then((response) => {
                    if(response.data.code == 0){
                        this.taskDetails.state= 1;
                        this.$toast('您已接单，完成后，上传验证图')
                    }else if(response.data.code == 10004){
                        this.$router.push('/login')
                    }else if(response.data.code == 20004){
                        this.$toast(response.data.msg)
                    }else if(response.data.code == 20007){
                        this.$toast(response.data.msg)
                    }
                    
                    // console.log(response.data)
                })
        },
        // 分享口令
        shareTask(){
            // console.log(this.taskDetails)
            let tastText ='【'+this.taskDetails.title+'赏'+this.taskDetails.price+'元】推荐给你这个任务，快来和我一起瓜分红包。复制这条消息后￥'+this.taskDetails.id+'￥打开米多多赚钱。戳此下载https://dibaqu.com/yyiQ'

            let _this = this
            // 判断是否在APP,并且设置剪贴板内容
            if (/LT-APP/.test(navigator.userAgent)) {
                jsBridge.ready(function () { 
                    jsBridge.setClipboardText(tastText);
                    // _this.$toast('分享内容以复制到剪贴板')

                    _this.$dialog.confirm({
                        title: '注意',
                        message: '以复制到剪贴板,是否打开微信?'
                    }).then(() => {
                        
                        jsBridge.launch("weixin://", function(succ) {
                        });
                    }).catch(() => {
                    // on cancel
                    });
                });
            }
        }
    },

}
</script>

<style lang="scss" scoped>

.scroll-wrapper {
    position: absolute; width: 100%; top: 38px; bottom: 0;  overflow: hidden; 
}
.scroll {
    position: absolute; width: 100%; top: 38px; bottom: 0;  overflow-y: scroll; 
    -webkit-overflow-scrolling: touch;
}

.task-verification-img {
    text-align: center; color: #333;
    .hd { line-height: 25px; }
    .bd { 
        img { width:170px; border: 1Px solid #ccc;}
        span {display: block; line-height:30px; padding-bottom: 24px;}
    }
}

.task-run-book {
    .borderT{
        height: 4px; background:url('../common/images/bg_bor.png') center; background-size: auto 4px;
    }
    .hd {
        padding-top: 20px; height:50px; background: #cecece; margin-top: -1px; text-align: center;position: relative;
        .title_line { width:82%; position: absolute; top: 30px; left: 9%; height:1Px; border-top: 1Px solid #878787;  border-bottom: 1Px solid #878787; background-color: #333;}
        .title_font {position: relative; z-index:3; left:26%; width: 48%; height:14px; background-color: #cecece; font-size: 14px; }
    }
    .bd {
        li{
            overflow: hidden;
            .desc { 
                position: relative; background-color: #fff; padding: 14px 14px 14px 50px; line-height:22px;
                i { position: absolute; left: 14px; width:22px; height:22px; background-color: #30b1fc; color: #fff; text-align: center;  border-radius: 50%; }
            }
            img {
                display: block; margin: 12px auto; width:170px; border: 1Px solid #ccc;
            }
        }
        
    }
}

.footer_msg_wrap {
    padding:32px 0 16px; text-align: center;
    p { line-height:17px; 
        a{ color: #56b1ff; } 
    }
}

// 任务规则弹窗


</style>
