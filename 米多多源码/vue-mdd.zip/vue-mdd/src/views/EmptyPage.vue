<template>
    <div id="page">
    </div>
</template>

<script>
import CNav from '@/components/CNav'

import TopBar from '@/components/TopBar'
import Scroll from '@/components/Scroll'
// import axios from 'axios';
export default {
    name: 'page',
    components: {
        TopBar,Scroll,CNav
    },    
    data() {
        return {
            tit:'任务详情'

        }
    },
    created(){
      // this.axios.all([
      //       this.axios.get('/dept/list'),
      //       this.axios.get('/business/list'),
      //   ]).then(this.axios.spread((response1, response2) => {
      //       console.log(response2)
      //   }, (error) => {
      //       console.log(error)
      //   }));
    },
    beforeRouteEnter (to, from, next) {
      next(vm => {
        vm.$router.replace(from.path)
      })
    }
}
</script>

<style lang="scss" scoped>

.scroll-wrapper {
    position: absolute; width: 100%; top: 38px; bottom: 48px;    overflow: hidden;
}


</style>
