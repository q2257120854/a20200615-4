<template>
    <div id="page">
        <TopBar :title="tit" />
        
        
        <Scroll class="scroll-wrapper"  ref="listScroll">
            <div class="scroll">
                <div class="textarea-wrap">
                    <textarea v-model="params.content" class="textarea" id="" placeholder="请输入申诉内容！"  rows="6"></textarea>
                </div>
                <van-button type="info"    class="sub-btn" @click="sendAppeal" >提交</van-button>

                <div class="tit">
                    申诉原则：
                    <p>1.只有在与商家充分沟通无果的前提下才有必要申诉，沟通内容表述不清，使用不文明语言的将不予处理；</p>
                    <p>2.平台将秉承公正立场予以裁定，但无法确保每次裁定均为客观正确，无论审核是否通过，您都需要接受终审裁定；</p>
                    <p>3.频繁申诉者，被驳回的概率会增加；</p>
                    <p>4.如果终审被驳回，此单将被释放，您还可以重新抢单；</p>
                    <p>5.如果任务存在问题，您可以进行举报，并尽可能提供详细信息，平台核实后会及时对商家进行处理。</p>   
                </div>
            </div>
        </Scroll>
    </div>
</template>

<script>

import TopBar from '@/components/TopBar'
import Scroll from '@/components/Scroll'
// import axios from 'axios';
export default {
    name: 'page',
    components: {
        TopBar,Scroll
    },    
    data() {
        return {
            tit:'申诉',
            params:{
                content:'',
                task_id:''
            }
        }
    },
    created(){
        this.params.task_id=this.$route.query.task_id
    },
    methods:{
        sendAppeal(){
            if(this.params.content){
                this.axios.get('/user/appeal',{params:this.params})
                    .then(response => {
                        // console.log(response)
                        if(response.data.code == 0){
                            this.$toast('申诉请求发送成功！')

                            this.$router.replace('/mytask')
                        }else{
                            this.$toast(response.data.msg)
                        }
                    })
            }else{
                this.$toast('申诉内容不能为空')
            }
        }
    }
}
</script>

<style lang="scss" scoped>

.scroll-wrapper {
    position: absolute; width: 100%; top: 38px; bottom: 48px;    overflow: hidden;
}

.textarea-wrap {
    padding:10px; background-color: #fff;
    .textarea {border: none; width: 100%; line-height: 18px; color:#999;}
}
.tit {
    font-size: 10px; padding:10px; line-height:15px; color: #999;
}
</style>
