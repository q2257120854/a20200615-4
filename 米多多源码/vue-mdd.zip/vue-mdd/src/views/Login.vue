<template>
    <div id="login">
        

        <div class="from-register">

            <van-field class="text" v-model="phone" type="number" placeholder="请输入手机号" >
                <i slot="left-icon" class="lft-icon" ><img src="@/common/images/i_phone.png" alt=""></i>
            </van-field>
            <van-field class="text" v-model="pwd"  type="password" placeholder="请输入密码" >
                <i slot="left-icon" class="lft-icon" ><img src="@/common/images/i_mm.png" alt=""></i>
            </van-field>

            <p class="link">
                <router-link :to="{path:'/register',query:{'type':'forget'}}" tag="a" style="float: left" >忘记密码</router-link>
                <router-link :to="{path:'/register',query:{'redirect':redirect}}" tag="a" style="float: right" >还没有账号？立即注册</router-link>
            </p>
            
            <van-button class="btn-yellow" @click="loginSubmit" type="primary">登入</van-button>
            <!-- <p>{{$store.state.token}}</p> -->
        </div>
    </div>
</template>

<script>
// var self =this;

import store from '@/vuex/store'
// import { mapState,mapMutations } from 'vuex';

export default {
    name: 'Login',
    data() {
        return {
            phone:'',
            pwd:'',
            redirect:''
        }
    },
    created(){


        this.redirect =this.$route.query.redirect;
        if(localStorage.getItem('token')){
            this.$router.push('/')
        }
    },
    store,
    methods:{
        // ...mapMutations(['ADD_COUNT']),
        loginSubmit() {

            let loading = this.$toast.loading({
                // mask: true,
                forbidClick:true,
                duration:0,
                message: '加载中...'
            })
            if( this.phone == '') {
                this.$toast('手机号不能为空')
                return false;
            }else if( this.pwd == '') {
                this.$toast('密码不能为空')
                return false;
            }
                

            this.axios.post('/user/login',this.qs.stringify({'phone':this.phone, 'pwd':this.pwd}),{emulateJSON: true})
                .then(reponse => {
                    // console.log(reponse)
                    if(reponse.data.code == 0){
                        localStorage.setItem('token',reponse.data.token);
                        localStorage.setItem('phone',reponse.data.info.phone);
                        localStorage.setItem('id',reponse.data.info.id);
                        localStorage.setItem('head_img',reponse.data.info.head_img);
                        localStorage.setItem('nickname',reponse.data.info.nickname);


                        // 判断是否在APP,并且发送用户id
                        if (/LT-APP/.test(navigator.userAgent)) {
                            jsBridge.ready(function () { 
                                let idS =reponse.data.info.id.toString()
                                jsBridge.jiguang.setAlias(idS, function(alias){
                                    // alert("设置的别名"+alias);
                                });
                            });
                        }

                        let url =this.$route.query.redirect;
                        if( url != undefined ){
                            this.$router.push(url)
                        }else{
                            this.$router.push('/')
                        }
                        
                    loading.clear()
                        // this.$router.push({name:'login'})
                    }else{
                       // console.log(reponse.data.msg);
                        this.$toast(reponse.data.msg);
                        // console.log(this.$store)
                    }
                })
        }
    }
}
</script>

<style lang="scss">
#login {
    width: 100%; min-height: 100vh; background:url('../common/images/bg_logo.jpg') no-repeat center  -30px #fff; background-size: 100% auto;

    .logo {
        text-align: center; padding-top: 116px;
        img { width: 160px;}
    }
    .from-register {
        padding: 170px 30px 20px;
        .link {text-align: right; color: #999; line-height: 40px; padding:0 10px; overflow: hidden;}

    }
}
</style>
