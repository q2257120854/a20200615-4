<template>
    <div class="page">
        <!-- <TopBarTaskHall/> -->
        <TopBar :title="title" class="task-hall-tit" >
            <div slot="content" class="content">
                <em  class="tis" @click.stop="toggleShow('tisProtocol')">警示声明</em>
                <router-link tag="i" class="rgt" to="/mytask">我的任务</router-link>
                <div class="search-text" @click="popupShow"><span class="text">{{getSearchVal}}</span><img src="../common/images/sousuo.png" alt=""></div>
            </div>
        </TopBar>
        <router-link tag="a" class="btn_back" to="index"><img src="../common/images/right_hovering.png" alt=""></router-link>
        <Scroll class="scroll-wrapper"   ref="listScroll"  :pullup="true"  :bounce="bounce" v-on:scrollToEnd="upData(listParams)">
            <div class="scroll">
                <!-- 标签 -->
                <TagSelection   :Tags="Tags" v-on:changeType="changeTypelist" />
                <!-- 置顶店铺 -->
                <TopShop  />

                <!-- 排序 -->
                <!-- <ul class="row-screen">
                    <li class="act">最新</li>
                    <li>综合</li>
                    <li>优先</li>
                    <li>人气</li>
                    <li>苹果</li>
                </ul> -->
                
                <van-row class="list-task" type="flex" style="flex-wrap:wrap">
                    <van-col  span="12" v-for="(item,idx) in listInfo" :key="idx" >
                        <router-link tag="a" :to="'/taskdetails/'+item.id">
                            <i class="icon" :style="'background-image:url('+item.icon+')'" ></i>
                            <div class="desc">
                                <h3>
                                    {{item.task_type}} 
                                    <span class="x_icon_top" v-if="item.is_top == 1">顶</span>
                                    <span class="x_icon_devaice" v-if="item.device != 0 ">{{item.device | iconDevice}}</span>
                                    <span class="x_icon_earnest" v-if="item.is_earnest_money == 1"><img src="@/common/images/bao.png" alt=""></span>
                                </h3>
                                <p>{{item.title}}</p>
                                <span>编号：{{item.id}}<br>单价：{{item.price}}元 </span>
                            </div>
                        </router-link>
                    </van-col >

                </van-row>
                <div v-if="listParams.dataNo" style="text-align: center;" class="wgd">无更多数据</div>
                <div v-else style="position: absolute;width:100%; height: 30px; line-height: 30px; text-align: center; bottom: -30px">上拉加载</div>
                <!-- <div v-if="dataNo" style="text-align: center">无数据</div>
                <div v-else style="position: absolute;width:100%; height: 30px; line-height: 30px; text-align: center; bottom: -30px">上拉加载</div> -->
            </div>
        </Scroll>

        <!-- 搜索弹窗 -->
        <van-popup v-model="searchParams.show" class="popup-search">
            
            <van-radio-group v-model="searchParams.radio" class="hd" >
                <div class="rad"v-for="item in searchParams.searchRadio">
                    <van-radio  :key="item.id" :name="item.id" >{{item.name}}</van-radio>
                </div>
            </van-radio-group>
            <div class="bd">
                <van-field v-model="searchParams.val" placeholder="请输入用户名" />
            </div>
            <van-button type="info" @click="getSearch"  class="search-btn">搜索</van-button>
        </van-popup>

        
        <!-- 警示声明 -->
        <van-popup class="popup-mod" v-model="popupMod.tisProtocol">
            <TopBar :title="'警示声明'" >
                <i slot="lft" class="iconfont  icon-iconfont-edu11" @click="toggleShow('tisProtocol')"></i>
            </TopBar>
            <div class="bd">
                <iframe  class="p-scroll" src="../../static/html/jssm.html"   frameborder="0"></iframe>
            </div>
        </van-popup>
        <!-- <CNav /> -->
    </div>
</template>

<script>
import TopBar from '@/components/TopBar'
import TopBarTaskHall from '@/components/TopBarTaskHall'
import TagSelection from '@/components/TagSelection'
import TopShop from '@/components/TopShop'

import { popupToggle } from '@/mixin/popupToggle'

import Scroll from '@/components/Scroll'
// import CNav from '@/components/CNav'
// import axios from 'axios';
export default {
    name: 'Page',
    components: {
        TopBar,TopBarTaskHall,TagSelection,Scroll,TopShop
    },
    data() {
        return {
            title:'',
            listParams:{
                pageNumber:1,
                pageSize:16,
                type_id:null,
                url:'/task/list',
                add:true,
                task_id:'',
                title:'',
                dataNo:false
            },
            Tags:[],
            listInfo:null,
            bounce:{
                top:false,
                left:false,
                right:false,
                bottom:true
            },
            searchParams:{
                show:false,
                searchRadio:[
                    {
                        id:1,
                        name:'按编号'
                    },
                    {
                        id:2,
                        name:'按标题'
                    }
                ],
                radio:1,
                val:''
            },
            popupMod:{
                tisProtocol:false
            }
        }
    },
    mixins:[popupToggle],
    created(){
        // console.log(this.$toast)
        // console.log(this.$router)
        this.axios.all([
            this.axios.get('/task/type/list'),
            this.axios.get(this.listParams.url,{params: this.listParams}),
        ]).then(this.axios.spread((response1, response2) => {
            this.Tags = response1.data.data
            this.listInfo = response2.data.data
            if(response2.data.data.length <10){
                this.listParams.dataNo = true
            }
            // console.log(this.listInfo)
        }, (error) => {
            console.log(error)
        }));
    },
    computed:{
        getSearchVal:function () {
            return this.searchParams.val == '' ? '搜索' : this.searchParams.val
        }
    },
    methods:{
        // 弹窗显示
        popupShow(){
            this.searchParams.show=true
        },
        //搜索发送
        getSearch(){
            this.listParams.pageNumber = 1
            this.listParams.dataNo = false
            this.listParams.add = true

            if(this.searchParams.radio ==1){
                this.listParams.title == null
                this.listParams.task_id = this.searchParams.val
            }else{
                this.listParams.task_id == null
                this.listParams.title = this.searchParams.val
            }

            this.axios.get('/task/list',{params:this.listParams})
                .then(response => {
                    if(response.data.code == 0 ){
                        // if(response.data.count == 0){
                        //     this.$toast('未找到搜索任务')
                        // }

                        this.listInfo=response.data.data
                    }else{
                        this.$toast(response.data.msg)
                    }
                    this.searchParams.show = false
                    // console.log()
                })

        },
        changeTypelist(id) {
            // console.log(id)
            this.listParams.type_id = id
            this.listParams.pageNumber = 1
            this.listParams.dataNo = false
            this.listParams.add = true

            this.axios.get(this.listParams.url,{params: this.listParams})
                .then ((response) => {
                    this.listInfo = response.data.data
                })
        },
        // 上拉加载
        upData(obj) {
            // console.log(this.pullup)
            const _this = this;
            if(obj.add){
                obj.add=false;
                obj.pageNumber +=1;

                this.$toast.loading({
                    duration: 0,       // 持续展示 toast
                    forbidClick: true, // 禁用背景点击
                    loadingType: 'spinner',
                    message: '加载中...'
                });

                // console.log(obj.pageNumber)

                
                this.axios.get(obj.url,{params:obj})
                    .then((response) => {
                        // console.log(response+'ddd')
                        if(response.data.count == 0) {
                            this.$toast.clear();
                            obj.dataNo = true;
                            this.$toast('没有新数据了')
                        }else{

                            

                            response.data.data.forEach(function(item){
                                _this.listInfo.push(item)
                            })
                            
                            setTimeout(() => {
                                _this.$refs.listScroll.refresh()
                                _this.$toast.clear();
                                obj.add=true
                                // console.log(obj.add)
                        },500)
                            
                        }
                    })
            }
            
        }

    }
}
</script>

<style lang="scss"  scoped>
.scroll-wrapper {position: absolute; top: 38px; bottom: 0;width: 100%;  overflow: hidden; }

// 顶部
.task-hall-tit{
    .content { 
        position: relative; margin:0 10px 0 44px; 
        em {
            position: absolute; line-height:38px; display: block; 
            // i { text-align-last: left; left:0; }
        }
        .search-text {
            position: relative;  top: 9px; margin-left: 73px;padding:3px 10px;  width: 100px; height:12px; border: 1Px solid #d1d1d1; border-radius:3Px; 
            .text { font-size: 12px; line-height:12px; display: block; text-align: center; margin-right: 20px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; color:#999; }
            img { position: absolute; right:5px; top:3px; height:12px; }
        }
    }
    .rgt{ right: 0; font-size: 12px; width: auto;}
}

.row-screen {
    overflow: hidden; border-bottom: 1px solid #f3f3f3; background: #fff;
    li { float: left; width: 20%; text-align: center; line-height: 40px; }
    .act { color: #f66364; }
}

.list-task {
    border-bottom:1px solid #f2f2f2; background:#fff;
    .van-col {
        border-bottom: 1px solid #f2f2f2; 
        a {
            display: block; position: relative; padding-left: 50px; 
            .icon { 
                position: absolute;display: block; width:26px; height:26px; top:50%; margin-top: -13px; left:12px; background-size: 100%100%;
                &.icon_gj {background-image: url('../common/images/renwu_logo_8.png');}
                &.icon_gz {background-image: url('../common/images/renwu_logo_12.png');}
            }
            .desc {
                padding:3px 10px 3px 0; font-size: 12px;  line-height: 1.2;
                h3 {  
                    color:#000;  vertical-align: middle; display: inline-block;
                    span {
                        display: inline-block; margin-left: 5px; vertical-align: middle;
                        &.x_icon_top { border: 1px solid #f66364;  color: #f66364; background-color: #FFEC14; line-height: 1; padding:1Px; border-radius:2Px; font-weight: bold;}
                        &.x_icon_devaice { border: 1px solid #aaa8a8;  color: #aaa8a8; line-height: 1; padding:1Px; border-radius:50%; text-align: center;}
                        &.x_icon_earnest img{vertical-align: middle; display:inline-block; width: 16px;height:16px;}
                    }
                }
                p { color: #666; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
                span { font-size: 10px; color: #999; }
            }
        }
    }
}

// 搜索弹窗
.popup-search{
    width: 80%; padding: 25px 0 20px; border-radius:10px;
    .hd{
        overflow: hidden; padding:0 30px;
        .rad {float: left; width:50%; text-align: center;}
    }
    .bd {
        margin:20px 30px 0; border: 1px solid #d1d1d1; 
        .van-cell{padding-top:4px;padding-bottom: 4px; font-size: 14px;}
    }
    .search-btn {display: block; margin: 20px auto 0; width: 92px; height:28px; line-height:28px; background-color: #f66364; color: #fff; border: none; border-radius:5px;}
}
</style>
