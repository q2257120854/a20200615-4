<template>
    <div class="mytask">
        <TopBar :title="tit" >
            <i slot="rgt" class="i-rgt iconfont  icon-refresh-1-copy-copy" @click="$router.push('/emptyPage')"></i>

        </TopBar>


        <van-row class="tabs">
            <van-col span="12"><router-link to="/mytask/t" active-class="on" tag="a" replace>我的任务<i></i></router-link></van-col>
            <!-- <van-col span="8"><router-link to="/mytask/r" active-class="on" tag="a" replace>我的记录<i></i></router-link></van-col> -->
            <van-col span="12"><router-link to="/mytask/p" active-class="on" tag="a" replace>我的发布<i></i></router-link></van-col>
        </van-row>

        <TopShop ></TopShop>
        

        <!-- <keep-alive> -->
            <router-view class="router-v"></router-view>
        <!-- </keep-alive> -->



        <!-- <cNav /> -->
    </div>
</template>

<script>
// import cNav from '@/components/CNav';
import TopBar from '@/components/TopBar';

import TopShop from '@/components/TopShop'

import Scroll from '@/components/Scroll'
// import axios from 'axios';
export default {
    name: 'MyTask',
    data() {
        return {
            tit:'我的任务',
            tagAct:0,
            

        }
    },
    components: {
         TopBar, Scroll, TopShop
    },
    created(){
        
    },
    methods:{
        
    }
}
</script>

<style lang="scss" >

.router-v{
    position: absolute;  width: 100%; top:128px; bottom: 0;
}
.tabs{ 
    height:40px; background: #fff;
    a{
        position: relative;display: block; text-align: center; line-height: 40px; font-size: $fon_size_small;
    }
    .on{
        // color: #f00; 
        i { position: absolute; bottom: 3px; left:20%; width:60%; height:1px; background: #6ecdf6; }
    }
}
.mytask {
   
}
</style>
