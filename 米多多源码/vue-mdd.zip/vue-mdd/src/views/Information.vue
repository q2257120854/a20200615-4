<template>
    <div id="page">
        <TopBar :title="tit" >
            <i slot="lft"></i>
        </TopBar>
        <Scroll class="scroll-wrapper"  ref="listScroll">
            <div class="scroll">
                <ul class="info-list">
                    <li v-for="item in msgList" :key="item.id">
                        <div class="time">
                            <span>{{item.time}}</span>
                        </div>
                        <div class="info-card">
                            <div class="hd">
                                {{item.title}}
                                <!-- <p>03月16日</p> -->
                            </div>
                            <div class="bd" v-html="item.content">
                                <!-- {{item.content}} -->
                                <!-- 哎呦，你的任务审核未通过，请重新上传验证图吧！ <br>任务名称：1123123123 <br> 通知类型：待办 <br>提交正确图，需要看到商户单号核对，不是订单编号 -->
                                
                            </div>
                        </div>
                    </li>
                </ul>
            </div>
        </Scroll>
        <!-- <CNav /> -->
    </div>
</template>

<script>
// import CNav from '@/components/CNav'

import TopBar from '@/components/TopBar'
import Scroll from '@/components/Scroll'
// import axios from 'axios';
export default {
    name: 'page',
    components: {
        TopBar,Scroll
    },    
    data() {
        return {
            tit:'消息中心',
            msgList:[]

        }
    },
    created(){
        this.axios.get('/msg/list')
            .then(response => {
                // console.log(response)
                this.msgList = response.data.data
            })
      // this.axios.all([
      //       this.axios.get('/dept/list'),
      //       this.axios.get('/business/list'),
      //   ]).then(this.axios.spread((response1, response2) => {
      //       console.log(response2)
      //   }, (error) => {
      //       console.log(error)
      //   }));
    },
}
</script>

<style lang="scss" scoped>

.scroll-wrapper {
    position: absolute; width: 100%; top: 38px; bottom: 0;    overflow: hidden;
}

.info-list {
    padding:0 14px 20px;
    .time {
        padding :10px 0; text-align: center;
        span { display: inline-block;  padding:0 10px; line-height: 20px; color: #fff; background-color: #d3d3d3; border-radius:3px; }
    }
    .info-card {
        padding:10px 14px; background-color: #fff; border: 1Px solid #ccc; border-radius:3px;
        .hd {
            line-height:1.6; font-size: 14px; color: #000; font-weight: bold;
            p { font-weight: normal; font-size: 10px; color: #333;}
        }
        .bd {
            padding-top: 5px; font-size: 10px;
        }
    }
}
</style>
