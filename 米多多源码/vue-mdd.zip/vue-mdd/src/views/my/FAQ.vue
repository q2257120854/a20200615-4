<template>
    <div id="page">
        <TopBar :title="tit" />
                     
        <Scroll class="scroll-wrapper"  ref="listScroll">
            <div class="scroll">
                <div class="faq-wrap">
                    <van-cell title-class="tit" to="/faqdetail" title="为什么提现申请成功后，金额又返回到账户中？" is-link />
                    <van-cell title-class="tit" to="/faqdetail"  title="砍价、点赞、助力任务发在哪个类别里？" is-link />
                    <van-cell title-class="tit" to="/faqdetail"  title="怎样解除支付宝绑定？" is-link />
                </div>
            </div>
        </Scroll>
    </div>
</template>

<script>

import TopBar from '@/components/TopBar'
import Scroll from '@/components/Scroll'
// import axios from 'axios';
export default {
    name: 'page',
    components: {
        TopBar,Scroll
    },    
    data() {
        return {
            tit:'常见问题'

        }
    },
    created(){
      // this.axios.all([
      //       this.axios.get('/dept/list'),
      //       this.axios.get('/business/list'),
      //   ]).then(this.axios.spread((response1, response2) => {
      //       console.log(response2)
      //   }, (error) => {
      //       console.log(error)
      //   }));
    },
}
</script>

<style lang="scss" scoped>

.scroll-wrapper {
    position: absolute; width: 100%; top: 38px; bottom: 0;    overflow: hidden;
}

.faq-wrap{
    .tit {overflow: hidden; text-overflow: ellipsis; white-space: nowrap; font-size: 12px; color: #555; }
}

</style>
