<template>
    <div id="page">
        <TopBar :title="tit" />
        <div class="bill-info">
            <h3>提现总额</h3>
            <p><span>{{total_advance_money}}</span>元</p>
        </div>
        
        <Scroll class="scroll-wrapper"  ref="listScroll":pullup="true" v-on:scrollToEnd="upData(params)">
            <div class="scroll">
                <ul class="bill-list">
                    <li v-for="(item,idx) in myBillList" :key="idx">
                        <i class="iconfont icon-qiandai"></i>
                        <!-- <img src="" alt=""> -->
                        <div class="desc">
                            <h3 :class="{'red': item.money > 0}">{{item.money}}</h3>
                            <p><span>{{item.add_time}}</span>{{item.op}}</p>
                        </div>
                    </li>
                </ul>
                <div v-if="params.dataNo" style="text-align: center">没有更多数据</div>
                <div v-else style="position: absolute;width:100%; height: 30px; line-height: 30px; text-align: center; bottom: -30px">上拉加载</div>
            </div>
        </Scroll>
        <!-- <CNav /> -->
    </div>
</template>

<script>
// import CNav from '@/components/CNav'

import TopBar from '@/components/TopBar'
import Scroll from '@/components/Scroll'
// import axios from 'axios';
export default {
    name: 'page',
    components: {
        TopBar,Scroll
    },    
    data() {
        return {
            tit:'收支账单',
            params:{
                pageNumber:1,
                pageSize:10,
                url:'/user/accountdetail',
                add:true,
                dataNo:false
            },
            total_advance_money:0,
            myBillList:[]
        }
    },
    created(){
        this.axios.all([
            this.axios.get('user/info'),
            this.axios.get('/user/accountdetail',{params:this.params})
        ]).then(this.axios.spread((response1,response2) =>{
            // console.log(response1)
            this.total_advance_money = response1.data.data.total_advance_money
            this.myBillList = response2.data.data
        }))
    },
    methods:{

        // 上拉加载
        upData(obj) {
            // console.log(this.pullup)
            const _this = this;
            if(obj.add){
                obj.add=false;
                obj.pageNumber +=1;

                this.$toast.loading({
                    duration: 0,       // 持续展示 toast
                    forbidClick: true, // 禁用背景点击
                    loadingType: 'spinner',
                    message: '加载中...'
                });

                // console.log(obj.pageNumber)

                
                this.axios.get(obj.url,{params:obj})
                    .then((response) => {
                        // console.log(response+'ddd')
                        if(response.data.count == 0) {
                            this.$toast.clear();
                            obj.dataNo = true;
                            this.$toast('没有新数据了')
                        }else{
                            // console.log(response)
                            response.data.data.forEach(function(item){
                                _this.myBillList.push(item)
                            })
                            
                            setTimeout(() => {
                                _this.$refs.listScroll.refresh()
                                _this.$toast.clear();
                                obj.add=true
                                // console.log(obj.add)
                        },500)
                            
                        }
                    })
            }
        }
    }
}
</script>

<style lang="scss" scoped>

.scroll-wrapper {
    position: absolute; width: 100%; top: 123px; bottom: 0;    overflow: hidden; background-color: #fff;
}

.bill-info {
    background:  $body_color;  color: #f3f3f3; text-align: center; height:85px;
    h3 { padding:17px 0; line-height: 12px; }
    p { line-height:23px; span{ font-size: 23px; margin: 7px; color: #fff;} }
}

.bill-list {
    li{ 
        position: relative; padding:10px 10px 10px 50px;  border-bottom: 1Px solid #e5e5e5;
        img,i { position: absolute; left:10px; width: 30px; height:30px; text-align: center; color: #fff; font-size: 20px; line-height:30px; background:#f66364; border-radius:50%; }
        h3 { color: #599e61;line-height:14px; padding-bottom: 4px;  &.red{ color:#e66c69; } }
        p { font-size: 10px; line-height:12px; color: #555; span{float: right;} }
    }
}
</style>
