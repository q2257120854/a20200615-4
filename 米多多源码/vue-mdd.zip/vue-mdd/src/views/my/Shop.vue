<template>
    <div id="page" v-if="shopInfo">
        <TopBar :title="tit+'的店铺'" />
        
        <div class="my-info">
            <div class="hd">
                <img :src="shopInfo.user.head_img" id="show_img" alt="">
                <div class="desc">
                    <h3><i>{{shopInfo.user.nickname}}</i></h3>
                    <p>ID:{{shopInfo.user.id}}&nbsp;&nbsp;&nbsp;保证金{{shopInfo.user.earnest_money}}元</p>
                    <div class="rgt">
                        <router-link tag="i" v-if="!shopUid " to="/shoptop"  >置顶店铺</router-link>
                        <FollowBtn class="shop-folllow-btn" :follow-info="{is_follow:shopInfo.is_follow,uid:shopInfo.user.id}" v-on:follow-state="changeFollow" />
                        <!-- <i>+关注</i> -->
                    </div>
                </div>
            </div>
            <ul class="bd">
                <li>发任务<span>{{shopInfo.task_count}}个</span></li>
                <li>总发单<span>{{shopInfo.total_count}}单</span></li>
                <li>总成交<span>{{shopInfo.finish_count}}单</span></li>
                <li>投&nbsp;&nbsp;&nbsp;诉<span>{{shopInfo.complain_count}}个</span></li>
                <li>被申诉<span>{{shopInfo.appeal_by_count}}个</span></li>
                <li>被举报<span>{{shopInfo.report_by_count}}次</span></li>
                <li>接任务<span>{{shopInfo.take_count}}单</span></li>
                <li>申&nbsp;&nbsp;&nbsp;诉<span>{{shopInfo.appeal_count}}次</span></li>
                <li>被投诉<span>{{shopInfo.complain_by_count}}次</span></li>
            </ul>
        </div>
        

        <van-row class="followers-tabs">
            <van-col span="12">
                <i :class="{act:taskType == 0}" @click="changeTaskType(0)">进行中</i>
                <!-- <router-link tag="a" replace active-class="act" to="t">进行中</router-link> -->
            </van-col>
            <van-col span="12">
                <i :class="{act:taskType == 1}" @click="changeTaskType(1)">已下架</i>
                <!-- <router-link tag="a" replace active-class="act" to="r">已下架</router-link> -->
            </van-col>
        </van-row>


        <!-- <keep-alive>
            <router-view class="router-f"></router-view>
        </keep-alive> -->


        <Scroll class="scroll-wrapper"  ref="listScroll">
            <div class="scroll">
                <ListShopTask :list-info="listInfo" />
            </div>
        </Scroll>
    </div>
</template>

<script>

import ListShopTask from '@/components/ListShopTask'
import FollowBtn from '@/components/FollowBtn'

import TopBar from '@/components/TopBar'
import Scroll from '@/components/Scroll'
// import axios from 'axios';
export default {
    name: 'page',
    components: {
        TopBar,Scroll,ListShopTask,FollowBtn
    },    
    data() {
        return {
            tit:'',
            shopInfo:'',
            listInfo:[],
            taskType:0,
            shopUid:''
        }
    },
    created(){
        this.shopUid =this.$route.query.uid
        let api
        if(this.shopUid == undefined){
            api =this.axios.get('/store/home')
        }else{
            api =this.axios.get('/store/home',{params:{uid:this.shopUid}})
        }
        api.then(response => {
            // console.log(response)
            this.shopInfo = response.data.data
            this.listInfo = this.shopInfo.proceedList
            this.tit =this.shopInfo.user.nickname
        })
    },
    methods:{
 
        // 关注状态
        changeFollow(state){
            this.shopInfo.is_follow=state
        },
        // 切换进行中与下架
        changeTaskType(idx){
            if(this.taskType !=idx){
                this.taskType=idx
                if(idx==0) {
                    this.listInfo = this.shopInfo.proceedList
                }else{
                    this.listInfo = this.shopInfo.finishList                    
                }
            }
        }
    }
}
</script>

<style lang="scss" scoped>

.scroll-wrapper {
    position: absolute; width: 100%; top: 201px; bottom: 0;    overflow: hidden;
}

.my-info {
    background-color:  $body_color; color: #f3f3f3;
    .hd {
        padding:10px 8px 10px 56px;  position: relative; 

        img { position: absolute; left: 10px; width: 40px; height:40px; border-radius:50%; }
        .desc {
            position: relative;
            h3 {line-height: 20px; i{margin-right: 10px; font-size: 13px;}}
            p{line-height:20px; i { display: inline-block; width: 30px;text-align: center; }}
            .rgt {
                position: absolute; right: 0; top: 2px; 

                i{ display: block; position: relative; margin-bottom: 4px; margin-left: 0;  padding:0 10px; color: #fff; text-align: center; border-radius:10px;  line-height:14px; border: 1Px solid #fff;}
            }
        }
    }
    .bd { 
        margin:0 10px ; padding:5px 0; border-top: 1px solid #f3f3f3; overflow: hidden;
        li { float: left; width: 33%; line-height: 18px; span { color: #fff; margin-left: 5px; }  }
    }
}

.followers-tabs{
    padding:0 7px; text-align: center; background-color: #fff;
    i {
        margin: 0 auto; display: block; width: 70%; color: #555; border-bottom: 2Px solid #fff; line-height:35px; 
        &.act { border-bottom-color:  $body_color }
    }
}

// .router-f{
//     position: absolute;  width: 100%; top:201px; bottom: 0;
// }
</style>
