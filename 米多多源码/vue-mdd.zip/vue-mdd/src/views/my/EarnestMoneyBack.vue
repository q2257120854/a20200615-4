<template>
    <div id="page">
        <TopBar :title="tit" />
        
        
        <Scroll class="scroll-wrapper"  ref="listScroll">
            <div class="scroll">

                <!--  -->
                <div class="project-from">
                    <van-field label="保证金" v-model="earnest_money" placeholder="0.0" input-align="right" disabled><i slot="icon">元</i></van-field>
                    <van-field label="申退金额" v-model="params.amount" placeholder="请输入金额" input-align="right" ><i slot="icon">元</i></van-field>
                    

                    <div class="tips">
                        <!-- <p>温馨提示：</p>
                        <p>1、提现金额需是大于等于10元小于等于500元之间的整数，因为提现手续费需要10%，所以账户余额需大于等于1.1元方能提现。</p>
                        <p>2、每天可以提现三次，有时因网络的原因会有几秒到几分钟的延迟，请注意查收。</p> -->
                    </div>

                    <van-button type="info" @click="sendCoinAdvance"  class="sub-btn">确定申退</van-button>

                </div>


            </div>
        </Scroll>
    </div>
</template>

<script>

import TopBar from '@/components/TopBar'
import Scroll from '@/components/Scroll'
// import axios from 'axios';
export default {
    name: 'page',
    components: {
        TopBar,Scroll
    },    
    data() {
        return {
            tit:'申退保证金',
            params:{
                amount:''
            },
            pd:0,
            earnest_money:0
        }
    },
    created(){
        // console.log(this.$route)
        this.earnest_money = this.$route.query.earnest_money
      // this.axios.all([
      //       this.axios.get('/dept/list'),
      //       this.axios.get('/business/list'),
      //   ]).then(this.axios.spread((response1, response2) => {
      //       console.log(response2)
      //   }, (error) => {
      //       console.log(error)
      //   }));
    },
    methods:{
        sendCoinAdvance(){
            if(this.params.amount ==''){
                this.$dialog.alert({message:'申退金额不能空！'})
            }else{
                this.axios.get('/user/earnestMoneyBack',{params:this.params})
                    .then(response => {
                        // console.log(response)
                        if(response.data.code == 0){
                            this.$toast('申退成功!')
                            this.$router.push('/usercenter')
                        }else {
                            this.$toast(response.data.msg)
                        }/*else if(response.data.code == 40007){
                            // 未填写支付宝账号
                            this.$toast({
                                message:response.data.msg,
                                 forbidClick: true, // 禁用背景点击
                            });
                            setTimeout(() =>{
                                this.$router.replace(
                                    { 
                                        path: '/bindalipay',
                                        query: {redirect: this.$route.fullPath} 
                                    }
                                )
                            },1000)
                        }*/
                    })
            }
        }
    }
}
</script>

<style lang="scss" scoped>

.scroll-wrapper {
    position: absolute; width: 100%; top: 38px; bottom: 48px;    overflow: hidden;
}

.project-from {
    overflow: hidden; 

    .van-row { 
        line-height: 43px; overflow: hidden; padding:  0 10px; border-bottom: 1px solid #f4f4f4; background: #fff;
    }
    .van-radio { width:auto; }
    .tips {padding:8px 10px; color:#777; }

}

</style>
