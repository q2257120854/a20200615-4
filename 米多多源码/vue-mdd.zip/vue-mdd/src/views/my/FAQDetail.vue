<template>
    <div id="page">
        <TopBar :title="tit" />
        
        
        <Scroll class="scroll-wrapper"  ref="listScroll">
            <div class="scroll">
                <div class="faq-detail">
                    <div class="hd">
                        <h3>为什么提现申请成功后，金额又返回到账户中？</h3>
                        <p>2019-01-31<span>蚂蚁帮扶</span></p>
                    </div>
                    <div class="bd">请先查看您绑定的支付宝账号和姓名是否匹配，如填写错误，金额无法正常到账，金额将返回到个人账户中，请修改后再重新提交提现申请。</div>
                </div>
            </div>
        </Scroll>
    </div>
</template>

<script>

import TopBar from '@/components/TopBar'
import Scroll from '@/components/Scroll'
// import axios from 'axios';
export default {
    name: 'page',
    components: {
        TopBar,Scroll
    },    
    data() {
        return {
            tit:'常见问题'

        }
    },
    created(){
      // this.axios.all([
      //       this.axios.get('/dept/list'),
      //       this.axios.get('/business/list'),
      //   ]).then(this.axios.spread((response1, response2) => {
      //       console.log(response2)
      //   }, (error) => {
      //       console.log(error)
      //   }));
    },
}
</script>

<style lang="scss" scoped>

.scroll-wrapper {
    position: absolute; width: 100%; top: 38px; bottom: 0;    overflow: hidden;background-color: #fff;
}

.faq-detail {
    padding:12px 5%;
    .hd { 
        h3 { padding:20px 0; font-size: 18px; border-bottom: 1Px solid #edf0f3; line-height: 28px;  }
        p { line-height:34px; font-size: 13px; color: #555; span { color: #56b1ff; margin-left: 6px; } }
    }
    .bd { color: #555; font-size: 13px; line-height:30px; padding-top: 25px; }
}

</style>
