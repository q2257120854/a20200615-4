<template>
    <div id="page">
        <TopBar :title="tit" />
        
        
        <Scroll class="scroll-wrapper"  ref="listScroll">
            <div class="scroll">

                <!--  -->
                <div class="project-from">
                    <van-field label="充值金额" input-align="right" v-model="params.amount" placeholder="请输入价格" ><i slot="icon">元</i></van-field>
                    <van-row>
                        <van-col span="5" >充值方式</van-col>
                        <van-col span="18" >
                            <van-radio-group v-model="pd" >
                                <van-radio  :name="0" >支付宝</van-radio>
                            </van-radio-group>
                        </van-col>
                    </van-row>

                    <div class="font-red">提示：支付过程中，如遇"本次交易存在风险"，选择【继续付款】即可，此提醒仅为支付宝尽到的风险提示义务，多针对首次支付的用户。</div>


                    <van-button type="info" @click="sendBuy"  class="sub-btn">充值</van-button>


                    <!-- <div class="tips">
                        <p>注：</p>
                        <p>1.因微信政策的调整，平台暂不支持微信充值及提现，请用支付宝进行操作，今后如开放平台会及时公告。</p>
                        <p>2.登录电脑网页版www.mayibangfu.com也可以进行支付。</p>
                        <p>3.充值无最低额度限制够用即可，请根据任务单价及数量自行确定充值金额，如有剩余可以提现，但会收取一定的费用，详情请参阅任务[发布规则]或[用户协议]。</p>
                    </div> -->
                </div>


            </div>
        </Scroll>
    </div>
</template>

<script>

import TopBar from '@/components/TopBar'
import Scroll from '@/components/Scroll'
// import axios from 'axios';
export default {
    name: 'page',
    components: {
        TopBar,Scroll
    },    
    data() {
        return {
            tit:'充值',
            params:{
                amount:''
            },
            pd:0
        }
    },
    created(){
      // this.axios.all([
      //       this.axios.get('/dept/list'),
      //       this.axios.get('/business/list'),
      //   ]).then(this.axios.spread((response1, response2) => {
      //       console.log(response2)
      //   }, (error) => {
      //       console.log(error)
      //   }));
    },
    methods: {
        sendBuy() {
            if(this.params.amount == '' || this.params.amount == 0){
                this.$dialog.alert({message:'充值金额不能空' })
            }else{
                this.axios.get('/user/pay',{params:this.params})
                    .then(response => {
                        
                        if(response.data.code == 0){
                            window.location.href=response.data.data;
                            this.$toast.loading({
                                mask: true,
                                forbidClick:true,
                                duration:0,
                                message: '加载中...'
                            });
                        }else{

                            this.$toast(response.data.msg)
                        }
                    })
            }
        }
    }
}
</script>

<style lang="scss" scoped>

.scroll-wrapper {
    position: absolute; width: 100%; top: 38px; bottom: 48px;    overflow: hidden;
}

.project-from {
    overflow: hidden; 

    .van-row { 
        line-height: 43px; overflow: hidden; padding:  0 10px; border-bottom: 1px solid #f4f4f4; background: #fff;
    }
    .van-radio { width:auto; }
    .font-red, .tips { padding:10px 30px 0; line-height:21px; }
    .tips { padding-top: 17px; color:#777; }

}

</style>
