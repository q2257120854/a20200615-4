<template>
    <div id="page">
        <TopBar :title="tit" />
        
        
        <Scroll class="scroll-wrapper"  ref="listScroll">
            <div class="scroll">

                <!--  -->
                <div class="project-from">
                    <van-field label="支付宝账号" placeholder="请输入支付宝账号" v-model="params.account" input-align="right" ></van-field>
                    <van-field label="真实姓名" placeholder="请输入真实姓名" v-model="params.name" input-align="right" ></van-field>

                    <van-button type="info"  @click="bindAlipay" class="sub-btn">绑定</van-button>

                    <div class="tips">

                        <p> 注：因支付宝为实名账户，请输入对应账户的真实姓名，否则会造成支付或提现失败，支付宝账户只能修改一次，请勿随意改动。</p><!-- 
                        <p>1、提现金额需大于等于1.0元小于等于200元，账户余额需大于等于1.2元，提现时间为工作日的早9:00~17:00。</p>
                        <p>2、提现手续费：非合作商15%；普通合作商10%；金牌合作商8%；白金合作商5%；</p>
                        <p>3、合作商每天可以提现三次；非合作商7天内只能提现一次，需要审核，审核时间1个工作日内；</p>
                        <p>4、有时因网络原因会有几秒到几分钟的延时，注意查收红包。</p>
                        <p>5、提现需关注蚂蚁帮扶微信公众号（mayibangfu)，取消关注将无法提现。</p> -->
                    </div>



                </div>


            </div>
        </Scroll>
    </div>
</template>

<script>

import TopBar from '@/components/TopBar'
import Scroll from '@/components/Scroll'
// import axios from 'axios';
export default {
    name: 'page',
    components: {
        TopBar,Scroll
    },    
    data() {
        return {
            tit:'绑定支付宝',
            params:{
                account:'',
                name:''
            },
            pd:0
        }
    },
    created(){
        this.axios.get('/user/getAlipay')
            .then(response => {
                // console.log(response.data)
                this.params.account = response.data.data.alipay_number
                this.params.name = response.data.data.alipay_name
            })
      // this.axios.all([
      //       this.axios.get('/dept/list'),
      //       this.axios.get('/business/list'),
      //   ]).then(this.axios.spread((response1, response2) => {
      //       console.log(response2)
      //   }, (error) => {
      //       console.log(error)
      //   }));
    },
    methods:{
        bindAlipay() {
            if(this.params.account =='' || this.params.name == '') {
                this.$dialog.alert({message:'账号和姓名不能为空！'})
            }else{
                this.axios.get('/user/updateAlipay',{params:this.params})
                    .then(response => {
                        if(response.data.code == 0){
                            this.$toast({message:'绑定成功！'})
                            if(this.$route.query.redirect != ''){
                                // console.log(this.$route.query)
                                this.$router.replace({path:this.$route.query.redirect})
                            }
                        }else{
                            this.$toast(response.data.msg)
                        }
                    })

            }
        }
    }
}
</script>

<style lang="scss" scoped>

.scroll-wrapper {
    position: absolute; width: 100%; top: 38px; bottom: 48px;    overflow: hidden;
}

.project-from {
    overflow: hidden; 

    .van-row { 
        line-height: 43px; overflow: hidden; padding:  0 10px; border-bottom: 1px solid #f4f4f4; background: #fff;
    }
    .van-radio { width:auto; }
    .tips {padding:8px 10px; color:#f00; }

}

</style>
