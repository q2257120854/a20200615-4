<template>
    <div id="page" v-if="">
        <TopBar :title="tit" />
        
        <div class="my-info" v-if=" userInfo.myfans">
            <img :src="userInfo.head_img" id="show_img" alt="">
            <div class="desc">
                <h3><i>{{userInfo.nickname}}</i>ID:{{userInfo.id}}</h3>
                <p>我的粉丝<i>{{userInfo.myfans.length}}</i>人&nbsp;&nbsp;&nbsp;我的关注<i>{{userInfo.myfollow.length}}</i>人</p>
            </div>
        </div>
        
        <van-row class="followers-tabs">
            <van-col span="12">
                <i :class="{act:follow_type == 0}" @click="changeList(0)" >我的粉丝</i>
            </van-col>
            <van-col span="12">
                <i :class="{act:follow_type == 1}" @click="changeList(1)">我的关注</i>
            </van-col>
        </van-row>

    
        <Scroll class="scroll-wrapper" ref="listScroll"   >
            <div class="scroll">
                
                
                <ListMember :listInfo="listInfo" v-if="listInfo != ''"  />
                <!-- <div v-if="paramsTask.dataNo" style="text-align: center">无数据</div>
                <div v-else style="position: absolute;width:100%; height: 30px; line-height: 30px; text-align: center; bottom: -30px">上拉加载</div> -->
            </div>
        </Scroll>

        <!-- <keep-alive>
            <router-view class="router-f"></router-view>
        </keep-alive> -->


        <!-- <Scroll class="scroll-wrapper"  ref="listScroll">
            <div class="scroll">
        
            </div>
        </Scroll> -->
    </div>
</template>

<script>

import TopBar from '@/components/TopBar'
import Scroll from '@/components/Scroll'
import ListMember from '@/components/ListMember'
// import axios from 'axios';
export default {
    name: 'page',
    components: {
        TopBar,Scroll, ListMember
    },    
    data() {
        return {
            tit:'粉丝关注',
            userInfo:{},
            listInfo:[],
            fansList:[],
            followList:[],
            follow_type:0,
            paramsTask:{
                token:'',
                state:'',
                pageNumber:1,
                pageSize:10,
                url:'/task/my',
                add:true,
                dataNo:false
            },
        }
    },
    created(){
        // this.axios.get('/user/info')
        //     .then((response) => {
        //         this.userInfo = response.data.data
        //     })
      this.axios.all([
            this.axios.get('/user/info'),
            this.axios.get('/user/myfans'),
            this.axios.get('/user/myfollow')
        ]).then(this.axios.spread((response1, response2,response3) => {
            // console.log(response1)
            this.userInfo = response1.data.data

            this.listInfo = response2.data.data
            this.userInfo['myfans'] = response2.data.data
            this.userInfo['myfollow'] = response3.data.data
            // console.log(this.userInfo.myfollow)
            // console.log(this.listInfo)
        }, (error) => {
            console.log(error)
        }));
    },
    methods:{
        changeList(idx){
            if(this.follow_type != idx){
                this.follow_type = idx;
                // let api
                if(this.follow_type == 0){
                    this.listInfo = this.userInfo.myfans
                }else{
                    
                    this.listInfo = this.userInfo.myfollow
                }
                // this.axios.get(api)
                //     .then((response) => {
                //         this.listInfo = response.data.data
                //     })
            }
            
        }
    }
}
</script>

<style lang="scss" scoped>

// .scroll-wrapper {
//     position: absolute; width: 100%; top: 38px; bottom: 48px;    overflow: hidden;
// }

.my-info {
    padding:10px 8px 10px 56px; background-color:  $body_color; position: relative; color: #f3f3f3;
    img { position: absolute; left: 10px; width: 40px; height:40px; border-radius:50%; }
    h3 {line-height: 20px; i{margin-right: 10px; font-size: 13px;}}
    p{line-height:20px; i { display: inline-block; width: 30px;text-align: center; }}
    i { color: #fff; }

}

.followers-tabs{
    padding:0 7px; text-align: center; background-color: #fff;
    i {
        margin: 0 auto; display: block; width: 70%; color: #555; border-bottom: 2Px solid #fff; line-height:35px; 
        &.act { border-bottom-color:  $body_color }
    }
}

.router-f{
    position: absolute;  width: 100%; top:138px; bottom: 0;
}
</style>
