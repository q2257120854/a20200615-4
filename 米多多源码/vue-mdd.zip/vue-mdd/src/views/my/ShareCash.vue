<template>
    <div id="page">
        <TopBar :title="tit" />
        
        
        <Scroll class="scroll-wrapper"  ref="listScroll">
            <div class="scroll">

                <!--  -->
                <div class="project-from">
                    <van-field label="收人分红" v-model="income" placeholder="0.0" input-align="right" disabled><i slot="icon">元</i></van-field>
                    <van-field label="提现金额" v-model="params.amount" placeholder="请输入提现金额" input-align="right" ><i slot="icon">元</i></van-field>
                    <van-row>
                        <van-col span="5" >提现方式</van-col>
                        <van-col span="18" >
                            <van-radio-group v-model="pd" >
                                <van-radio  :name="0" >支付宝</van-radio>
                            </van-radio-group>
                        </van-col>
                    </van-row>

                    <div class="tips">
                        <p>温馨提示：</p>
                        <p>1、提现金额需是大于等于1元小于等于200元之间的整数，因为提现手续费需要10%，所以账户余额需大于等于1.1元方能提现。</p>
                        <p>2、每天可以提现三次，有时因网络的原因会有几秒到几分钟的延迟，请注意查收。</p>
                    </div>

                    <van-button type="info"    class="sub-btn" @click="sendCoinAdvance" >提现</van-button>


                </div>


            </div>
        </Scroll>
    </div>
</template>

<script>

import TopBar from '@/components/TopBar'
import Scroll from '@/components/Scroll'
// import axios from 'axios';
export default {
    name: 'page',
    components: {
        TopBar,Scroll
    },    
    data() {
        return {
            tit:'推广提现',
            params:{
                amount:''
            },
            income:0,
            pd:0
        }
    },
    created(){
        // console.log(this.$route)
        this.income = this.$route.query.income
    },
    methods:{
        sendCoinAdvance(){
            if(this.params.amount ==''){
                this.$dialog.alert({message:'提现金额不能空！'})
            }else{
                this.axios.get('/user/incomeAdvance',{params:this.params})
                    .then(response => {
                        // console.log(response)
                        if(response.data.code == 0){
                            
                            this.$toast('提现成功!')
                            this.$router.push('/usercenter')
                        }else if(response.data.code == 40007){
                            // 未填写支付宝账号
                            this.$toast({
                                message:response.data.msg,
                                 forbidClick: true, // 禁用背景点击
                            });
                            setTimeout(() =>{
                                this.$router.replace(
                                    { 
                                        path: '/bindalipay',
                                        query: {redirect: this.$route.fullPath} 
                                    }
                                )
                            },1000)
                        }else {
                            this.$toast(response.data.msg)
                        }
                    })
            }
        }
    }
}
</script>

<style lang="scss" scoped>

.scroll-wrapper {
    position: absolute; width: 100%; top: 38px; bottom: 48px;    overflow: hidden;
}

.project-from {
    overflow: hidden; 

    .van-row { 
        line-height: 43px; overflow: hidden; padding:  0 10px; border-bottom: 1px solid #f4f4f4; background: #fff;
    }
    .van-radio { width:auto; }
    .tips {padding:8px 10px; color:#777; }
    .sub-btn { height: 34px; line-height: 34px; display: block; margin: 17px auto; width:82%; border-radius:5px; }

}

</style>
