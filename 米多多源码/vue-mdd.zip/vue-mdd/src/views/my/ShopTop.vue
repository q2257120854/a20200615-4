<template>
    <div id="page">
        <TopBar :title="tit" />
        
        
        <Scroll class="scroll-wrapper"  ref="listScroll">
            <div class="scroll">

                <!--  -->
                <div class="project-from">
                    <div class="tit">周期价格</div>
                    <van-row>
                        <van-col span="24" >
                            <van-radio-group v-model="params.cycle" style="padding: 5px 0; overflow: hidden;">
                                <van-radio v-for="item in cyclePrice" :key="item.id"  :name="item.id" >
                                    {{item.tit}} 
                                    <div><span v-if="item.sub">(合<i>{{item.sub}}</i>/小时)</span></div>
                                </van-radio>
                            </van-radio-group>
                        </van-col>
                    </van-row>
                    <van-field label="周期数量" type="number" input-align="right" v-model="params.cycle_count" placeholder="0" ><i slot="icon">个</i></van-field>
                    <van-field label="金额合计" input-align="right" v-model="totalPrice" disabled ><i slot="icon">元</i></van-field>

                    <div class="font-red">提示：支付过程中，如遇"本次交易存在风险"，选择【继续付款】即可，此提醒仅为支付宝尽到的风险提示义务，多针对首次支付的用户。</div>


                    <van-button type="info" @click="sendBuy"  class="sub-btn">确认</van-button>


                    <!-- <div class="tips">
                        <p>注：</p>
                        <p>1.因微信政策的调整，平台暂不支持微信充值及提现，请用支付宝进行操作，今后如开放平台会及时公告。</p>
                        <p>2.登录电脑网页版www.mayibangfu.com也可以进行支付。</p>
                        <p>3.充值无最低额度限制够用即可，请根据任务单价及数量自行确定充值金额，如有剩余可以提现，但会收取一定的费用，详情请参阅任务[发布规则]或[用户协议]。</p>
                    </div> -->
                </div>


            </div>
        </Scroll>
    </div>
</template>

<script>

import TopBar from '@/components/TopBar'
import Scroll from '@/components/Scroll'
// import axios from 'axios';
export default {
    name: 'page',
    components: {
        TopBar,Scroll
    },    
    data() {
        return {
            tit:'置顶店铺',
            cyclePrice:[
                {
                    id:1,
                    price:30,
                    tit:'30  元/小时',
                    sub:''
                },
                {
                    id:2,
                    price:288,
                    tit:'288 元/天',
                    sub:'12'
                },
                {
                    id:3,
                    price:1588,
                    tit:'1588元/周',
                    sub:'9.45'
                },
                {
                    id:4,
                    price:4888,
                    tit:'4888元/月',
                    sub:'6.78'
                },
            ],
            params:{
                cycle:1,
                cycle_count:null
            },
            pd:0
        }
    },
    computed:{
        totalPrice : function () {
            // console.log(this)
            let price =this.cyclePrice[this.params.cycle -1].price
            return this.params.cycle_count != '' ? this.params.cycle_count*price : 0
        }
    },
    created(){

    },
    methods: {
        sendBuy() {
            if(this.params.cycle_count == '' ){
                this.$toast({message:'周期数不能为0' })
            }else{
                this.axios.get('/store/top',{params:this.params})
                    .then(response => {
                        
                        if(response.data.code == 0){

                            this.$toast('置顶成功！')
                            
                        }else{

                            this.$toast(response.data.msg)
                        }
                    })
            }
        }
    }
}
</script>

<style lang="scss" scoped>

.scroll-wrapper {
    position: absolute; width: 100%; top: 38px; bottom: 48px;    overflow: hidden;
}

.project-from {
    overflow: hidden; 
    .tit { padding: 0 10px; line-height: 43px; font-size: 14px; background: #f4f4f4;  }
    .van-row { 
        line-height: 43px; overflow: hidden; padding:  0 10px; border-bottom: 1px solid #f4f4f4; background: #fff;
    }
    .van-radio { 
        width:50%;  line-height:17px; padding:3px 0;
        div{ height:17px; }
        span {
            display: block; color: #999;
            i{ color: #56b1f5; }
        }
    }
    .font-red, .tips { padding:10px 30px 0; line-height:21px; }
    .tips { padding-top: 17px; color:#777; }

}

</style>
