<template>
    <div class="mytasktask">
        <Scroll class="scroll-wrapper" :pullup="pullup" ref="listScroll" v-on:scrollToEnd="upData(paramsTask)"  >
            <div class="scroll">
                
                
                <ListMember />
                <div v-if="paramsTask.dataNo" style="text-align: center">无数据</div>
                <div v-else style="position: absolute;width:100%; height: 30px; line-height: 30px; text-align: center; bottom: -30px">上拉加载</div>
            </div>
        </Scroll>

        


    </div>
</template>

<script>
import ListMember from '@/components/ListMember'
import TagSelection from '@/components/TagSelection'

import Scroll from '@/components/Scroll'
// import axios from 'axios';
export default {
    name: 'MyTaskTask',
    data() {
        return {
            tit:'我的任务',
            tagAct:0,
            paramsTask:{
                token:'',
                state:'',
                pageNumber:1,
                pageSize:10,
                url:'/task/my',
                add:true,
                dataNo:false
            },

            myTaskList:[],
            
            pullup:true
            // bannimg:null

        }
    },
    components: {
       ListMember, TagSelection, Scroll
    },
    created(){
        this.paramsTask.token=localStorage.getItem("token");
        
        this.axios.get('/task/my',{params:this.paramsTask})
            .then((response) => {
                // console.log(response)
                this.myTaskList = response.data.data
            })
    },
    methods:{
        upData(obj) {
            // console.log(this.pullup)
            const _this = this;
            if(obj.add){
                obj.add=false;
                obj.pageNumber +=1;

                this.$toast.loading({
                    duration: 0,       // 持续展示 toast
                    forbidClick: true, // 禁用背景点击
                    loadingType: 'spinner',
                    message: '加载中...'
                });

                // console.log(obj.pageNumber)

                
                this.axios.get(obj.url,{params:obj})
                    .then((response) => {
                        // console.log(response+'ddd')
                        if(response.data.count == 0) {
                            this.$toast.clear();
                            obj.dataNo = true;
                            this.$toast('没有新数据了')
                        }else{

                            response.data.data.forEach(function(item){
                                _this.myTaskList.push(item)
                            })
                            
                            setTimeout(() => {
                                _this.$refs.listScroll.refresh()
                                _this.$toast.clear();
                                obj.add=true
                                // console.log(obj.add)
                        },500)
                            
                        }
                    })
            }
            
        }

    }
}
</script>

<style lang="scss" scoped>
.scroll-wrapper {position: absolute; top: 0; bottom: 0px;width: 100%;  overflow: hidden; background: #fff; }


</style>
