<template>
    <div id="page" style="background-color: #fff;">
        <TopBar :title="tit" >
            <i slot="lft" class="iconfont  icon-iconfont-edu11" @click="$router.push('usercenter')"></i>
        </TopBar>
        
        <div class="succeed-box">
            <img src="@/common/images/ok.png" alt="">
            <h3>支付成功!</h3>
            <p>请返回"个人中心" <br>查看【收支账单】确认到账情况</p>
        </div>

        <!-- <CNav /> -->
    </div>
</template>

<script>
// import CNav from '@/components/CNav'
import TopBar from '@/components/TopBar'
import Scroll from '@/components/Scroll'
// import axios from 'axios';
export default {
    name: 'page',
    components: {
        TopBar,Scroll
    },    
    data() {
        return {
            tit:'充值成功'

        }
    },
    created(){
      // this.axios.all([
      //       this.axios.get('/dept/list'),
      //       this.axios.get('/business/list'),
      //   ]).then(this.axios.spread((response1, response2) => {
      //       console.log(response2)
      //   }, (error) => {
      //       console.log(error)
      //   }));
    },
}
</script>

<style lang="scss" scoped>

.scroll-wrapper {
    position: absolute; width: 100%; top: 38px; bottom: 0;    overflow: hidden;
}

.succeed-box {
    text-align: center; position: absolute; width: 100%; top: 38px; bottom: 0;    overflow: hidden;background-color: #fff;
     img {width: 20%; margin-top: 30%;}
     h3 { font-size: 25px ; padding: 10px;  }
     p { font-size: 14px; }
}
</style>
