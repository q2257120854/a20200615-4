<template>
    <div id="page">
        <TopBar :title="tit" />
        
        
        <Scroll class="scroll-wrapper"  ref="listScroll">
            <div class="scroll">
                <!-- 保证金充值 -->
                <div class="hk10" style="height: 1px"></div>
                <div class="cash-deposit">
                    <div class="hd">保证金金额(元)</div>
                    <div class="bd">
                        <span class="logo"><img src="@/common/images/bao.png" alt=""></span>
                        <span>{{userInfo.earnest_money}}</span>
                    </div>
                    <div class="ft">
                        <router-link :to="{path:'/cashdepositbuy'}" tag="a" >充值保证金</router-link>
                    </div>
                </div>
                
                <!-- 保证金说明 -->
                <div class="cash-deposit-desc">
                    <p class="bzj_intro_title">保证金说明：</p>
                    <p>1、保证金最低金额为1000元，可以大于1000元，保证金越高，您发布任务的可信度越高，有利于您任务的快速完成；</p>
                    <p>2、缴纳保证金的商家发布的任务在前台将显示特殊标识，提高商家的信誉度，增加成交机会；</p>
                    <p>3、充值保证金的商家将享受一定的优待政策，包括但不限于独立展示任务列表等；</p>
                    <p>4、部分金融类任务，只有缴纳保证金才可以发布；</p>
                    <p>5、如果被投诉，平台将根据相关规定和证据进行仲裁，并依照相应任务金额及用户损失进行保证金处罚：</p>
                    <p class="text_indent_p">1)发布的任务如存在私下交易、私下发布其他任务、恶意篡改任务链接、二维码等，但任务内容不存在违规违法行为，视投诉情况及任务单价范围，将处以200~500元之间的罚款，罚款直接从保证金中扣除；</p> 
                    <p class="text_indent_p">2)通过加粉或通过平台渠道联系到用户，私下进行推广违规任务，如：推广同类平台、赌博类、涉黄类、挂机软件类、投资类等造成大量投诉但并未给用户造成严重的经济损失，将处以500~1000元之间的罚款，罚款直接从保证金中扣除；</p>
                    <p class="text_indent_p">3)通过发布加粉类、投资理财类、投票类、关注类等任务聚集用户，私下实施诈骗或发布违法任务，将罚没全部保证金，并永久冻结账户；</p>
                    <p class="text_indent_p">4)冒充平台工作人员，收取会费或私下以本平台名义发布任务的，将罚没全部保证金，并永久冻结账户；</p>
                    <p class="text_indent_p">5)态度恶劣，不能主动承认错误、找各种借口和理由拒不悔改、辱骂、威胁平台及工作人员的将从重加倍处罚，严重者将交由公安机关处理；</p>     
                    <p>6、保证金可申请退还，提交申请后20个工作日（即为除去周六周日及法定节假日后的天数），经审核无违规行为及投诉，保证金将全额退还，退还时收取1%的手续费。</p>
                    <p>注：如申请20个工作日后未到账，请在工作日联系2460943687或3313765207QQ客服协助您查询处理。</p>
                </div>
            </div>
        </Scroll>

    </div>
</template>

<script>

import TopBar from '@/components/TopBar'
import Scroll from '@/components/Scroll'
// import axios from 'axios';
export default {
    name: 'page',
    components: {
        TopBar,Scroll
    },    
    data() {
        return {
            tit:'保证金',
            userInfo:{}

        }
    },
    created(){

        this.axios.get('/user/info')
            .then((response) => {
                // console.log(response)
                this.userInfo=response.data.data;

                // localStorage.setItem('invite_code',this.userInfo.invite_code);
            })
      // this.axios.all([
      //       this.axios.get('/dept/list'),
      //       this.axios.get('/business/list'),
      //   ]).then(this.axios.spread((response1, response2) => {
      //       console.log(response2)
      //   }, (error) => {
      //       console.log(error)
      //   }));
    },
}
</script>

<style lang="scss" scoped>

.scroll-wrapper {
    position: absolute; width: 100%; top: 38px; bottom: 0;    overflow: hidden;
}

// 保证金
.cash-deposit {
    margin: 10px 26px; background-color: #56b1ff; text-align: center; color: #fff; border-radius:8px;
    .hd { line-height: 34px; }
    .bd { 
        line-height:28px;  vertical-align: middle;
        span { 
            display: inline-block; vertical-align: middle; font-size: 23px; line-height:23px;
            &.logo {
                height:23px; width: 23px; border-radius:50%; background-color: #fff; line-height:21px;
                img { width: 16px; height:16px;  }
            }
        }
    }
    .ft {
        padding: 20px 0 10px;
        a { display: inline-block; line-height: 17px; padding:0 6px; border: 1Px solid #fff;vertical-align: middle; border-radius:9px; }
    }
}

// 保证金说明
.cash-deposit-desc {
    margin: 0 10px; line-height:25px; padding-bottom: 10px;
}
</style>
