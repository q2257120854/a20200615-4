<template>
    <div id="page">
        <TopBar :title="tit" />
        
        <div class="my-team-me">
            <img :src="info.head_img" alt="">
            <div class="desc">
                <h3><span>{{info.nickname}}</span><i>用户ID:{{info.id}}</i></h3>
                <p>战士：<span>{{listTeam.length}}</span>人。</p>
            </div>
        </div>
        <Scroll class="scroll-wrapper"  ref="listScroll">
            <div class="scroll">
                <ListMember :listInfo="listTeam" />


            </div>
        </Scroll>
        <!-- <CNav /> -->
    </div>
</template>

<script>
// import CNav from '@/components/CNav'

import TopBar from '@/components/TopBar'
import Scroll from '@/components/Scroll'

import ListMember from '@/components/ListMember'
// import axios from 'axios';
export default {
    name: 'page',
    components: {
        TopBar,Scroll, ListMember
    },    
    data() {
        return {
            tit:'我的战队',
            info:{
                phone:'',
                id:'',
                head_img:'',
                nickname:''
            },
            listTeam:[]
        }
    },
    created(){
        this.info.phone=localStorage.getItem('phone')
        this.info.head_img=localStorage.getItem('head_img')
        this.info.id=localStorage.getItem('id')
        this.info.nickname=localStorage.getItem('nickname')
        
        this.axios.get('/user/team')
            .then((response) => {
                // console.log(response)
                this.listTeam=response.data.data;
                // console.log(response)
                // localStorage.setItem('invite_code',this.userInfo.invite_code);
            })
    },
}
</script>

<style lang="scss" scoped>

// .scroll-wrapper {
//     position: absolute; width: 100%; top: 38px; bottom: 48px;    overflow: hidden;
// }
.scroll-wrapper {
    position: absolute; width: 100%; top: 104px; bottom: 0;    overflow: hidden;
}

.my-team-me {
    padding:10px; padding-left: 60px; height:45px; background:  $body_color; position: relative; color: #f3f3f3;
    img { position: absolute; width: 40px; height: 40px; left:10px; border-radius:50%; }
    span { color: #fff; display: inline-block;}
    h3 { line-height: 20px ; vertical-align: middle;
        span {  max-width: 120px; margin-right: 22px;   text-overflow: ellipsis; overflow: hidden; white-space: nowrap; vertical-align: middle;}
        i {display: inline-block; vertical-align: middle;}
    }
    p { line-height: 20px;
        span{ text-align: center; width: 30px;}
     }
}

</style>
