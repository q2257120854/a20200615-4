<template>
    <div id="page">
        <TopBar :title="tit" />
        
        
        <Scroll class="scroll-wrapper"  ref="listScroll">
            <div class="scroll">
                <div class="feedback-wrap">
                    <van-field v-model="params.content"  type="textarea" rows="5" placeholder="请输入反馈内容" />

                    <ul  class="bd">
                        <!-- <li class="img" v-show="img != ''" v-for="(img,index) in feedback_img_json" :key="index"><img  :src="img.base64" alt=""><i class="iconfont icon-cha1" @click="delImg(index,feedback_img_json)" ></i></li> -->
                        <!-- <li>
                            <UploadImg class="up-explain" v-show="feedback_img_json.length < 5" v-on:addImg="addFeedbackImg" :font-tit="fontTit" />
                        </li> -->

                        <li  v-for="(step,index) in imgs" :key="index" >
                            <UploadImg  :imgurl="step | upImgUrl" class="up-step"  v-on:addImg="addStepImg($event,index)"  :font-tit="fontTit" />
                            <!-- <UploadImg  v-else  :imgurl="step" class="up-step"  v-on:addImg="addStepImg($event,index)" :font-tit="fontTit"   /> -->
                        </li>
                    </ul>
                </div>

                    <van-button type="info" @click="sendInfo"  class="sub-btn">提交</van-button>
            </div>
        </Scroll>
    </div>
</template>

<script>

import TopBar from '@/components/TopBar'
import Scroll from '@/components/Scroll'


import UploadImg from '@/components/UploadImg'
// import {urlReplace} from '@/common/js/common'
// import axios from 'axios';
export default {
    name: 'page',
    components: {
        TopBar,Scroll, UploadImg
    },    
    data() {
        return {
            tit:'意见反馈',
            fontTit:'',
            params:{
                task_id:null,
                content:'',
                imgs:['']
            },
            imgs:[''],
            feedback_img_json:[]
        }
    },
    created(){
        this.params.task_id = this.$route.query.task_id

    },
    methods:{
        // 提交建议信息
        sendInfo(){
            if(this.params.content == ''){
                this.$toast({message:'不合格原因不能为空！'})
            }else{
                this.params.imgs = this.imgs
                this.params.imgs = this.params.imgs.join(',')
                this.axios.get('/user/report',{params:this.params})
                    .then(response => {
                        // console.log(response)
                        if(response.data.code ==0 ){


                            this.$router.go(-1)
                            // this.$dialog.alert({message:'投诉成功！'})
                        }
                    })
            }
        },
        // 图片添加
        addStepImg(img,key) {
            this.imgs.splice(key,1,img)
            // console.log(this.params.imgs)
            if(this.imgs.length < 9) {
                // console.log(123)
                this.imgs.push('')
            }
        },

    }
}
</script>

<style lang="scss" scoped>

.scroll-wrapper {
    position: absolute; width: 100%; top: 38px; bottom: 48px;    overflow: hidden;
}


.feedback-wrap {
    background-color: #fff; 
    .bd { 
        overflow: hidden; padding:20px 10px 0; 
        li { 
            float: left;  width: 75px; padding-bottom: 20px; text-align: center;position: relative;
            img {width: 50px; height: 50px;}
            .icon-cha1 { top:-10px; left:50px; position: absolute; width: 20px; height:20px; border-radius:50%; background-color: #666; text-align: center; line-height:20px; font-size: 12px; color: #fff; }
        }
        .upload-img {
            border: 1Px solid #ccc; padding:10px 0;  line-height: 26px; width: 50px; vertical-align: middle; margin: 0 auto;

        }
    }

}
</style>
