<template>
    <div id="page">
        <TopBar :title="tit" >
            <i slot="rgt" class="i-rgt iconfont  icon-snimicfenxiang" @click="shareQr"></i>

        </TopBar>

        
        
        <Scroll class="scroll-wrapper"  ref="listScroll">
            <div class="scroll">
                <div class="user-box">
                    <div class="hd">
                        <img :src="userInfo.head_img" alt="">
                        <div class="desc">
                            <p>{{userInfo.phone}} （邀请码）</p>
                            <p>向您推荐<span class="font-red">米多多</span></p>
                            <p>ID:{{userInfo.id}}</p>
                        </div>
                    </div>

                    <div class="text">投票、关注、浏览、注册...都可赚钱<br>无需任何投入，一元即可提现，秒到帐<br>推荐好友加入，赚取更多佣金分红</div>
                    <div class="bd">
                        <h3>识别二维码，一起赚零钱</h3>
                        <div class="qr-wrap">
                            <vue-qr  class="img" :logoSrc="config.logo" :text="config.value"  :margin="0"></vue-qr>
                        </div>
                        <!-- <div class="time">此二维码30天内(2019年5月28日前)有效，重新进入将更新</div> -->
                    </div>
                    <div class="ft">
                        需要投票？需要粉丝？需要流量？<br>到<span class="font-red">米多多</span>发布任务，百万级好友帮你快速实现！
                    </div>
                    <!-- <router-link to=""></router-link> -->
                </div>
            </div>
        </Scroll>
    </div>
</template>

<script>

import TopBar from '@/components/TopBar'
import Scroll from '@/components/Scroll'


import VueQr from 'vue-qr'
// import axios from 'axios';
export default {
    name: 'page',
    components: {
        TopBar,Scroll, VueQr
    },    
    data() {
        return {
            tit:'我的二维码',
            userInfo:{},
            params:{
                pageNumber:1,
                pageSize:10,
                type_id:''
            },
            config: {
              value: '',//显示的值、跳转的地址
              // logo:'static/img/logo.png'//中间logo的地址
            },
        }
    },
    created(){
     
        let host = window.location.host;
        this.axios.get('/user/info')
            .then((response) => {
                // console.log(response)
                this.userInfo= response.data.data
                this.config.value='http://'+host+'/register?code='+response.data.data.phone
            })
    },
    methods:{
        shareQr(){
            // 判断是否在APP,并且发送用户id
            let _this = this
            if (/LT-APP/.test(navigator.userAgent)) {
                jsBridge.ready(function () { 
                    jsBridge.share({
                      title: "米多多，既能办事儿又能赚钱",
                      link  : _this.config.value,
                      desc  : "投票、关注、浏览、注册...都可赚钱，无需任何投入，一元提现秒到账！推荐好友加入，赚取更多佣金分红"
                    });
                });
            }
        }
    }
}
</script>

<style lang="scss" scoped>

.scroll-wrapper {
    position: absolute; width: 100%; top: 38px; bottom: 0;    overflow: hidden; background-color: #fff;
}

.user-box {
    width: 68%; position: relative; left: 16%;
    .hd {
        padding-top: 12px; padding-left: 60px; position: relative;
        img { position: absolute; left: 0; width: 50px; height:50px; border-radius:50%; }
        .desc { line-height: 18px; color:#222; font-weight: 600;}
    }
    .text { color: #222; line-height:18px; margin-top: 18px; }
    .bd {
        margin-top: 22px; text-align: center;
        h3 {color: #0b79e9; font-weight: 700; }
        .qr-wrap{
            width: 106px; height:106px; padding:10px; margin:10px auto 0;  border: 1Px solid #d0d0d0; border-radius:14px;overflow: hidden; 

            img { width: 106px; height:106px;  }
        }
        .time {text-align: left; margin-top:7px; color: #888; line-height:18px;}
    }
    .ft { color: #0b79e9; line-height:18px; margin-top: 18px; }
}
</style>
