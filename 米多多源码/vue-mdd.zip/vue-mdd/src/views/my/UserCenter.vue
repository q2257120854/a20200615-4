<template>
    <div id="page" class="page">
        <top-bar :title="tit"  >
            <i slot="lft"></i>
            <i slot="rgt" class="change-user" @click="changeUser" >切换账号</i>
        </top-bar>
        
        
        <Scroll class="scroll-wrapper"    ref="listScroll">
            <div class="scroll">
                <!-- 头像 昵称 -->
                <van-row   type="flex" class="head-photo" justify="center" align="center">
                    <van-col span="5">
                        <img @click="changeHead" class="head-img" :src="userInfo.head_img" alt="">
                        <UploadImg  v-show="false" ref="upImg" class="up-step"  v-on:addImg="addStepImg($event)" />
                    </van-col>
                    <van-col span="19">
                        <h3><i @click="nicknamePopup.show = true">{{userInfo.nickname}} </i><span>{{userInfo.grade | getLv}}</span></h3>
                        <p>ID：{{userInfo.id}}</p>
                    </van-col>
                </van-row>

                <!-- 账户信息 -->
                <div class="user-info-accoun" type="flex">
                    <van-row class="hd">
                        <van-col span="6"><p>保证金</p><p class="c_green">{{userInfo.earnest_money}}</p></van-col>
                        <van-col span="6" style ="border-right: 1Px solid #ccc"><router-link to="/cashdeposit" class="c_red" tag="p">充值保证金</router-link>
                            <router-link v-if="userInfo.earnest_money != 0" :to="{path:'/earnestmoneyback',query:{'earnest_money':userInfo.earnest_money}}" tag="p" class="c_red" >申退保证金</router-link>
                            <p v-else >申退保证金</p>
                        </van-col>
                        <van-col span="6"><p>信用分</p><p class="c_blue">{{userInfo.credit_score}}</p></van-col>
                        <van-col span="6"><p @click="toastNo" class="c_red">规则</p><router-link to="#" tag="p">明细</router-link></van-col>
                    </van-row>

                    <van-row class="bd">
                        <van-col span="12">
                            <h3>米币余额(元)</h3>
                            <strong>{{userInfo.mi_coin}}</strong>
                            <p>
								<router-link to="http://pay.3qbuluo.com/" class="c_red" tag="a">充值</router-link>
								<router-link :to="{path:'/micash',query:{mi_coin:userInfo.mi_coin}}" tag="a">提现</router-link>
							</p>
                        </van-col>
                        <van-col span="12">
                            <h3>收入分红(元)</h3>
                            <strong>{{userInfo.income}}</strong>
                            <p><router-link :to="{path:'/sharecash',query:{income:userInfo.income}}" tag="a">提现</router-link></p>
                        </van-col>
                    </van-row>
                </div>
                
                <!-- 我的选项菜单 -->
                <van-cell-group class="my-men">
                    <van-cell title="我的战队" to="/myteam"  is-link >
                        <i slot="icon" class="iconfont icon-wodezhandui"></i>
                    </van-cell>
                    <van-cell title="我的店铺" to="/shop"  icon="http://www.aliyunqifu.com/resources/images/antHelp/geren_zx/ico_wddp.png" is-link >
                        <i slot="icon" class="iconfont icon-dianpu"></i>
                    </van-cell>
                    <van-cell title="粉丝关注" to="/followers"  icon="http://www.aliyunqifu.com/resources/images/antHelp/geren_zx/ico_fsgz.png" is-link >
                        <i slot="icon" class="iconfont icon-fensiguanzhu"></i>
                    </van-cell>
                    <van-cell title="收支账单" to="/bill"  icon="http://www.aliyunqifu.com/resources/images/antHelp/geren_zx/ico_szzd.png" is-link >
                        <i slot="icon" class="iconfont icon-zhangdan"></i>
                    </van-cell>
                    <van-cell title="支付宝" to="/bindalipay" icon="http://www.aliyunqifu.com/resources/images/antHelp/geren_zx/ico_zfb.png" is-link >
                        <i slot="icon" class="iconfont icon-umidd17"></i>
                    </van-cell>
                    <van-cell title="我的二维码"  to="/qrcode" icon="http://www.aliyunqifu.com/resources/images/antHelp/geren_zx/ico_wdewm.png" is-link >
                        <i slot="icon" class="iconfont icon-wodeerweima"></i>
                    </van-cell>
                    <!-- <van-cell title="常见问题" to="/faq"  icon="http://www.aliyunqifu.com/resources/images/antHelp/geren_zx/ico_cjwt.png" is-link >
                        <i slot="icon" class="iconfont icon-changjianwenti"></i>
                    </van-cell> -->
                    <!-- <van-cell title="使用帮助"  icon="http://www.aliyunqifu.com/resources/images/antHelp/geren_zx/ico_sybz.png" is-link /> -->
                    <!-- <van-cell title="退出登录" to="/feedback" icon="http://www.aliyunqifu.com/resources/images/antHelp/geren_zx/ico_yjfk.png"  /> -->
                    <!-- <van-cell title="意见反馈" to="/feedback" icon="http://www.aliyunqifu.com/resources/images/antHelp/geren_zx/ico_yjfk.png" is-link /> -->
                </van-cell-group>
            </div>
        </Scroll>
        
        <van-dialog v-model="nicknamePopup.show" title="修改昵称" show-cancel-button get-container="#app" @confirm="changeNickname">
            <div class="bd">
                <van-field class="text" v-model="nicknamePopup.nickname" placeholder="请输入新昵称" />
            </div>
        </van-dialog>
        
    </div>
</template>

<script>
// import CNav from '@/components/CNav'
import UploadImg from '@/components/UploadImg'

import TopBar from '@/components/TopBar'
import Scroll from '@/components/Scroll'
// import axios from 'axios';
export default {
    name: 'page',
    components: {
        TopBar,Scroll,UploadImg
    },    
    data() {
        return {
            tit:'个人中心',
            userInfo:'',
            nicknamePopup:{
                show:false,
                nickname:''
            }
        }
    },
    created(){
        this.axios.get('/user/info')
            .then((response) => {
                // console.log(response)
                this.userInfo=response.data.data;

                // localStorage.setItem('invite_code',this.userInfo.invite_code);
            })
    },
    filters:{
        getLv(val) {
            return val==1 ? '会员' : '队长'
        }
    },
    methods:{
        // 修改昵称
        changeNickname(){
            // console.log(1)
            if(this.nicknamePopup.nickname == ''){
                this.$toast('新昵称不能为空!')
            }else{
                this.axios.get('/user/updateNickname',{params:this.nicknamePopup})
                    .then(response => {
                        if(response.data.code == 0){
                            localStorage.setItem('nickname',this.nicknamePopup.nickname);
                            this.userInfo.nickname =this.nicknamePopup.nickname
                            this.$toast('修改成功!')
                        }else{
                            this.$toast(response.data.msg)
                        }
                    })
            }
        },
        toastNo () {
            this.$toast('暂未开放此功能')
        },
        // 头像换图
        changeHead () {
            let file=this.$refs.upImg.$el.children[4]
            file.click()
            // console.log(this.$refs.upImg.$el.children[4])
        },
        // 图片添加
        addStepImg(img) {
            // console.log(img)
            this.userInfo.head_img = this.GLOBAL.QiNiu + img
            this.axios.get('/user/upload/headimg',{params:{img:img}})
                .then(response => {
                    if(response.data.code ==0 ){
                        this.$toast('头像修改成功！')
                    }else{
                        this.$toast(response.data.msg)
                    }
                    // console.log(response)
                })
            // this.imgs.splice(key,1,img)
            // // console.log(this.popupReject.imgs)
            // if(this.imgs.length < 2) {
            //     // console.log(123)
            //     this.imgs.push('')
            // }
        },
        changeUser () {
            // console.log(localStorage)
            localStorage.removeItem('token');
            localStorage.removeItem('phone');
            localStorage.removeItem('id');


            // 判断是否APP，清楚别名
            if (/LT-APP/.test(navigator.userAgent)) {
                jsBridge.ready(function () { 
                    jsBridge.jiguang.deleteAlias(function(alias){
                      // alert(alias);
                    });
                });
            }

            this.$router.replace(
                { 
                    path: '/login',
                }
            )
        }
    }
}
</script>

<style lang="scss" scoped>
.page .change-user{
    left:auto; right:0; font-size: 14px; width: auto; padding:0 10px;
}
.scroll-wrapper {
    position: absolute; width: 100%; left:0; top: 38px; bottom: 0;    overflow: hidden;
}

// 头像 昵称
.head-photo {
    padding:23px 16px 75px; background-color:  $body_color;
    .head-img { width: 44px; height:44px; border-radius:50%; border:3px solid #fff; }
    h3 { font-size: 13px;  color: #fff;  line-height: 26px;}
    p { font-size: 12px; color: #f3f3f3; }
}

// z账户信息
.user-info-accoun {
    margin:-47px 10px 0 ; background-color: rgba(255,255,255,0.9); border-radius:10px;    box-shadow: 0px 1px 4px rgba(0,0,0,0.3), 0px 0px 20px rgba(0,0,0,0.1) inset; text-align: center; overflow: hidden;
    .hd {
        line-height:23.5px; 
        p {
            color: #919299;
            &.c_red { color:#f66364; text-decoration: underline; }
            &.c_green { color:#07cd60;  }
            &.c_blue { color:#2998ff;  }
        }
    }
    .bd {
        background:#fff; padding-top: 5px;
        h3 { line-height:20px; color:#919292; }
        strong { font-size: 18px; color: #222; line-height:27px; font-weight: normal; }
        p { 
            line-height:25px;
            a { color: #f66364; line-height: 14px; margin: 0 5px; border: 1Px solid #e2e2e2; padding:0 5px; display: inline-block; border-radius:7px; }
         }
    }
}

// 我的菜单
.my-men {
    margin-top: 10px; 
    .iconfont{ 
        width: 18.75px; margin-right: 5px; font-size: 18px;
        &.icon-wodezhandui { color:#08aa32; }
        &.icon-dianpu { color:#70c6f9; }
        &.icon-fensiguanzhu { color:#f34f4d; }
        &.icon-zhangdan { color:#ff8d59; }
        &.icon-umidd17 { color:#4da6ea; }
        &.icon-wodeerweima { color:#748cfa; }
    }
}
</style>
