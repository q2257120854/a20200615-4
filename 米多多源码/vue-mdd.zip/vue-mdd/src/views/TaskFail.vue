<template>
    <div id="page">
        <TopBar :title="tit" >
            <em class="i-rgt" slot="rgt" @click="affirmAppeal">申诉</em>
        </TopBar>
        
        
        <Scroll class="scroll-wrapper"  ref="listScroll" v-if="failInfo !=0">
            <div class="scroll">
                <!-- 任务信息 -->
                <div class="task-info-wrap">
                    <div class="exchange-info">
                        <div class="hd">
                            <span>信息交流：</span>
                            <ul class="desc">

                                <li v-for="(item,idx) in failInfo.chatlist">
                                    {{item.content}}
                                    <div class="img" v-if="item.image_list.length != 0">
                                        <img v-for="(i,num) in item.image_list.split(',')" :src="i" alt="">
                                    </div>
                                </li>
                            </ul>
                        </div>
                        <div class="ft">
                            <i class="btn" @click="togglePopup('popupReply')">回复</i>
                        </div>
                    </div>
                </div>

                <!-- 用户上传的验证图片 -->
                <van-swipe class="audit_img" @change="onChange">
                    <van-swipe-item v-for="(item,idx) in failInfo.auth_img.split(',')" :key="idx"><img :src="item" alt=""></van-swipe-item>
                    <div class="custom-indicator" slot="indicator">
                        {{ current + 1 }}/{{failInfo.auth_img.split(',').length}}
                    </div>
                </van-swipe>
                
                <!-- 文字验证内容 -->
                <div v-if="failInfo.word_verify" class="audit_text">
                    {{failInfo.word_verify}}
                </div>

                <!--  是否合格按钮 -->
                <div class="btn-wrap">
                    <button class=" btn ok" @click="myTaskDel(failInfo.task_id)">放弃</button>
                    <router-link tag="button" :to="{path:'/taskverify',query:{task_id:failInfo.task_id}}" class="  btn re">重做</router-link>
                </div>
                
                <div class="hk"></div>

            </div>
        </Scroll>
        


        <!-- 回复弹窗 -->
        <van-popup v-model="popupReply.show" class="popup_wrap reject_wrap">
            <div class="reject_text">
                <textarea v-model="popupReply.content" placeholder="请输入回复内容…" rows="4"></textarea>
            </div>
            <!--  是否合格按钮 -->
            <div class="pop_btn_wrap">
                <button class="btn " @click="togglePopup('popupReply')" >取消</button>
                <button class="btn " @click="sendReply">确定</button>
            </div>
        </van-popup>

        <!-- <CNav /> -->
    </div>
</template>

<script>
// import CNav from '@/components/CNav'

import TopBar from '@/components/TopBar'
import Scroll from '@/components/Scroll'


import UploadImg from '@/components/UploadImg'
import {urlReplace} from '@/common/js/common'

// import axios from 'axios';
export default {
    name: 'page',
    components: {
        TopBar,Scroll, UploadImg
    },    
    data() {
        return {
            tit:'详情',
            fonttit:' ',
            current: 0,
            failInfo:[],
            popupReply:{
                show:false,
                content:''
            }
        }
    },
    created(){

        // this.myInfo.phone = localStorage.getItem('phone')
        this.axios.get('/task/check',{params:{task_id:this.$route.query.task_id}})
            .then((response) => {
                // console.log(response)
                this.failInfo = response.data.data
            })
    },
    methods: {
        // 删除我的任务
        myTaskDel(id){
            // console.log(id)
            this.$dialog.confirm({
                title: '注意',
                message: '确认要放弃任务吗？'
            }).then(() => {
                // on confirm
                this.axios.get('/task/deletemy',{params:{task_id:id}})
                    .then((response) => {
                        // console.log(response)
                        if(response.data.code == 0){
                            this.$router.replace('/mytask/t')
                        }
                    })
            }).catch(() => {
              // on cancel
            })
        },
        // 回复商家
        sendReply(){
            if(this.popupReply.content == ''){
                this.$dialog.alert({message:'回复内容不能为空'})
            }else{
                this.popupReply['mytask_id'] = this.failInfo.id
                this.axios.get('/task/chat',{params:this.popupReply})
                    .then(response => {
                        // console.log(response)
                        if(response.data.code == 0){
                            this.$router.replace('/mytask/t')
                        }
                    })
            }
        },
        // 申诉
        affirmAppeal() {
            this.$dialog.confirm({
                title:'友情提示！',
                messageAlign:'left',
                closeOnClickOverlay:true,
                message: '与商家沟通直接点击“回复”按钮即可，勿走申诉通道，申诉通道内容商家看不到，不符合申诉条件的将不会受理，您确认是要申诉吗？'
            }).then(() => {
              // on confirm
              
                this.$router.replace({path:'/taskappeal',query:{task_id:this.failInfo.task_id}})
            }).catch(() => {
              // on cancel
            });
        },
        // 用户上传验证图的 当前页数
        onChange(index) {
            this.current = index;
        },
        // 弹窗展示
        togglePopup(popup) {
           this[popup].show = !this[popup].show
        },
        // 图片添加
        addStepImg(img,key) {
            this.rejectJson.img_json[key].explain_img=img;
            if(this.rejectJson.img_json.length == 1) {
                this.rejectJson.img_json.push({'explain_img':''})
            }
        },
    }
}
</script>

<style lang="scss" scoped>

.scroll-wrapper {
    position: absolute; width: 100%; top: 38px; bottom: 0;    overflow: hidden;
}





//  用户上传的验证图片
.audit_img {
    width: 170px; margin: 20px auto 0; 
    .van-swipe-item { 
        position: relative;
        .audit_state {
            position: absolute; right:0; top:0; padding: 0 4px; color: #fff; line-height: 26px;
            &.check_state_sign {background: #56b1ff;}
        }
     }
    img { width: 100%; height:auto; max-height: 360px; }

    .custom-indicator { display: block; text-align: center; }
}

// 文字验证
.audit_text { margin: 10Px auto ; width: 188px; padding:10Px; background-color: #fff; line-height:21px; color: #999; }



// 不合格弹窗
.reject_wrap {
    
    .reject_text {
        padding: 25px 0;
        textarea { display: block; padding:5Px; width: 80%; margin:0 auto; line-height:14px; }
    }
    .img_up {
        padding:0 15px; overflow: hidden;
        li {
            width: 50px; height: 50px; float: left; margin: 0 8px 17px ;

            .upload-img { 
                height:44px; padding:6px 0  0; border: none; 
            }
        }
    }
    .tit { width: 84%; margin:0 auto; line-height:17px; }
}
</style>
