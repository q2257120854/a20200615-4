<template>
    <div id="index">
        <van-swipe class="banner" :autoplay="3000" indicator-color="white">
            <van-swipe-item v-for="item in bannerList" :key="item.id" ><img :src="item.img" alt=""></van-swipe-item>
        </van-swipe>
        <van-notice-bar  :text="noticeList"  left-icon="volume-o"/>

        <ul class="idx-menu">
            
            <li><router-link tag="a" to="/taskhall"><i class="iconfont icon-qian2 blue"></i><h3>我要赚钱</h3><p>投票、关注、浏览也可赚钱</p></router-link></li>
            <li><router-link tag="a" to="/taskpublish"><i class="iconfont icon-renwu2 yellow"></i><h3>发布任务</h3><p>要投票？要粉丝？还是品牌推广？有事儿您说话</p></router-link></li>
            <li><router-link tag="a" to="/qrcode"><i class="iconfont icon-erweima green"></i><h3>我的二维码</h3><p>推荐好友返佣金(充值2%提现10%)好友够多，你可不劳而获</p></router-link></li>
            <li><router-link tag="a" to="/mytask"><i class="iconfont icon-renwu1 red"></i><h3>我的任务</h3><p>已接单的任务在这里，完成任务以后来这儿上传验证图吧</p></router-link></li>
        </ul>
        
        <!-- <a   href="https://www.yimenapp.net/doc/demo.cshtml#share" >测试</a> -->
        <!-- <CNav /> -->
    </div>
</template>

<script>
// import CNav from '@/components/CNav'
// import axios from 'axios';
export default {
    name: 'Index',
    components: {
        
    },
    data(){
        return {
            bannerList:[],
            noticeList:''
        }
    },
    created(){

      this.axios.all([
            this.axios.get('/banner/list'),
            this.axios.get('/notice/list'),
        ]).then(this.axios.spread((response1, response2) => {
            // console.log(response2)
            this.bannerList = response1.data.data
            response2.data.data.forEach((item,key) => {
                // console.log(item)
                this.noticeList +=(key+1)+'.'+item.content+' '
            })
            // console.log(this.noticeList.join('-'))
        }, (error) => {
            // console.log(error)
        }));
    },
}
</script>

<style lang="scss">

.banner {
    img {width:100%; height:125px;}
}

.idx-menu {
    padding-top: 10px; padding-left: 10px; overflow: hidden;
    li { 
        float: left; width:50%;  
        a { 
            display: block; min-height: 120px; padding-top: 10px; margin-right: 10px; margin-bottom: 10px; background:#fff; border: 1Px solid #eee; text-align: center; border-radius:5px;
            i { 
                display: block; margin: 0 auto;  width:45px; height:45px; line-height: 45px;  border-radius: 50%; font-size: 20px; color: #fff;
                &.blue {background-color: #84d5f0;}
                &.yellow {background-color: #ffc24b;}
                &.green {background-color: #82d04d;}
                &.red {background-color: #ff6f84;}
             }
            h3 {
                font-size: 12px; color: #000; line-height: 1; padding-top: 10px; 
            }
            p { font-size: 10px; color: #999; line-height: 1.4; padding: 6px 10px 10px; }
        }
    }
}
</style>
