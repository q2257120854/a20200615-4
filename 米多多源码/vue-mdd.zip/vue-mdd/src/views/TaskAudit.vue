<template>
    <div id="page">
        <TopBar :title="tit" />
        
        
        <Scroll class="scroll-wrapper"  ref="listScroll" v-if="auditInfo.length != 0">
            <div class="scroll">
                <!-- 任务信息 -->
                <div class="task-info-wrap" >
                    <ul class="task-info">
                        <li>编&nbsp;&nbsp;&nbsp;号：<span>{{auditInfo[0].task_id}}</span></li>
                        <li >发布方：<span>{{myInfo.nickname}}</span></li>
                        <li>已审核：<span>{{myInfo.auditNum}}</span></li>
                        <li>未审核：<span>{{auditInfo.length}}</span></li>
                    </ul>
                    <div class="exchange-info" v-if="auditInfo[0].chatlist.length !=0">
                        <div class="hd">
                            <span>信息交流：</span>
                            <ul class="desc">
                                <li v-for="(item,idx) in auditInfo[0].chatlist">
                                    {{item.content}}
                                    <div class="img" v-if="item.image_list.length != 0">
                                        <img v-for="(i,num) in item.image_list.split(',')" :src="i" alt="">
                                    </div>
                                </li>
                                <!-- <li>拉法士大夫的辣辣拉法士大夫的辣辣拉法士大夫的辣辣拉法士大夫的辣辣拉法士大夫的辣辣拉法士大夫的辣辣</li> -->
                            </ul>
                        </div>
                    </div>
                </div>

                <!-- 任务完成者信息 -->
                <div class="user-info">
                    <div class="content" >
                        <img :src="auditInfo[0].head_img" alt="">
                        <div class="desc">
                            <p>用户：{{auditInfo[0].nickname}}</p>
                            <p>用户id：{{auditInfo[0].user_id}}</p>
                        </div>
                    </div>
                </div>

                <!-- 用户上传的验证图片 -->
                <van-swipe class="audit_img" @change="onChange" v-if="auditInfo.length !=0">
                  <van-swipe-item v-for="(item,idx) in auditInfo[0].auth_img.split(',')" :key="idx"><img :src="item" alt=""  v-image-preview><div class="audit_state check_state_sign">待审</div></van-swipe-item>
                  <div class="custom-indicator" slot="indicator">
                    {{ current + 1 }}/{{auditInfo[0].auth_img.split(',').length}}
                  </div>
                </van-swipe>
                
                <!-- 文字验证内容 -->
                <div class="audit_text" v-if="auditInfo[0].word_verify">
                    {{auditInfo[0].word_verify}}
                </div>

                <!--  是否合格按钮 -->
                <div class="btn-wrap">
                    <button class=" btn no" @click="togglePopup('popupReject')">不合格</button>
                    <button class=" btn ok" @click="auditFinish">合格</button>
                    <p>如有骗单行为请点此<i @click="togglePopup('popupComplain')">投诉</i></p>
                </div>

            </div>
        </Scroll>
        
        <!-- 不合格弹窗 -->
        <van-popup v-model="popupReject.show" class="popup_wrap reject_wrap">
            <div class="reject_text">
                <textarea v-model="popupReject.reject_reason" placeholder="请输入不合格原因..." rows="4"></textarea>
            </div>
            <ul class="img_up" >
                <li  v-for="(step,index) in imgs" :key="index" >
                    <UploadImg :imgurl=" step | upImgUrl" class="up-step"  v-on:addImg="addStepImg($event,index)"  :font-tit="fonttit" />
                    <!-- <UploadImg  v-else  :imgurl="step" class="up-step"  v-on:addImg="addStepImg($event,index)" :font-tit="fonttit"   /> -->
                </li>

            </ul>
            <div class="tit">
                如接单用户所提交的验证图无后台数据或其它可以证明其没有完成任务的，可上传相关截图说明！
            </div>
            <!--  是否合格按钮 -->
            <div class="pop_btn_wrap">
                <button class="btn " @click="togglePopup('popupReject')" >取消</button>
                <button class="btn " @click="auditFail">确定</button>
            </div>
        </van-popup>

        <!-- 投诉弹窗 -->
        <van-popup v-model="popupComplain.show" class="popup_wrap reject_wrap">
            <div class="reject_text">
                <textarea v-model="popupComplain.content" placeholder="请输入投诉理由和内容…" rows="4"></textarea>
            </div>
            <!--  是否合格按钮 -->
            <div class="pop_btn_wrap">
                <button class="btn " @click="togglePopup('popupComplain')" >取消</button>
                <button class="btn " @click="sendComplain">确定</button>
            </div>
        </van-popup>

        <!-- <CNav /> -->
    </div>
</template>

<script>
// import CNav from '@/components/CNav'

import TopBar from '@/components/TopBar'
import Scroll from '@/components/Scroll'


import UploadImg from '@/components/UploadImg'
import {urlReplace} from '@/common/js/common'

// import axios from 'axios';
export default {
    name: 'page',
    components: {
        TopBar,Scroll, UploadImg
    },    
    data() {
        return {
            tit:'审核',
            fonttit:' ',
            current: 0,
            auditInfo:[],
            myInfo:{
                phone:'',
                auditNum:0,
                nickname:'',
            },
            popupReject:{
                show:false,
                reject_reason:'',
                imgs:['']
            },
            imgs:[''],
            popupComplain:{
                show:false,
                content:'',
            },
        }
    },
    created(){
        // console.log(this.$route.query.task_id)
        this.myInfo.phone = localStorage.getItem('phone')
        this.myInfo.nickname = localStorage.getItem('nickname')
        this.axios.get('/task/mypublish/'+this.$route.query.task_id)
            .then((response) => {
                // console.log(response)
                this.auditInfo = response.data.data
            })

    },
    methods: {
        // getU
        // 用户上传验证图的 当前页数
        onChange(index) {
            this.current = index;
        },
        // 通过审核
        auditFinish(){
            let params ={
                task_id:this.auditInfo[0].task_id,
                user_id:this.auditInfo[0].user_id
            }
            this.axios.get('/task/finish',{params:params})
                .then(response => {
                    if(response.data.code == 0) {
                        this.auditInfo.shift()
                        this.myInfo.auditNum +=1

                        if(this.auditInfo.length == 0){
                            this.$router.replace('/mytask/p')
                        }
                    }
                })
        },
        // 弹窗展示
        togglePopup(popup) {
           this[popup].show = !this[popup].show
        },
        // 图片添加
        addStepImg(img,key) {
            this.imgs.splice(key,1,img)
            // console.log(this.popupReject.imgs)
            if(this.imgs.length < 2) {
                // console.log(123)
                this.imgs.push('')
            }
        },
        // 不合格 信息
        auditFail(){
            if(this.popupReject.reject_reason == ''){
                this.$dialog.alert({message:'不合格原因不能为空！'})
            }else{
                this.popupReject['task_id']= this.auditInfo[0].task_id
                this.popupReject['user_id']= this.auditInfo[0].user_id
                this.popupReject.imgs = this.imgs
                this.popupReject.imgs = this.popupReject.imgs.join(',')
                this.axios.get('/task/fail',{params:this.popupReject})
                    .then(response => {
                        // console.log(response)
                        if(response.data.code ==0 ){
                            this.popupReject.show = false

                            this.auditInfo.shift()
                            this.myInfo.auditNum +=1

                            
                            if(this.auditInfo.length == 0){
                                this.$router.replace('/mytask/p')
                            }
                            // this.$dialog.alert({message:'投诉成功！'})
                        }
                    })
            }
        },
        // 投诉用户骗单
        sendComplain(){
            if(this.popupComplain.content == ''){
                this.$dialog.alert({message:"投诉内容不能为空！"})
            }else{
                this.popupComplain['task_id']= this.auditInfo[0].task_id
                this.popupComplain['user_id']= this.auditInfo[0].user_id
                this.axios.get('/user/complain',{params:this.popupComplain})
                    .then(response => {
                        // console.log(response)
                        if(response.data.code ==0 ){
                            this.popupComplain.show = false
                            this.$dialog.alert({message:'投诉成功！'})
                        }
                    })
            }
        }
    }
}
</script>

<style lang="scss" scoped>

.scroll-wrapper {
    position: absolute; width: 100%; top: 38px; bottom: 0;    overflow: hidden;
}



//  任务完成者信息
.user-info {
    text-align: center;
    .content {
        padding:10px 0; display: inline-block; overflow: hidden; 
        img { width: 30px; height: 30px; margin:0 12px; border: 1Px solid #fff; border-radius: 50% }
        .desc { float: right; text-align: left; line-height: 16px; }
    }
}

//  用户上传的验证图片
.audit_img {
    width: 170px; margin: 10px auto 0; 
    .van-swipe-item { 
        position: relative; 
        .audit_state {
            position: absolute; right:0; top:0; padding: 0 4px; color: #fff; line-height: 26px;
            &.check_state_sign {background: #56b1ff;}
        }
     }
    img { width: 100%; height:auto; max-height: 360px; min-height:50px;}

    .custom-indicator { display: block; text-align: center; }
}

// 文字验证
.audit_text { margin: 10Px auto ; width: 188px; padding:10Px; background-color: #fff; line-height:21px; color: #999; }



// 不合格弹窗
.reject_wrap {
    
    .reject_text {
        padding: 25px 0;
        textarea { display: block; padding:5Px; width: 80%; margin:0 auto; line-height:14px; }
    }
    .img_up {
        padding:0 15px; overflow: hidden;
        li {
            width: 50px; height: 50px; float: left; margin: 0 8px 17px ;

            .upload-img { 
                height:44px; padding:6px 0  0; border: none; 
            }
        }
    }
    .tit { width: 84%; margin:0 auto; line-height:17px; }
}
</style>
