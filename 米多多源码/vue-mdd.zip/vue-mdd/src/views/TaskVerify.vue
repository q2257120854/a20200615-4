<template>
    <div id="page">
        <TopBar :title="tit" />
        
        <router-link tag="a" class="btn_back" to="index"><img src="../common/images/right_hovering.png" alt=""></router-link>
        
        <Scroll class="scroll-wrapper"  ref="listScroll">
            <div class="scroll">
                <!-- 任务描述 -->
                <TaskVerifyDescribe :taskDescribe="taskDetails" />

                <!-- 上传验证图 -->
                <div class="verify-pic">
                    <div class="hd">验证图</div>
                    <UploadImg v-on:addImg="pushImg" v-show="explain_img_json.length < 6" />
                    <div class="bd">
                        <van-row class="imga">
                            <van-col span="8" v-for="(pic,index) in explain_img_json" :key="index" ><i class="iconfont icon-cha1" @click="delPic(index)"></i><img  :src="GLOBAL.QiNiu + pic" alt=""><p>第{{index+1}}张</p></van-col>
                        </van-row>
                        
                    </div>
                    <div class="ft"  v-if="taskDetails.word_verify != '' ">
                        
                            <van-field class="text" v-model="upParams.word_verify" placeholder="请输入文字验证…" type="textarea"     rows="1"    autosize />
                    </div>
                    <van-button class="submit"  @click="subVerify" type="primary">提交</van-button>
                </div>
            </div>
        </Scroll>
        <!-- <CNav /> -->
    </div>
</template>

<script>
// import CNav from '@/components/CNav'

import TopBar from '@/components/TopBar'
import Scroll from '@/components/Scroll'

// 任务描述
import TaskVerifyDescribe from '@/components/TaskVerifyDescribe'

import UploadImg from '@/components/UploadImg'

import {urlReplace} from '@/common/js/common'
// import axios from 'axios';
export default {
    name: 'page',
    components: {
        TopBar,Scroll,TaskVerifyDescribe,UploadImg
    },    
    data() {
        return {
            tit:'上传图片',
            upParams:{
                auth_img:null,
                task_id:null,
                word_verify:""
            },
            taskDetails:{
                word_verify:null
            },
            explain_img_json:[],
        }
    },
    created(){

        this.upParams.task_id =this.$route.query.task_id
        this.axios.get('/task/detail',{params:{task_id:this.upParams.task_id}})
            .then((response) => {
                // console.log(response)
                this.taskDetails = response.data.data
                // // 验证图
                // this.explain_img = this.taskDetails.explain_img.split(',')
            })
    },
    methods:{
        subVerify() {
            // console.log(this.picA)
            if (this.taskDetails.word_verify != '' && this.upParams.word_verify == "") {
                this.$toast('文字验证不能为空')
            }else if(this.explain_img_json.length==0){
                this.$toast('验证图不能空')
            }else {


                this.upParams.auth_img =this.explain_img_json.join(',')

                    // console.log(this.upParams.auth_img)
                this.axios.post('/task/submit',this.qs.stringify(this.upParams))
                    .then((response) => {
                       if(response.data.code == 0){
                            this.$toast('上传成功')
                            this.$router.replace('/mytask/t')
                            
                       }
                        // console.log(response)
                    })
            }
        },
        delPic(key) {
            // this.picA.splice(key,1)

            let imgKey=this.explain_img_json[key]
            this.axios.get('/qiniu/manage',{params:{op:'delete',filename:imgKey}})
                .then((response) => {
                    // console.log(response)
                    this.explain_img_json.splice(key,1);
                })
        },
        pushImg(img) {
            // let pic={base64:img}
            // console.log(img)
            this.explain_img_json.push(img)
            // setTimeout(() => { this.$refs.listScroll.refresh() },300)
            
        }

    }
}
</script>

<style lang="scss" scoped>

.scroll-wrapper {
    position: absolute; width: 100%; top: 38px; bottom: 0;   overflow: hidden;
}

// 图片上传 预览部分
.verify-pic {
    padding-bottom: 30px; background-color: #fff;
    .hd { text-align: center; padding: 10px; font-size: $fon_size_small;}
    .bd {
        .imga{
            padding: 10px; 
            .van-col { padding: 0 10px; position: relative; }
            i { position: absolute; right: 0; top: -5px; width:20px; height:20px; background: #f00; color: #fff; text-align: center; line-height: 20px; font-size: 12px; border-radius:50%}
            img {height: 100px; }
            p {text-align: center; line-height: 35px; }
        }
    }
    .ft{
        padding: 0 20px;
        .text { background: #f4f4f4; }
    }
    .submit {
        display: block; margin-top: 30px; width: 50%; margin-left: 25%; line-height: 30px; height: 40px;
    }

}
</style>
