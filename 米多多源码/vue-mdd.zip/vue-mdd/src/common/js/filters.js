import Global from '@/common/js/Global'

// 判断图片链接是否有值，加七牛链接
export const upImgUrl = url => { return url =='' ? url : Global.QiNiu + url}
// 判断任务平台是安卓还是苹果
export const iconDevice = device => { return device == 1 ? "卓" : "苹"}