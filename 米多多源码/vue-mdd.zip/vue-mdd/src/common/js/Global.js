

const QiNiu = 'http://qiniu.68m42.cn/'

export default { QiNiu }
