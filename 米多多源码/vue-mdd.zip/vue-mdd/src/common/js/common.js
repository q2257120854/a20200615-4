const urlReplace = function(url) {
    
    return url.replace("data:image/png;base64,","").replace("data:image/jpeg;base64,","")
}
export {urlReplace}
// // 设置 rem 函数
function setRem() {
    let htmlWidth = document.documentElement.clientWidth || document.body.clientWidth;
    let htmlDom = document.getElementsByTagName('html')[0];
    if (htmlWidth > 750) { htmlWidth = 750 };
    htmlDom.style.fontSize = htmlWidth / 20 + 'px';
    // console.log(htmlWidth)
}
// 初始化
setRem()
// 改变窗口大小时重新设置 rem
window.onresize = function() {
    setRem()
}
