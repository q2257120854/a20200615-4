// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import VueDirectiveImagePreviewer from 'vue-directive-image-previewer'
import 'vue-directive-image-previewer/dist/assets/style.css'
Vue.use(VueDirectiveImagePreviewer)

// 七牛云域名
import global_ from './common/js/Global'
 Vue.prototype.GLOBAL =global_
 // 图片压缩
import lrz from 'lrz' 
 // axios 引入

import axios from 'axios'
import VueAxios from 'vue-axios'
import qs from 'qs'
Vue.prototype.qs = qs;
Vue.use(VueAxios, axios)
axios.defaults.withCredentials = true;
axios.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded';


let token = '';
axios.defaults.headers.common['Authorization'] = token

axios.defaults.baseURL='http://api.3qbuluo.com';

// axios.defaults.baseURL='http://192.168.0.222:8081'
//  axios 请求拦截
axios.interceptors.request.use(
    config => {
        const user = localStorage.getItem('token')
        if (user !== null) {
            token = user;
        }
        config.headers.common['Authorization'] = token
        return config
    }, function (error) {
    return Promise.reject(error) 
    }
)

// 路由引入
import VueRouter from 'vue-router'
import routes from './routers.js'

Vue.use(VueRouter);

// 公用js
import './common/js/common.js'

// 文字复制组件
import VueClipboard from 'vue-clipboard2'
Vue.use(VueClipboard)

//  vant 引入
import { Row, Col,Swipe, SwipeItem ,NoticeBar,Search, Popup, Field, Button, RadioGroup, Radio, DatetimePicker, Dialog, Toast, Checkbox, Cell, CellGroup     } from 'vant'
Vue.use(Row).use(Col).use(Swipe).use(SwipeItem).use(NoticeBar).use(Search).use(Popup).use(Field).use(Button).use(RadioGroup).use(Radio).use(DatetimePicker).use(Dialog)
Vue.use(Toast).use(Checkbox).use(Cell).use(CellGroup)

// 过滤器加载
import * as filters from './common/js/filters.js'
// console.log()
Object.keys(filters).forEach(key => {
    Vue.filter(key,filters[key])
})


//css重置 
import '@/common/css/reset.css'
import '@/common/css/vant_style.scss'

Vue.config.productionTip = false

const router =new VueRouter({
    mode: 'history',
    base: __dirname,
    routes
});


router.beforeEach((to, from, next) => {
  // console.log(from)
  let token = localStorage.getItem('token');//获取本地存储的token

  if (to.meta.requireAuth) {  // 判断该路由是否需要登录权限
    if ( token != null &&  token != null ) {  // 通过vuex state获取当前的token是否存
        next();
    }
    else {
      next({
        path: '/login',
        query: {redirect: to.fullPath}  // 将跳转的路由path作为参数，登录成功后跳转到该路由
      })
    }
  }
  else {
    next();
  }
})

// 请求拦截
axios.interceptors.response.use(function (response) {
    // console.log(response.data.code)
    if(response.data.code == 10011 ) {
        // console.log(123)
        router.push('/login')
    }
    return response;
  }, function (error) {
    return Promise.reject(error);
  });

/* eslint-disable no-new */
new Vue({
    router,
    el: '#app',
    components: { App },
    template: '<App/>'
})
