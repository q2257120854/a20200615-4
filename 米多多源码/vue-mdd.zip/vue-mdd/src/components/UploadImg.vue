<template>
    <div class="upload-img" >
        <img v-show="imgurl != null" :src="imgurl"  alt="">
        <i class="iconfont icon-jiahao"></i>
        <p class="fonttit">{{fontTit}}</p>
        <label @click="fileClick"></label>
        <input ref="file"  class="upload" @change='add_img'  type="file" accept="image/gif, image/jpeg, image/png, image/jpg" >  
    </div>
</template>

<script>
export default {
    name: 'uploadImg',
    props:{
        imgurl:{
            type:String,
            default:null
        },
        fontTit:{
            type:String,
            default:'上传验证图'            
        }
    },
    data () {
        return {
            imgResult:'',
            token:'',
            loading:null
        }
    },
    methods:{
        fileClick() {
            this.$refs.file.dispatchEvent(new MouseEvent('click'));
        },
        // 上传图片到七牛
        uploadImgToQiniu(file){
            const axiosInstance = this.axios.create({withCredentials: false});    //withCredentials 禁止携带cookie，带cookie在七牛上有可能出现跨域问题
            let data = new FormData();
            data.append('token', this.token);     //七牛需要的token，叫后台给，是七牛账号密码等组成的hash
            data.append('file', file);
            axiosInstance({
                method: 'POST',
                url: 'http://up-z2.qiniup.com',  //上传地址
                data: data,
                timeout:30000,      //超时时间，因为图片上传有可能需要很久
                onUploadProgress: (progressEvent)=> {
                    //imgLoadPercent 是上传进度，可以用来添加进度条
                    let imgLoadPercent = Math.round(progressEvent.loaded * 100 / progressEvent.total);
                },
            }).then(data =>{
                this.imgResult= data.data.key
                this.$emit('addImg',this.imgResult)
                this.$refs.file.value = ''        //上传成功，把input的value设置为空，不然 无法两次选择同一张图片
                //上传成功...  (登录七牛账号，找到七牛给你的 URL地址) 和 data里面的key 拼接成图片下载地址
                this.loading.clear();
                        // console.log('2')
            }).catch(function(err) {
                //上传失败
            });
        },
        add_img() {
            let files = event.target.files || event.dataTransfer.files;
            // console.log(files)
            const maxSize=1024;

            this.loading = this.$toast.loading({
                    // mask: true,
                    forbidClick:true,
                    duration:0,
                    message: '加载中...'
                })
            this.axios.get('/qiniu/token')
                .then((response) => {

                    this.token = response.data.data
                    if(files[0].size/1024 > maxSize){
                        
                        lrz( files[0],{quality:0.6})  
                            .then((rst) => {
                                //成功时执行
                                // console.log()
                                this.uploadImgToQiniu(rst.file)
                            }).catch(function(error) {
                                this.$toast(error)
                                // console.log(error)
                                //失败时执行
                            }).always(function() {
                                //不管成功或失败，都会执行
                            })
                        // this.$toast("请选择小于2M的图片")
                    }else{
                        // console.log('ky')
                        this.uploadImgToQiniu(files[0])
                    }

                })
            
           

        },
        

        // base64 前面替换
        urlReplace(url){
            
            return url.replace("data:image/png;base64,","").replace("data:image/jpeg;base64,","")
        },
    }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss" >
.upload-img{
    position: relative; background: #f4f4f4; text-align: center; padding: 20px 0; border-top: 1px solid #ccc; border-bottom: 1px solid #ccc;
    img { position: absolute; left:0; top: 0; width:100%; height:100%;z-index: 4; }
    i{ font-size: 24px; font-weight: bold;}
    label { position: absolute;z-index: 5; width: 100%; height: 100%;left: 0; top: 0; }
    .upload{display: none;}
}
</style>
