<template>
    <van-row class="cnav" id="nav-yx" type="flex">
        <van-col span="6"><router-link to="/index" active-class="act"><i class="iconfont icon-shouye-"></i>首页</router-link></van-col>
        <van-col span="6"><router-link to="/information" active-class="act"><i class="iconfont icon-xiaoxi-"></i>消息</router-link></van-col>
        <van-col span="6"><router-link to="/mytask" active-class="act"><i class="iconfont icon-renwu3"></i>我的任务</router-link></van-col>
        <van-col span="6"><router-link to="/usercenter" active-class="act"><i class="iconfont icon-wode-"></i>我的</router-link></van-col>
    </van-row>
</template>

<script>
export default {
  name: 'cnav',
  data () {
    return {
      // msg: 'Welcome to Your Vue.js App'
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss" scoped>
.cnav {
    position: fixed;z-index: 99; bottom: 0; width: 100%;height: 48px; border-top: 1px solid #ccc; text-align: center; line-height: 1; font-size: $fon_size_minimum; color: #333; background: #fff;
    .act { color: $body_color; }
    i { display: block; font-size: 24px;margin: 4px 0 2px;}
}
</style>
