<template>
    <div class="topbar">
        <i  class="iconfont  icon-iconfont-edu11" @click="goBack"></i>
        <em  class="tis"><i class="iconfont  icon-jinggao"></i>警示声明</em>
       
        <router-link tag="i" class="i-rgt" to="/">我的任务</router-link>
        
    </div>
</template>

<script>
export default {
    name: 'topbar',
    props:{
        title:{
            type:String,
            default:'米多多'
        }
    },
    data () {
        return {
          // msg: 'Welcome to Your Vue.js App'
        }
    },
    methods:{

        goBack(){
            // console.log('b')
            this.$router.go(-1)
        }
    }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss" scoped>
.topbar{ 
    position: relative; z-index: 99; width: 100%; background: #fff; color: #f66364;  height: 38px; border-bottom: 1px solid #ccc;line-height: 38px;
    i{ 
        position: absolute; width: 34px; height: 100%; text-align: center; font-size: 18px;
        &.i-rgt{ left:auto; right: 10px; font-size: 10px; width: auto; }
    }
    h3{
        text-align: center; margin: 0 46px; overflow: hidden;text-overflow: ellipsis;white-space: nowrap;  font-size: $fon_size_normal; line-height: 42px;
    }
    .tis {
        i{left:0; width:12px; font-size: 12px;}
        position: absolute; left: 34px; top: 0; padding-left: 15px; font-size: 12px;
    }
}
</style>
