<template>
    <div class="list-mission">

            <van-row v-for="item in listInfo" :key="item.id"  type="flex" justify="center" align="center">
                <van-col span="3"><i class="icon"  :style="'background-image:url('+item.icon+')'"></i></van-col>
                <van-col span="17">
                    <h3>
                        <span>{{item.title}}</span>
                    </h3>
                    <p>
                        <span>编号：{{item.id}}</span>
                        剩余单数：{{item.residue_count}}
                    </p>
                    <p>
                        单价：{{item.price}}元
                    </p>
                </van-col>
                <van-col span="4">
                    <router-link :to="'/taskdetails/' +item.id" tag="i" class="btn-list">查看</router-link>
                </van-col>
            </van-row>
    </div>
    
</template>

<script>
export default {
  name: 'listmission',
  props:{
    listInfo:{
        type:Array,
        default:null
    }
  },
  data () {
    return {
        // publishStateName:["待审核","未通过","进行中","已完成"]
      // msg: 'Welcome to Your Vue.js App'
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss" scoped>
    .list-mission {
        background: #fff;
        .van-row { 
            padding: 8px 10px; border-bottom: 1px solid #ccc;
            h3 {
                font-size: 12px; color: #666;
            }
            p {
                color: #999; font-size: $fon_size_minimum; line-height:16px; overflow: hidden;
                span { float: left; display: block; margin-right: 5px; width:102px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
            }

            .col-r { color: #f00; text-align: right; }
        }
        // .icon { width: 44px; height: 44px; display: block; background: blue; color: #fff; line-height: 44px; text-align: center; border-radius:50% }

        .icon { 
            display: block; width:26px; height:26px; background-size: 100%100%;
            &.icon_gj {background-image: url('../common/images/renwu_logo_8.png');}
            &.icon_gz {background-image: url('../common/images/renwu_logo_12.png');}
        }

        .btn-list{    display: block; border: 1Px solid #e1e1e1;  text-align: center; border-radius:3px; font-size: 12px; color: #ff8a00; line-height:25px;  }
    }
</style>
