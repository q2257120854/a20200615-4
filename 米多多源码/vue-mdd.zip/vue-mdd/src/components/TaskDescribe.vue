<template>
    <div class="task-describe">
        <van-row  >
            <van-col class="bt" span="5">标<span class="perch">空格</span>题:</van-col>
            <van-col span="19">{{taskDescribe.title}}</van-col>
        </van-row>
        <van-row  >
            <van-col class="bt" span="5">发 布 方:</van-col>
            <van-col span="19">
                <router-link tag="a" class="link-shop" to="" ><!-- <img src="" alt=""> --> <span>{{taskDescribe.nickname}}</span></router-link>
                <FollowBtn :follow-info="{is_follow:taskDescribe.is_follow,uid:taskDescribe.uid}" v-on:follow-state="sendFollowState" />
                <!-- <i class="btn on" v-if="taskDescribe.is_follow" @click="cancelFollow(taskDescribe.uid)">已关注</i>
                <i class="btn" v-else @click="onFollow(taskDescribe.uid)">+关注</i> -->
                <router-link tag="a" class="btn" :to="{path:'/shop',query:{uid:taskDescribe.uid}}" >店铺</router-link>
            </van-col>
        </van-row>
        <van-row  >
            <van-col class="bt" span="5">编<span class="perch">空格</span>号:</van-col>
            <van-col span="7">{{taskDescribe.id}}</van-col>
            <van-col class="bt" span="5">类<span class="perch">空格</span>别:</van-col>
            <van-col span="7">{{taskDescribe.type_name}}</van-col>
        </van-row>
        <van-row v-if="taskDescribe.type_name == '长单'" >
            <van-col class="bt" span="5">接单限时:</van-col>
            <van-col span="7">{{taskDescribe.order_time_limit}}分钟</van-col>
            <van-col class="bt" span="5">审核限时:</van-col>
            <van-col span="7">{{taskDescribe.check_time_limit}}小时</van-col>
        </van-row>
        <van-row  >
            <van-col class="bt" span="5">单<span class="perch">空格</span>价:</van-col>
            <van-col span="19">{{taskDescribe.price}}元</van-col>
        </van-row>
        <van-row  v-show="taskDescribe.url" >
            <van-col class="bt" span="5">链<span class="perch">空格</span>接:</van-col>
            <van-col span="19"><a class="link" :href="taskDescribe.url">{{taskDescribe.url}}</a><span class="copy" v-clipboard:copy="taskDescribe.url" v-clipboard:success="onCopy" v-clipboard:error="onError">复制</span></van-col>
        </van-row>
        <van-row v-show="taskDescribe.word_verify" >
            <van-col class="bt" span="5">文字验证:</van-col>
            <van-col span="19">{{taskDescribe.word_verify}} </van-col>
        </van-row>
        <van-row  v-show="taskDescribe.remark">
            <van-col class="bt" span="5">备<span class="perch">空格</span>注:</van-col>
            <van-col span="19">{{taskDescribe.remark}}</van-col>
        </van-row>
        <van-row  v-show="taskDescribe.top_expire_time" >
            <van-col class="bt" span="5">置顶到期:</van-col>
            <van-col span="19">{{taskDescribe.top_expire_time}}</van-col>
        </van-row>
        <van-row  >
            <van-col class="bt" span="5">截止日期:</van-col>
            <van-col span="19">{{taskDescribe.end_time}}</van-col>
        </van-row>
    </div>
</template>

<script>
import FollowBtn from '@/components/FollowBtn'
export default {
    name: 'taskdescribe',
    components:{
        FollowBtn
    },
    props:{
        taskDescribe:{
            type:Object,
            default:null
        },
    },
    data () {
        return {
            headInfo:{
                url:'www',
            }
            // msg: 'Welcome to Your Vue.js App'
        }
    },
    methods: { 
        onCopy: function (e) { 
            // console.log('你刚刚复制: ' + e.text) 
        }, 
        onError: function (e) { 
            // console.log('无法复制文本！') 
        },
        // 传递关注状态给父组件
        sendFollowState(state){
            // console.log(state)
            this.$emit('follow-state',state)
        },
        // onFollow(uid) {
        //     // console.log(uid)
        //     this.axios.get('/store/follow',{params:{uid:uid}})
        //         .then((response) => {
        //             if(response.data.code == 0){
        //                 this.$emit('followState',true)
        //             }
                    
        //             // console.log(response)                    
        //         })
        // },
        // cancelFollow(uid) {
        //     this.axios.get('/store/cancelfollow',{params:{uid:uid}})
        //         .then((response) => {
        //             if(response.data.code == 0){
        //                 this.$emit('followState',false)
        //             }
        //             // console.log(response)                    
        //         })

        // },
    }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss" scoped>
    .task-describe { 
        font-size: 12; background-color: #fff; padding: 10px; line-height: 22px; color: #999;
        .bt{
            color: #333; 
            .perch{ visibility: hidden; }
        }
        .link-shop {
            display: inline-block; line-height: 22px; vertical-align: middle;
            img{
                display: inline-block;  height: 18px; width:18px; background-color: #ccc; border-radius: 50%;line-height: 22px;
            }
            span{
                display: inline-block; vertical-align: middle; line-height: 22px;
            }
        }
        .btn {
            margin-left: 3px; padding:0 5px; display: inline-block; vertical-align: middle; border: 1Px solid #f66364; line-height:16px; color: #f66364; border-radius:3px;
            &.on { background-color: #f66364; color: #fff;}
        }
        .link { color: #56b1ff; text-decoration: underline; }
        .copy { margin-left: 10px; display: inline-block; background-color: #56b1ff; color: #fff;  padding:0 5px; border-radius:3px; }
    }
</style>
