<template>
    <div class="content" ref="wrapper">
        <slot></slot>
    </div>
</template>
<script>
import BScroll from 'better-scroll'

export default {
    props: {
        probeType: {
            type: Number,
            default: 3
        },
        click: {
            type: Boolean,
            default: true
        },
        listenScroll: {
            type: Boolean,
            default: true
        },
        object: {
            type: Object,
            default: null
        },
        data: {
            type: Array,
            default: null
        },
        string: {
            type: String,
            default: ''
        },
        pullup: {
            type: Boolean,
            default: false
        },
        beforeScroll: {
            type: Boolean,
            default: false
        },
        refreshDelay: {
            type: Number,
            default: 20
        },
        bounce: {
            type: Object,
            default: function (){
                return {
                    top:false,
                    left:false,
                    right:false,
                    bottom:true
                }
            }
        }
    },
    mounted() {
        this.$nextTick(() => {
                setTimeout(() => {
                    this._initScroll()
                }, 120)
            })
        
    },
    methods: {
        _initScroll() {
            if (!this.$refs.wrapper) {
                return
            }
            this.scroll = new BScroll(this.$refs.wrapper, {
                probeType: this.probeType,
                click: this.click,
                bounce:this.bounce
                // eventPassthrough:'horizontal'
            })
            if (this.listenScroll) {
                let me = this
                // pos为位置参数
                this.scroll.on('scroll', (pos) => {
                    me.$emit('scroll', pos)
                })
            }

            if (this.pullup) {
                this.scroll.on('touchEnd', () => {
                    if (this.scroll.y <= (this.scroll.maxScrollY -20 )) {
                        this.$emit('scrollToEnd')
                    }
                })
            }

            if (this.beforeScroll) {
                this.scroll.on('beforeScrollStart', () => {
                    this.$emit('beforeScroll')
                })
            }
        },
        disable() {
            this.scroll && this.scroll.disable()
        },
        enable() {
            this.scroll && this.scroll.enable()
        },
        refresh() {
            // console.log('s')
            
            this.scroll && this.scroll.refresh()
        },
        scrollTo() {
            this.scroll && this.scroll.scrollTo.apply(this.scroll, arguments)
        },
        scrollToElement() {
            this.scroll && this.scroll.scrollToElement.apply(this.scroll, arguments)
        }
    },
    updated () {
        //解决better-scroll因为图片没有下载完导致的滚动条高度不够，无法浏览全部内容的问题。
        //原因是better-scroll初始化是在dom加载后执行，此时图片没有下载完成，导致滚动条高度计算不准确。
        //利用图片的complete属性进行判断，当所有图片下载完成后再对scroll重新计算。
        let img = document.getElementsByClassName('content')[0].getElementsByTagName('img')
        let count = 0
        let length = img.length
        if (length) {
            // console.log(123)
            let timer = setInterval(() => {
                if (count == length) {
                    // console.log(count)
                    this.scroll.refresh()
                    clearInterval(timer)
                } else if (img[count].complete) {
                    count ++
                }
            }, 100)
        }
        
    },
    watch: {
        data() {
            // console.log(1)
            setTimeout(() => {
                this.refresh()
            }, this.refreshDelay)
        },
        string() {
            // console.log(2)
            setTimeout(() => {
                this.refresh()
            }, this.refreshDelay)
        },
        object() {
            // console.log(3)
            setTimeout(() => {
                this.refresh()
            }, this.refreshDelay)
        }
    }
}

</script>
<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss" scoped>
</style>
