<template>
    <div class="topbar">
        <slot name="lft">
        <i tag="i" class="iconfont  icon-iconfont-edu11" @click="goBack"></i>
        </slot>
        <slot name="content"></slot>
        <slot name="rgt"></slot>
        <h3 v-if="title != ''">{{title}}</h3>
    </div>
</template>

<script>
export default {
    name: 'topbar',
    props:{
        title:{
            type:String,
            default:'米多多'
        }
    },
    data () {
        return {
          // msg: 'Welcome to Your Vue.js App'
        }
    },
    methods:{
        goBack(){
            // console.log('a')
            this.$router.go(-1)
        }
    }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss" scoped>
.topbar{ 
    position: relative; z-index: 99; width: 100%; background: #fff; color: $body_color;  height: 38px; border-bottom: 1px solid #ccc;line-height: 38px;
    i{ 
        position: absolute; width: 44px; height: 100%; text-align: center; font-size: 18px;
        &.i-rgt{ right: 0;font-size: 20px;}
    }
    h3{
        text-align: center; margin: 0 46px; overflow: hidden;text-overflow: ellipsis;white-space: nowrap;  font-size: $fon_size_normal; line-height: 38px;
    }
}
</style>
