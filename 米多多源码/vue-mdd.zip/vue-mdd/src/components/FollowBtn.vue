<template>
<!--     <span class="follow-btn">
        <i class="btn on" v-if="followInfo.is_follow" @click="cancelFollow(followInfo.uid)">已关注</i>
        <i class="btn" v-else @click="onFollow(followInfo.uid)">+关注</i>
    </span> -->

    <i class="btn " :class="{on:followInfo.is_follow}" @click="changeFollow">{{ followInfo.is_follow | filterFollow}}</i>
</template>

<script>
export default {
    name: 'FollowBtn',
    props:{
        followInfo:{
            type:Object,
            default:() =>{
                return {
                    is_follow:false,
                    uid:null
                }
            }
        }
    },
    data () {
        return {
          // msg: 'Welcome to Your Vue.js App'
        }
    },
    filters:{
        filterFollow(item) {
            return item?'已关注':'+关注';
        }
    },
    methods:{
        changeFollow(){
            let api 
            if(this.followInfo.is_follow){

                api = '/store/cancelfollow'
            }else{
                api = '/store/follow'
            }
            this.axios.get(api,{params:{uid:this.followInfo.uid}})
                .then(response => {
                    if(response.data.code == 0){

                        this.$emit('follow-state',!this.followInfo.is_follow)
                    // console.log('b1')
                    }else{
                        this.$toast(response.data.msg)
                    }
                })
        },
    }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss" scoped>
    // .follow-btn{
    // }
    .btn {
        margin-left: 3px; padding:0 5px; display: inline-block; vertical-align: middle; border: 1Px solid #f66364; line-height:16px; color: #f66364; border-radius:3px;
        &.on { background-color: #f66364; color: #fff;}
    }

</style>
