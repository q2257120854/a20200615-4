<template>

    <ul class="my-member">
        <router-link tag="li"  v-for="item in listInfo" :to="{path:'/shop',query:{uid:item.id}}" :key="item.id" >
            <img :src="item.head_img" alt="">
            <i>{{item.nickname}}</i>
            <span>{{item.reg_time || item.follow_time}}</span>
        </router-link>

    </ul>
    
</template>

<script>
export default {
  name: 'listmember',
  props:{
    listInfo:{
        type:Array,
        default:null
    },
    // param:{
    //     type:String,
    //     default:'price'

    // }
  },
  data () {
    return {
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss" scoped>

.my-member {
    li {
        padding: 10px; padding-left: 54px; position: relative; overflow: hidden; height:34px; line-height:34px; border-bottom: 1Px solid #d9d9d9;
        img { position: absolute; left: 10px; width: 34px; height:34px; border-radius:50%; }
        i { float: left;   text-overflow: ellipsis; overflow: hidden; white-space: nowrap; width:50%; font-size: 13px; color: #000;}
        span { float: right; color: #656565; }
    }
}
</style>
