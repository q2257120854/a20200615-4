<template>
    <div class="list-publish">
        <ul>
            <router-link v-for="(item,idx) in listInfo" :key="idx" tag="li"   :to="{path: '/taskdetails', query: { task_id: item.id }}">
                <div class="hd">
                    {{item.type_name}}<span>{{item.id}} <i>{{item.title}}</i></span>
                </div>
                <div class="bd">
                    <span>单&nbsp;&nbsp;&nbsp;价：{{item.price}}元</span>
                    <span>总&nbsp;&nbsp;&nbsp;量：{{item.total_count}}</span>
                    <span>未完成：{{item.unsubmit_count}}</span>
                    <span>剩&nbsp;&nbsp;&nbsp;余：{{getResidue(item.total_count,item.finish_count)}}</span>
                    <span>已完成：{{item.finish_count}}</span>
                    <span>待审核：{{item.submit_count}}</span>
                </div>
                
                <!-- 状态:1=待审核,2=未通过,3=进行中,4=已暂停,5=已结束 -->
                <!-- 刚发布任务，等待平台审核  @click="delTask()" 1 -->
                <div v-if="item.state == 1 " class="ft-btn">
                    <i class="delete" @click.stop="delTask(item)" >删&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;除</i>
                    <i class="no">待&nbsp;审&nbsp;核</i>
                </div>

                <!-- 未通过审核的任务   2 -->
                <div v-else-if="item.state == 2 " class="ft-btn">
                    <i class="delete" @click.stop="delTask(item)">删&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;除</i>
                    <i class="delete">修&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;改</i>
                    <i class="no">审核失败</i>
                    <p>失败原因:验证图请上传要求用户提供的例图</p>
                </div>
                
                <!-- 进行中的任务 3-->
                <div v-else-if="item.state == 3 " class="ft-btn">
                    <router-link tag="i" to="/taskaudit"  class="send" >审&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;核</router-link>
                    <i class="send" @click.stop="addCount(item)">追加数量</i>
                    <i class="send" @click.stop="addPrice(item)">上调价格</i>
                    <i class="send" @click.stop="pauseTask(item)">暂&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;停</i>
                    <i class="send">下&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;架</i>
                    <i class="send">刷&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;新</i>
                    <i class="send">推&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;荐</i>
                    <i class="send" @click.stop="popupStick = true">置&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;顶</i>
                </div>

                <!-- 暂停中的任务 4 -->
                <div v-else-if="item.state == 4 " class="ft-btn">
                    <i class="send">审&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;核</i>
                    <i class="send">追加数量</i>
                    <i class="send">上调价格</i>
                    <i class="send">开&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;启</i>
                    <i class="send">下&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;架</i>
                </div>

                <!--  结束的任务  5-->                
                <div v-else="item.state == 5 " class="ft-btn">
                    <i class="delete" @click.stop="delTask(item)" >删&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;除</i>
                    <i class="delete">重发任务</i>
                    <i class="no">已&nbsp;结&nbsp;束</i>
                </div>

                <div class="time">
                    <div class="lft">发布：{{item.add_time}}</div>
                    <div class="rgt">截止：{{item.end_time}}</div>
                </div>
            </router-link>

        </ul>
    </div>
    
</template>

<script>
export default {
    name: 'listpublish',
    props:{
        listInfo:{
            type:Array,
            default:null
        },
    // param:{
    //     type:String,
    //     default:'price'

    // }
    },
    data () {
        return {
            stickTime:'',
            // taskStateName:["待提交","审核中","不合格","已完成"],
            // publishStateName:["待审核","未通过","进行中","已完成"]
          // msg: 'Welcome to Your Vue.js App'
        }
    },
    methods: {
        // 计算未完成任务
        getResidue(total_count,finish_count){
            return total_count - finish_count
        },
        // 删除任务
        delTask(obj){
            // console.log(obj.id)
            this.$dialog.confirm({
                title: '注意',
                message: '确认要删除任务吗？'
            }).then(() => {
                // on confirm
                this.axios.get('/task/delete',{params:{'task_id':obj.id}})
                    .then((response) => {
                        // console.log('123')
                    })
            }).catch(() => {
              // on cancel
            })
        },
        // 暂停任务
        pauseTask(obj){

            this.$dialog.confirm({
                title: '注意',
                message: '确认要暂停任务吗？'
            }).then(() => {
                // on confirm
                // console.log(obj.id)
                this.axios.get('/task/pause',{params:{'task_id':obj.id}})
                    .then((response) => {
                        // console.log(response)
                    })
            }).catch(() => {
              // on cancel
            })
        },
        // 追加数量
        addCount(id){
            this.popupCount.countShow = true
            // this.$dialog.confirm({
            //     title: '注意',
            //     message: '确认要暂停任务吗？'
            // }).then(() => {
            //     // on confirm
            //     console.log(obj.id)
            //     this.axios.get('/task/pause',{params:{'task_id':obj.id}})
            //         .then((response) => {
            //             console.log(response)
            //         })
            // }).catch(() => {
            //   // on cancel
            // })
        },
        // 上调价格
        addPrice(id){

        },
    }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss" scoped>
    .list-publish {
        background: #fff;
        li {
            min-height: 90px; color: #666; padding: 10px 2%; border-bottom: 1Px solid #f2f2f2; line-height: 1.5;
            .hd { 
                font-size: 14px; color: #222; 
                span { 
                    font-size: 12px; margin-left: 5px; color: #999; 
                    i { color: #666; }
                } 
            }
            .bd { overflow: hidden;
                span { display: block; float: left; width: 33%; color: #999; }
            }
            .ft-btn {
                overflow: hidden;
                i { 
                    display: block; float: left; width: 60px;  text-align: center; line-height: 20px; border-radius: 4px; margin:5px 10px 5px 0; border: 1Px solid #dedede; 
                    &.send { color: #56b1ff; }
                    &.delete { color: #f66364; }
                    &.no { color: #555; background-color: #f1f1f1; }
                }
            }
            .time { overflow: hidden; color: #999; padding-right: 10px; }
        }
    }

    // 弹窗
    .popup_stick {
        width: 238px; background-color: #f66364; border-radius:6px; color: #fff; line-height:18px;
        .hd { 
            text-align: center;
            h3 { font-size: 14px; line-height:38px; }
        }
        .bd {
            padding: 11px 17px 0;
            .van-cell { 
                padding:3px 15px; border-radius: 6px; 
            }
        }
        .row-btn {
            display: flex; justify-content: space-between; padding-top: 15px;
            i{ display: block; width: 49%; background-color: #f88283; color: #fff; text-align: center; line-height:36px;}
        }
        .ft { padding:8px 17px; }
    }
</style>
