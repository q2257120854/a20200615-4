<template>
    <div class="task-describe">
        <van-row  >
            <van-col class="bt" span="5">发 布 方:</van-col>
            <van-col span="7">
                <router-link tag="a" class="link-shop" to="" ><!-- <img src="" alt="">  --><span>{{taskDescribe.nickname}}</span></router-link>
            </van-col>

            <van-col class="bt" span="5">编<span class="perch">空格</span>号:</van-col>
            <van-col span="7">{{taskDescribe.id}}</van-col>
        </van-row>
        <van-row  >
            <van-col class="bt" span="5">类<span class="perch">空格</span>别:</van-col>
            <van-col span="7">{{taskDescribe.type_name}}</van-col>
            <van-col class="bt" span="5">单<span class="perch">空格</span>价:</van-col>
            <van-col span="7">{{taskDescribe.price}}元</van-col>
        </van-row>
        <van-row  v-if="taskDescribe.word_verify != ''" >
            <van-col class="bt" span="5">文字验证:</van-col>
            <van-col span="19">{{taskDescribe.word_verify}} </van-col>
        </van-row>
        <van-row v-if="taskDescribe.remark"  >
            <van-col class="bt" span="5">备<span class="perch">空格</span>注:</van-col>
            <van-col span="19">{{taskDescribe.remark}}</van-col>
        </van-row>
    </div>
</template>

<script>
export default {
    name: 'taskverifydescribe',
    props:{
        taskDescribe:{
            type:Object,
            default:null
        },
    },
    data () {
        return {
            
            // msg: 'Welcome to Your Vue.js App'
        }
    }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss" scoped>
    
// 任务详情 文字描述
.task-describe { 
        font-size: 12; background-color: #fff; padding: 10px; line-height: 22px; color: #999;
        .bt{
            color: #333; 
            .perch{ visibility: hidden; }
        }
        .link-shop {
            display: inline-block; line-height: 22px; vertical-align: middle;
            img{
                display: inline-block;  height: 18px; width:18px; background-color: #ccc; border-radius: 50%;line-height: 22px;
            }
            span{
                display: inline-block; vertical-align: middle; line-height: 22px;
            }
        }
        .btn {
            margin-left: 3px; padding:0 5px; display: inline-block; vertical-align: middle; border: 1Px solid #f66364; line-height:16px; color: #f66364; border-radius:3px;
        }
    }
</style>
