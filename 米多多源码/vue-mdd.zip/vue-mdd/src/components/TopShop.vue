<template>
    <div class="rowtop"><i class="img_zd"></i>
        <van-swipe :autoplay="3000" :showIndicators="false" >
            <van-swipe-item v-for="(items,index) in topList" :key="index">
                <van-row>
                    <van-col span="4" v-for="item in items" :key='item.id'>
                        <router-link  :to="{path:'/shop',query:{uid:item.id}}">
                            <img class="img_top" src="@/common/images/zhiding_photo_top.png" alt="">
                            <img :src="item.head_img" alt="">
                            <p>{{item.nickname}}</p>
                        </router-link>
                    </van-col>
                </van-row>
            </van-swipe-item>
            <!-- <van-swipe-item>2</van-swipe-item> -->
        </van-swipe>
    </div>
</template>

<script>
export default {
    name: 'rowtop',
    props:{
        title:{
            type:String,
            default:'米多多'
        }
    },
    data () {
        return {
          // msg: 'Welcome to Your Vue.js App'
          topList:[]
        }
    },
    created(){
        this.axios.get('/store/toplist')
            .then(response => {
                let data = response.data.data
                for( let i =0; i< data.length; i+=6){
                    this.topList.push(data.slice(i,i+6));
                }
                // console.log(this.topList)
            })
    }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss" scoped>
.rowtop {
    position: relative; padding:0 10px 0 24px; background:#40b6ff; height:48px;
    .img_zd {
        position: absolute;left:0; top:0; display: block; width:24px; height:100%; background:url('../common/images/store_icon.png') no-repeat center center; background-size: 100% auto;
    }
}
.rowtop .van-col {
    position: relative; padding:5px 0 2px; 
    img.img_top { position: absolute; width:20px; height:6px; left:50%; margin-top: -2px; margin-left: -10px; }
    img{
        display: block; margin: 0 auto;  background:#ccc; width: 25px; height:25px; border-radius:50%;
    }
    p { overflow: hidden; white-space: nowrap; text-overflow: ellipsis; color: #fff; font-size: 10px;text-align: center; line-height: 16px; }
}
</style>
