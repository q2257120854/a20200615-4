<template>
    <button :disabled="disabled || time>0">{{time | change}}</button>
</template>
 
<script>
let flag = false
    export default {
        data () {
            return {
                time : '发送',
                disabled:false
            }
        },
        props : {
            start : {
                type : Boolean
            }
        },
        watch : {
            start (value,oldvalue) {
                if(value == true){
                    this.countDown()
                }
            }
        },
        methods: {
            countDown () {
                this.time = 60;
                let time = setInterval(()=>{
                    this.time --
                    if(this.time == 0){
                        this.$emit('countDown')
                        this.time = '获取验证码'
                        flag = true
                        clearInterval(time)
                    }
                },1000)
            }
        },
        filters : {
            change (value) {
               if(!value) return ""
               if(!isNaN(value)){
                   if(flag == true){
                       return `${value}秒`
                   }
                   return value+'秒'
               }else{
                   return value
               }
            }
        }
 
    }
</script>
