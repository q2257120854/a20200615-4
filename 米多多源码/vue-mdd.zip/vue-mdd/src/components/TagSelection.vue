<template>
    <div class="tag-slection" :class="{'tag-slection-white' : tagStyle == true}">
        <span :class="{act:act == '' }" @click="actClick('')">全 部</span>
        <span v-for="(tag,index) in Tags" :class="{act:act==tag.id }" @click="actClick(tag.id)">{{tag.name}}</span>
    </div>
</template>

<script>
export default {
    name: 'tagSlection',
    props:{
        Tags:{
            type:Array,
            default:null
        },
        tagStyle:{
            type:Boolean,
            default:false
        }
    },
    data () {
        return {
            act:''
          // msg: 'Welcome to Your Vue.js App'
        }
    },
    methods:{
        actClick(e) {
            this.act = e;
            // console.log(this.act)
            this.$emit('changeType',this.act)
        }
    }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss" scoped>
.tag-slection{
    padding: 5px 15px 5px; overflow: hidden;
    span { 
        float: left; display: block; width: 17%; margin: 3px 1.5%;  box-sizing: border-box; background: #fff; text-align: center;  border-radius:5px;  font-size: 10px; line-height: 2;
        &.act { background: #5eb0fa; color: #fff; }
    }
}
.tag-slection-white{
    padding: 5px 8px 5px; overflow: hidden; background:white;
    span { 
        float: left; display: block; width: 17%; margin: 2px 1.5%;  box-sizing: border-box; background: #fff; text-align: center;  border-radius:5px;  font-size: 10px; line-height: 2; border: 1Px solid #5eb0fa;  color: #5eb0fa;
        &.act { background: #5eb0fa; color: #fff; }
    }
}
</style>
