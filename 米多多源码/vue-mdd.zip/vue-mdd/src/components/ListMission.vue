<template>
    <div class="list-mission">
        <router-link v-for="(item,index) in listInfo" :key="index"  :to="'/taskdetails/' + item.id ">
            
            <van-row   type="flex" justify="center" align="center">
                <!-- <van-col span="3"><i class="icon icon_gz" ></i></van-col> -->
                <van-col span="3"><i class="icon " :style="'background-image:url('+item.icon+')'" ></i></van-col>
                <van-col span="17">
                    <h3>
                        {{item.task_type}}
                        <span>{{item.title}}</span>
                    </h3>
                    <p>
                        <span>任务编号：{{item.id}} </span>
                        单价：{{item.price}}元
                    </p>
                </van-col>
                <!-- 待提交 -->
                <van-col span="4" v-if="item.state == 1">
                    <router-link tag="i" :to="{path:'/taskverify',query:{task_id:item.id}}"  class="btn-list">上传验证</router-link>
                </van-col>

                <!-- 审核中 -->
                <van-col span="4" v-else-if="item.state == 2">
                    <i class="btn-list " @click.prevent.self >审核中</i>             
                </van-col>

                <!-- 不合格 -->
                <van-col span="4" v-else-if="item.state == 3">
                    <router-link tag="i" :to="{path:'/taskfail',query:{task_id:item.id}}"  class="btn-list">查看原因</router-link>
                    <i class="btn-list" @click.prevent="myTaskDel(item.id,index)">刪除</i>
                </van-col>
                

                <!-- 已完成 -->
                <van-col span="4" v-else>
                    <i class="btn-list " @click.prevent.self >合格</i>
                    <i class="btn-list " @click.prevent="myTaskDel(item.id,index)">删除</i>
                </van-col>
            </van-row>
        </router-link>
    </div>
    
</template>

<script>
export default {
    name: 'listmission',
    props:{
        listInfo:{
            type:Array,
            default:null
        },
        param:{
            type:String,
            default:'price'
        }
    },
    data () {
        return {
            taskStateName:["待提交","审核中","不合格","已完成"],
            // publishStateName:["待审核","未通过","进行中","已完成"]
          // msg: 'Welcome to Your Vue.js App'
        }
    },
    methods:{
        // 删除我的任务
        myTaskDel(id,idx){
            // console.log(id)
            this.$dialog.confirm({
                title: '注意',
                message: '确认要删除任务吗？'
            }).then(() => {
                // on confirm
                this.axios.get('/task/deletemy',{params:{task_id:id}})
                    .then((response) => {
                        // console.log(response)
                        if(response.data.code == 0){
                            this.listInfo.splice(idx,1)
                        }
                    })
            }).catch(() => {
              // on cancel
            })
        },
    }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss" scoped>
    .list-mission {
        background: #fff;
        .van-row { 
            padding: 8px 10px; border-bottom: 1px solid #ccc;
            h3 {
                color: #333; font-size: $fon_size_small; line-height:17px;
                span { margin-left: 5px; font-size: 12px; color: #666; }
            }
            p {
                color: #999; font-size: $fon_size_minimum; line-height:16px; overflow: hidden;
                span { float: left; display: block; margin-right: 5px; width:102px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
            }

            .col-r { color: #f00; text-align: right; }
        }
        // .icon { width: 44px; height: 44px; display: block; background: blue; color: #fff; line-height: 44px; text-align: center; border-radius:50% }

        .icon { 
            display: block; width:26px; height:26px; background-size: 100%100%;
            &.icon_gj {background-image: url('../common/images/renwu_logo_8.png');}
            &.icon_gz {background-image: url('../common/images/renwu_logo_12.png');}
        }

        .btn-list{  margin-bottom: 4px;  display: block; border: 1Px solid #e1e1e1;  text-align: center; border-radius:3px; font-size: 10px; color: #ff8a00; line-height:24px; 
            &.no {background-color: #f1f1f1; }
        }
        .btn-list:last-child{ margin-bottom: 0; }
    }
</style>
