-- MySQL dump 10.13  Distrib 5.7.26, for Linux (x86_64)
--
-- Host: localhost    Database: mdd
-- ------------------------------------------------------
-- Server version	5.7.26-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `mdd_account_detail`
--

DROP TABLE IF EXISTS `mdd_account_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mdd_account_detail` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '账户明细编号',
  `uid` bigint(20) DEFAULT NULL COMMENT '用户编号',
  `op` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '操作',
  `money` float(8,2) DEFAULT NULL COMMENT '金额',
  `add_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  PRIMARY KEY (`id`),
  KEY `FK_Reference_8` (`uid`),
  CONSTRAINT `FK_Reference_8` FOREIGN KEY (`uid`) REFERENCES `mdd_user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11095 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='账户明细';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mdd_account_detail`
--

LOCK TABLES `mdd_account_detail` WRITE;
/*!40000 ALTER TABLE `mdd_account_detail` DISABLE KEYS */;
INSERT INTO `mdd_account_detail` VALUES (11040,10060,'任务获得-噢噢噢',1.00,'2019-06-18 09:49:47'),(11081,10060,'发布任务-测试手段方式',-12.00,'2019-10-02 08:43:22'),(11082,10060,'追加数量-测试手段方式',-4.80,'2019-10-02 11:25:47'),(11083,10060,'追加数量-测试手段方式',-4.80,'2019-10-02 11:25:51'),(11084,10060,'发布任务-测算电费s\'d\'f',-110.00,'2019-10-02 11:27:58'),(11085,10067,'任务获得-测试手段方式',0.50,'2019-10-04 05:21:00'),(11086,10060,'一级佣金-测试手段方式',0.05,'2019-10-04 05:21:00'),(11087,10060,'任务退回-测算电费s\'d\'f',110.00,'2019-10-07 05:33:39'),(11088,10060,'发布任务-测试001',-11.00,'2019-10-15 15:11:02'),(11089,10067,'发布任务-1111',-11.00,'2019-10-16 12:17:15'),(11090,10067,'任务退回-1111',10.00,'2019-10-18 12:17:00'),(11091,10060,'充值奖励-',0.01,'2019-10-20 15:11:34'),(11092,10067,'米币充值',1.00,'2019-10-20 15:11:34'),(11093,10060,'米币充值',1.00,'2019-10-20 15:13:33'),(11094,10060,'发布任务-打字员一天80元',-1760.00,'2019-10-28 07:17:35');
/*!40000 ALTER TABLE `mdd_account_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mdd_appeal`
--

DROP TABLE IF EXISTS `mdd_appeal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mdd_appeal` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '编号',
  `uid` bigint(20) DEFAULT NULL COMMENT '用户编号',
  `task_id` bigint(20) DEFAULT NULL COMMENT '申诉的任务编号',
  `content` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '申诉内容',
  `add_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `is_solve` int(11) DEFAULT '0' COMMENT '是否解决',
  PRIMARY KEY (`id`),
  KEY `FK_Reference_17` (`uid`),
  KEY `FK_Reference_18` (`task_id`),
  CONSTRAINT `FK_Reference_17` FOREIGN KEY (`uid`) REFERENCES `mdd_user` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_Reference_18` FOREIGN KEY (`task_id`) REFERENCES `mdd_task` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='申诉';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mdd_appeal`
--

LOCK TABLES `mdd_appeal` WRITE;
/*!40000 ALTER TABLE `mdd_appeal` DISABLE KEYS */;
/*!40000 ALTER TABLE `mdd_appeal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mdd_banner`
--

DROP TABLE IF EXISTS `mdd_banner`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mdd_banner` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '轮播图编号',
  `img` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '图片',
  `url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '链接',
  `sort` int(11) DEFAULT NULL COMMENT '排序',
  `is_enable` tinyint(4) DEFAULT NULL COMMENT '是否启用:0=关闭,1=启用',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='轮播图';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mdd_banner`
--

LOCK TABLES `mdd_banner` WRITE;
/*!40000 ALTER TABLE `mdd_banner` DISABLE KEYS */;
INSERT INTO `mdd_banner` VALUES (5,'http://qiniuyun.shanhaijuhe.com/Fo6MMh6klC3HH4acmGTgVGQCIjNy','211',2,1),(6,'http://qiniuyun.shanhaijuhe.com/FnOEMMsjM5dtc22IJgLJRYnvHOwC','',1,1);
/*!40000 ALTER TABLE `mdd_banner` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mdd_chat`
--

DROP TABLE IF EXISTS `mdd_chat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mdd_chat` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '编号',
  `mytask_id` bigint(20) NOT NULL COMMENT '我的任务编号',
  `direction` int(11) DEFAULT NULL COMMENT '留言方向:0=商家留言,1=用户留言',
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '留言时间',
  `content` char(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '留言内容',
  `image_list` text COLLATE utf8mb4_unicode_ci COMMENT '附加图片列表',
  PRIMARY KEY (`id`),
  KEY `FK_Reference_14` (`mytask_id`),
  CONSTRAINT `FK_Reference_14` FOREIGN KEY (`mytask_id`) REFERENCES `mdd_my_task` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='信息交流';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mdd_chat`
--

LOCK TABLES `mdd_chat` WRITE;
/*!40000 ALTER TABLE `mdd_chat` DISABLE KEYS */;
/*!40000 ALTER TABLE `mdd_chat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mdd_complain`
--

DROP TABLE IF EXISTS `mdd_complain`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mdd_complain` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '编号',
  `task_id` bigint(20) DEFAULT NULL COMMENT '任务编号',
  `uid` bigint(20) DEFAULT NULL COMMENT '投诉的用户编号',
  `content` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '投诉内容',
  `add_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  PRIMARY KEY (`id`),
  KEY `FK_Reference_15` (`task_id`),
  KEY `FK_Reference_16` (`uid`),
  CONSTRAINT `FK_Reference_15` FOREIGN KEY (`task_id`) REFERENCES `mdd_task` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_Reference_16` FOREIGN KEY (`uid`) REFERENCES `mdd_user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='投诉';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mdd_complain`
--

LOCK TABLES `mdd_complain` WRITE;
/*!40000 ALTER TABLE `mdd_complain` DISABLE KEYS */;
/*!40000 ALTER TABLE `mdd_complain` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mdd_config`
--

DROP TABLE IF EXISTS `mdd_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mdd_config` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '配置编号',
  `mc_key` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '键',
  `mc_value` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '值',
  `mc_desc` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '说明',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='配置';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mdd_config`
--

LOCK TABLES `mdd_config` WRITE;
/*!40000 ALTER TABLE `mdd_config` DISABLE KEYS */;
INSERT INTO `mdd_config` VALUES (1,'cycle1','30','小时，店铺置顶周期价格30元/时'),(4,'cycle2','12','天，店铺置顶周期价格12元/时'),(5,'cycle3','9.45','周，店铺置顶周期价格9.45元/时'),(6,'cycle4','6.78','月，店铺置顶周期价格6.78元/时'),(7,'task_top_hour_price','15','置顶任务价格1小时15元'),(8,'commission1','0.1','一级佣金'),(9,'commission2','0.02','队长佣金'),(10,'direct_count','3','直推数量'),(11,'all_count','6','团队数量');
/*!40000 ALTER TABLE `mdd_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mdd_earnest_money_back`
--

DROP TABLE IF EXISTS `mdd_earnest_money_back`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mdd_earnest_money_back` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '编号',
  `uid` bigint(20) DEFAULT NULL COMMENT '用户编号',
  `amount` float DEFAULT NULL COMMENT '申退金额',
  `state` int(11) DEFAULT '0' COMMENT '状态:0=待审核,1=未通过,2=通过',
  `add_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '申请时间',
  PRIMARY KEY (`id`),
  KEY `FK_Reference_21` (`uid`),
  CONSTRAINT `FK_Reference_21` FOREIGN KEY (`uid`) REFERENCES `mdd_user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='申退保证金';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mdd_earnest_money_back`
--

LOCK TABLES `mdd_earnest_money_back` WRITE;
/*!40000 ALTER TABLE `mdd_earnest_money_back` DISABLE KEYS */;
/*!40000 ALTER TABLE `mdd_earnest_money_back` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mdd_follow`
--

DROP TABLE IF EXISTS `mdd_follow`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mdd_follow` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '编号',
  `uid` bigint(20) DEFAULT NULL COMMENT '用户编号',
  `follow_uid` bigint(20) DEFAULT NULL COMMENT '被关注用户',
  `follow_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '关注时间',
  PRIMARY KEY (`id`),
  KEY `FK_Reference_10` (`follow_uid`),
  KEY `FK_Reference_9` (`uid`),
  CONSTRAINT `FK_Reference_10` FOREIGN KEY (`follow_uid`) REFERENCES `mdd_user` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_Reference_9` FOREIGN KEY (`uid`) REFERENCES `mdd_user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='粉丝关注';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mdd_follow`
--

LOCK TABLES `mdd_follow` WRITE;
/*!40000 ALTER TABLE `mdd_follow` DISABLE KEYS */;
INSERT INTO `mdd_follow` VALUES (3,10060,10067,'2019-10-03 05:21:45');
/*!40000 ALTER TABLE `mdd_follow` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mdd_invite_code`
--

DROP TABLE IF EXISTS `mdd_invite_code`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mdd_invite_code` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '邀请码',
  `is_use` int(11) DEFAULT '0' COMMENT '是否使用:0=未使用,1=已使用',
  `use_time` timestamp NULL DEFAULT NULL COMMENT '使用时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `AK_Key_2` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='邀请码';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mdd_invite_code`
--

LOCK TABLES `mdd_invite_code` WRITE;
/*!40000 ALTER TABLE `mdd_invite_code` DISABLE KEYS */;
INSERT INTO `mdd_invite_code` VALUES (6,'534916',1,'2019-10-03 05:18:32'),(7,'056449',1,'2019-06-18 08:29:49'),(8,'884589',1,'2019-06-18 08:36:40'),(9,'265997',1,'2019-06-18 09:31:11'),(10,'320813',1,'2019-07-25 07:33:43'),(11,'153723',1,'2019-06-19 07:25:09'),(12,'219455',1,'2019-08-05 15:33:02'),(13,'996795',0,NULL),(14,'162359',0,NULL);
/*!40000 ALTER TABLE `mdd_invite_code` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mdd_message`
--

DROP TABLE IF EXISTS `mdd_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mdd_message` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '编号',
  `uid` bigint(20) DEFAULT NULL COMMENT '用户编号',
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '标题',
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '时间',
  `content` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '内容',
  PRIMARY KEY (`id`),
  KEY `FK_Reference_19` (`uid`),
  CONSTRAINT `FK_Reference_19` FOREIGN KEY (`uid`) REFERENCES `mdd_user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=364 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='消息';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mdd_message`
--

LOCK TABLES `mdd_message` WRITE;
/*!40000 ALTER TABLE `mdd_message` DISABLE KEYS */;
INSERT INTO `mdd_message` VALUES (357,10060,'收入提醒','2019-06-18 09:49:47','亲,您有一笔收入到账!<br/>收入类型:任务噢噢噢获得<br/>收入金额:1.0<br/>劳动换来的果实特别甜,继续加油吧!'),(362,10067,'任务处理通知','2019-10-03 05:19:43','哎呦，你的任务审核未通过，请重新上传验证图吧！<br/>任务名称:测试手段方式<br/>拒绝原因:有问题'),(363,10067,'收入提醒','2019-10-04 05:21:00','亲,您有一笔收入到账!<br/>收入类型:任务测试手段方式获得<br/>收入金额:0.5<br/>劳动换来的果实特别甜,继续加油吧!');
/*!40000 ALTER TABLE `mdd_message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mdd_my_task`
--

DROP TABLE IF EXISTS `mdd_my_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mdd_my_task` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '我的任务编号',
  `uid` bigint(20) DEFAULT NULL COMMENT '用户编号',
  `task_id` bigint(20) DEFAULT NULL COMMENT '任务编号',
  `state` tinyint(4) DEFAULT NULL COMMENT '状态:1=待提交,2=待审核,3=未通过,4=已完成',
  `reject_reason` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '拒绝原因',
  `auth_img` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '验证图',
  `add_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `del_state` tinyint(4) DEFAULT '0' COMMENT '删除状态:0=未删除,1=已删除',
  `word_verify` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '文字验证',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `FK_Reference_3` (`uid`),
  KEY `FK_Reference_4` (`task_id`),
  CONSTRAINT `FK_Reference_3` FOREIGN KEY (`uid`) REFERENCES `mdd_user` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_Reference_4` FOREIGN KEY (`task_id`) REFERENCES `mdd_task` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=93 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='我的任务';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mdd_my_task`
--

LOCK TABLES `mdd_my_task` WRITE;
/*!40000 ALTER TABLE `mdd_my_task` DISABLE KEYS */;
/*!40000 ALTER TABLE `mdd_my_task` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mdd_notice`
--

DROP TABLE IF EXISTS `mdd_notice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mdd_notice` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '公告编号',
  `content` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '内容',
  `add_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `sort` int(11) DEFAULT NULL COMMENT '排序',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='公告';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mdd_notice`
--

LOCK TABLES `mdd_notice` WRITE;
/*!40000 ALTER TABLE `mdd_notice` DISABLE KEYS */;
INSERT INTO `mdd_notice` VALUES (4,'任务区APP内测中！！！','2019-05-29 08:35:44',NULL);
/*!40000 ALTER TABLE `mdd_notice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mdd_report`
--

DROP TABLE IF EXISTS `mdd_report`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mdd_report` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '编号',
  `uid` bigint(20) DEFAULT NULL COMMENT '用户编号',
  `task_id` bigint(20) DEFAULT NULL COMMENT '举报的任务编号',
  `content` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '举报内容',
  `image_list` text COLLATE utf8mb4_unicode_ci COMMENT '图片列表',
  `add_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  PRIMARY KEY (`id`),
  KEY `FK_Reference_12` (`task_id`),
  KEY `FK_Reference_13` (`uid`),
  CONSTRAINT `FK_Reference_12` FOREIGN KEY (`task_id`) REFERENCES `mdd_task` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_Reference_13` FOREIGN KEY (`uid`) REFERENCES `mdd_user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='举报';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mdd_report`
--

LOCK TABLES `mdd_report` WRITE;
/*!40000 ALTER TABLE `mdd_report` DISABLE KEYS */;
/*!40000 ALTER TABLE `mdd_report` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mdd_task`
--

DROP TABLE IF EXISTS `mdd_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mdd_task` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '任务编号',
  `task_type_id` bigint(20) DEFAULT NULL COMMENT '任务类型编号',
  `uid` bigint(20) DEFAULT NULL COMMENT '用户编号',
  `device` tinyint(4) DEFAULT NULL COMMENT '支持设备:0=全部,1=安卓,2=苹果',
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '标题',
  `price` float(8,2) DEFAULT NULL COMMENT '单价',
  `total_count` int(11) DEFAULT '0' COMMENT '总数量',
  `unsubmit_count` int(11) DEFAULT '0' COMMENT '未提交数量',
  `submit_count` int(11) DEFAULT '0' COMMENT '提交数量',
  `fail_count` int(11) DEFAULT '0' COMMENT '不合格数量',
  `finish_count` int(11) DEFAULT '0' COMMENT '已完成数量',
  `service_charge` float(8,2) DEFAULT NULL COMMENT '服务费',
  `end_time` timestamp NULL DEFAULT NULL COMMENT '截止时间',
  `explain_img` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '说明图',
  `url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '链接',
  `word_verify` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '文字验证',
  `remark` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '备注',
  `add_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '发布时间',
  `is_top` tinyint(4) DEFAULT NULL COMMENT '是否置顶',
  `is_hot` tinyint(4) DEFAULT NULL COMMENT '是否推荐',
  `state` tinyint(4) DEFAULT NULL COMMENT '状态:1=待审核,2=未通过,3=进行中,4=已暂停,5=已结束',
  `balance` float(8,2) DEFAULT NULL COMMENT '余额',
  `reject_reason` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '拒绝原因',
  `cancel_time` timestamp NULL DEFAULT NULL COMMENT '下架时间',
  `top_expire_time` timestamp NULL DEFAULT NULL COMMENT '置顶到期时间',
  `del_state` tinyint(4) DEFAULT '0' COMMENT '删除状态:0=未删除,1=已删除',
  `order_time_limit` int(11) DEFAULT '20' COMMENT '接单限时(单位:分钟)',
  `check_time_limit` int(11) DEFAULT '24' COMMENT '审核限时(单位:小时)',
  `pause_count` int(11) DEFAULT '0' COMMENT '暂停次数',
  PRIMARY KEY (`id`),
  KEY `FK_Reference_11` (`uid`),
  KEY `FK_Reference_5` (`task_type_id`),
  CONSTRAINT `FK_Reference_11` FOREIGN KEY (`uid`) REFERENCES `mdd_user` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_Reference_5` FOREIGN KEY (`task_type_id`) REFERENCES `mdd_task_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10179 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='任务';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mdd_task`
--

LOCK TABLES `mdd_task` WRITE;
/*!40000 ALTER TABLE `mdd_task` DISABLE KEYS */;
INSERT INTO `mdd_task` VALUES (10174,12,10060,0,'测试手段方式',0.50,36,0,0,0,0,0.20,'2022-10-02 08:39:00','Fhut8VvFZUs6BZKlMM8Pd2VeyRlO,FtG4yGl6t2UQYHjbFYjoKUTv9W4A','','士大夫发','','2019-10-02 08:43:22',NULL,NULL,3,17.50,NULL,NULL,NULL,1,20,24,0),(10175,1,10060,0,'测算电费s\'d\'f',5.00,20,0,0,0,0,0.10,'2019-10-12 11:26:00','Fhut8VvFZUs6BZKlMM8Pd2VeyRlO','链接','文字验证','备注','2019-10-02 11:27:58',NULL,NULL,5,100.00,NULL,NULL,NULL,1,20,24,0),(10176,1,10060,0,'测试001',0.50,20,0,0,0,0,0.10,'2020-10-15 15:09:00','Fp2cJ4gby-dm8uuGtvOTLdokLiMP','http://xmzq.cnqcnet.com/','1348468','111','2019-10-15 15:11:02',NULL,NULL,3,10.00,NULL,NULL,NULL,1,20,24,0),(10177,1,10067,0,'1111',0.50,20,0,0,0,0,0.10,'2019-10-18 12:16:00','Fl6dwBkbdVQtL64I_ChDWakvsWUh','','','','2019-10-16 12:17:15',NULL,NULL,5,10.00,NULL,NULL,NULL,1,20,24,0),(10178,1,10060,0,'打字员一天80元',80.00,20,0,0,0,0,0.10,'2019-12-28 07:15:00','Fnd7vrjbNVjZOlKpSnzCr1lcsXpL','http://localhost:8080/','1111','有空即可来，要求打字速度快，按小时结算。','2019-10-28 07:17:35',NULL,NULL,3,1600.00,NULL,NULL,NULL,1,20,24,0);
/*!40000 ALTER TABLE `mdd_task` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mdd_task_step`
--

DROP TABLE IF EXISTS `mdd_task_step`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mdd_task_step` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '编号',
  `task_id` bigint(20) NOT NULL COMMENT '任务编号',
  `sort` int(11) DEFAULT NULL COMMENT '序号',
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '文字说明',
  `explain_img` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '图片说明',
  PRIMARY KEY (`id`),
  KEY `FK_Reference_7` (`task_id`),
  CONSTRAINT `FK_Reference_7` FOREIGN KEY (`task_id`) REFERENCES `mdd_task` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=157 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='操作步骤';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mdd_task_step`
--

LOCK TABLES `mdd_task_step` WRITE;
/*!40000 ALTER TABLE `mdd_task_step` DISABLE KEYS */;
INSERT INTO `mdd_task_step` VALUES (149,10174,1,'454545','Fl2NBga4QusEIra0eimNsugUylrW'),(150,10174,2,'4545',''),(151,10175,1,'454545','Fhut8VvFZUs6BZKlMM8Pd2VeyRlO'),(152,10175,2,'55555',''),(153,10176,1,'141864183','Fm5iMvcEwoEYyXnIUTsZsMNpD38G'),(154,10176,2,'qewrr','Fqs99OFajVFGK44brKGN_e7yPekE'),(155,10177,1,'455656','Frq6KlzBG9XC7aiAoDjH1MTIDggv'),(156,10178,1,'有空即可来，要求打字速度快，按小时结算。','');
/*!40000 ALTER TABLE `mdd_task_step` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mdd_task_type`
--

DROP TABLE IF EXISTS `mdd_task_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mdd_task_type` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '任务类型编号',
  `service_charge` float(8,2) DEFAULT NULL COMMENT '服务费(百分比)',
  `name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '名称',
  `earnest_money` float DEFAULT '0' COMMENT '保证金',
  `alias` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '别名',
  `icon` text COLLATE utf8mb4_unicode_ci COMMENT '图标',
  `min_price` float DEFAULT '0.1' COMMENT '最低出价',
  `min_count` int(11) DEFAULT '1' COMMENT '最低单数',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='任务类型';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mdd_task_type`
--

LOCK TABLES `mdd_task_type` WRITE;
/*!40000 ALTER TABLE `mdd_task_type` DISABLE KEYS */;
INSERT INTO `mdd_task_type` VALUES (1,0.10,'打字员',0,'zc','data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAD4AAAA+CAYAAABzwahEAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAABDxJREFUeNrsm1lsDWEUx/+3rVJrlLa2FrWV1lb7gyASYquExFprJCLhRSQePHkTImJfEk8iISFRIfHgRYSgdLMT+9KrrVpKl9tWnb9vmha93NuZO3Nn5p7kvNyZ5s5v/uc753zn6/UsymmAZvHi28QXi/eGs+yd+GnxHeKl/MCjgY8RvyDeA842r/h88VsEp9KPxBPgDqPiaVFaeLsFGhrrNoJnwX2WRfAUF4KnEDzWheCxUXCpRcAj4C6xGDs8ZJw8ZdZAIDMJ+FgFnHkCPP/scPAoD7AqA5imFd1+XYDkzsDuXODlF4eGerRArxvRBN1oie2BzePUS3AcOMN7/Shget+Wrydp8CmivsdJ4FSVa/pfRvglacDIRAeAt40GenUEXn0F9ucB32v/fT/vHRzvAPCFQ4CdU4FJvYDCEgVf4fN/f3k18LbC5uCLJWznS9lqI0+1YTQwvieQ/wE44Ed5fnZWStutYpuCMzktGwYsGPx7yG/MBCaK8gWi/N47vyv/pQbYcxu4XwbU/bAp+JKhSumW1jvhx/ZQYX8wH6gUlWvqgX3yIu6W6njZi3IaGixTWqRe6ge6uVXVAUcKgBvvgVGJSuF7ZTbu3JZLeM8bEFhN35Spurjr72zcq3u08A4EunnrGuMx7hksAV+RDswJApqhfrwIuPrWxuDZQUJzPR8rNC7ETQdnqGYPCw6a2ZtJzWhoU8EZ3rNTA7+/WsL7aGFooE0B59YyO0hoKn1IavbN4tA9V8jBOUSY2T/w+9mgUOlQQocUnM3JyvTgoH2i9OGC1vXeYQFO6LXDgRn9Av8bbjiOmAQdEnD2GGsygoNuXNO3veaVVcPBVw8Pfk0fNBnacHCq/akaaEBgczCGN/faeR/M7x4NA5/cB/B+B849BWp/qMT2vzaUW0vuta0wQ8CZzBjePTsA268DF5817b6iW5D+m0+UzrcO2rBBRFq8GvN2jAW2jFfzbsKffOBH6Tw1UrLSDAEfkaCmJTSOfLdo827Cn7gP1GujDo6OOC4qLIHlphu8Qxtg0h//HJbQDP6CwJ96qBIZJ6bhAP1reeodPXHov3VCy9d4wMch4eNyoHscUFaFsDHdik9J9n+tazs1KGR+Cydo3VmdxzyDuv79eWklcOUNkCtNyZsKVdfDzXSBjxE1u8U1lahHEtLXZP+cW6xqeThbq8Fjo1UY8wjn8kspTyX6D+ttAc6RL8sVVa6she3M0gMFWynOEGd9npMK9O4kzYlJa5nDSg4qOJm59KJ152W6wAk9d4A6xrXCeBbOHr81R8O6wFmqikoloyepDYiZyZsnKQ8/qoRqeqgz3D7LF5fIC4iR9sfMDMHv88r31tZHkpu1u7MIeAQ8Ah7W4D4XcvsI/tqF4K8Jft6F4Odd/YM72VhiFtTPD51uXo21vDGr3xHn2Qd/dPrCiWtafJfGSFb8FGAAsbVGw5awbb4AAAAASUVORK5CYII=',0.5,20),(2,0.20,'投票',0,'tp','data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAD4AAAA+CAYAAABzwahEAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAj9JREFUeNrsmztLA0EQx/97iW8QFAVBsLLSUvAjCDYWWtim0FoRtLGwURQsBEGwtNDCUlFs/QI2grUgCIoPgkiih7l1Jrlg7oEkwei5OwNDyGRvuV/mcbO3d0rPrcKXbtJl0mnSfpglt6SHpBukD2xw/B9GSK9IFwyEhs/EbJeko2Vw9vQZaR/MF2Y8YWbHD+9e2CPMuszgE7BPJhh8wELwAQZvthC82YGlIuACLuACLuAmSbqhs7e1Akuz9PeqL1v2BdjaMxxcEXBXp6Wh7nnB7wVPclzABVzABVzA/9V1vFppbSEXVPpAA/m34ofZ4IszwUaHr/Ur20Aubzg4ezvgcWVJjutwTGtLwKWqC3iCL2c9XcDkWNB2ew+cnhsO3t4GDA1GbcaHuo6pvK4rOS7gAi7gsjqrzUUq2sNrr+7u9v+AZ6aAwdAzDDsHpd7BaHDenAj3CY5jQY7rn70f/7PgKmYdrZyYXMX3NuVUN/efFDfeIXl7D9re3ei6Op8PhmT4mLKt0l7cfdHRucPHevVHgdJzq/XVRXZAKhVtY8NbROlU9B5DoRC08Txhh36ExzhRr/M8v17VdczJxUk1YwrVjElyjhvbwMxngN7uZJK85oD13QaBN9HwjoSuubVuYKhrndzYrfHcavP43SPQktAnQJ+yDQTfP5JlqYALuIALeNLBXQu5XQa/sRD8hsGPLQQ/ZvA1+K8dWiLMusbgz6Tj3JBaAH3nsz6Xq/oF6TBKL51em5jTpJs+I7PiU4ABAOlxg58SBbhwAAAAAElFTkSuQmCC',0.5,20),(3,0.20,'关注',0,'gz','data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAD4AAAA+CAYAAABzwahEAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAA9RJREFUeNrsm91Lk3EUx7/OvWmozbc5TSmzkrqruwqCuqrI7nqBQIq0uiiiugn/gSCCoMugLuoiK4ns5SaKghIK6rIkm8HCl1xOt5mt6VzneDYlfNncnmd79jw7cHhed87v83s957etINqDuJSTdpAeJq2DvmSAtJP0CqmXbxTEwLeRPiWtgb5lmPQg6QcG55buJa2CMYRbvNkU695GgUaMtYPBW2A8aWHwBgOCNzC41YDgVhMMKnnwPHgeXGUpsIgaDryqVTRLYs6OVwdQe0nOfV3A9JhBWryCEsCiTaJ8boiubl5NrX1h/prP+Z7uwatPAvYN89d8zvd0DW5xAq5zC+/zPX6mW3DnaYqS6xeJnOvlmS7BbesIbpkuzc/4Hd2BO09Ry65ZJl+iZ852nYHb1wM1SXTlmjPyrm7AOVgpLEv8Hr8TD2xyFtxkExDHvpUFKfwuf4Y/yzbUShWiPYimZ8FK49NFWidHG3XVomageLMck2npxSTiB/70ApOf5fjXDYSHSAfkGA1nEJwjLFujBB0MxuPRUkvApDZakkzF6vbPmUmqgB8EPghMkYbcUjGhPrrfTzH/uErgpbuAptsZXXaSkhBBu08AgTcqjXE27G6j2h7RDjSXpb9tRdCpTW7+l0DfUepWo9mH5jJwWfyvMjSrs6Ov5HDKm8WW9koZUoBObznzv6Buf1xm30wL+2TfXIasrONjz4BvrZmFZ1/sk31nNYDxPabapwQjEsgAdEB8sU9NRG6jD2lmpSRkJqTiGh4SH+xLUyHrr3uyrESCKrT0BNluFx+ajNW9dwHPZQonI8rZZFts03tH40kKx9WIKNncZPNLDmRn9o2SuCiWRln/35zULvhaFTYyGnMAfLntpVTF1qBx8MJSVQo5m+unmtdnBNxcIYVUA9xcrmVwKpzFpTw429Q0uNVJFu2J3wu+pXTymCifJyylXWwr2UbKTkIJdmaC74ChG5RgPJFtpNlY/xHgOAC4zgIlO1K3nVXwpdbbYA8BX5eMKg48F4PT9WinVIZjP1XAeaqA7cnb1gZ408INi5GbFGPfZ8IESQhXwAPSLqDyEFBNcX/Z7qVtpxsXpb29PGeJ6nCrR8ZigMbt4DXZppr5neLss4rA9wC1F4HSnUD4J/CJlsrotMZavLAEmHgvGRR33bTTUKqwsW5R/pKh8oj4UOhnI8p29ZFb1NqvlV/Oxp8vnBs009VzTPI/8MuD58Hz4LoFDxuQO8zgHgOCexi824Dg3Yb+w52PdC/k74d6l+EYqy8+q38k3QL50+l3PY5p0qsxRmbFPwEGAGiZF3S+KhSwAAAAAElFTkSuQmCC',0.5,20),(4,0.20,'浏览',0,'ll','data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAD4AAAA+CAYAAABzwahEAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAABUBJREFUeNrsm8lvG3UUx5/t8ZYmaRZnR4FSiRaKSgtSAYEAUUQUQEGoB/4BbhEXrj1XQuIfQJy5AKWFqKiUTUAPIKSKKCgsAhFwceIQxyR2E9vjWfh+Z8aIVoo9jhe5nnnKa2xnOn6ft/8cJTC/mBNHhqBnoS9Dp6S7JAV9B/o6dIMvBJ0fPARdhr7WhdDiMJFtCXqqAs5IX4aOS/cLGS+ROeik94h4R8h6luBz4j2ZI/i0B8GnCR7xIHgkKB4VH9wH98F9cB/cB/fBfXAf/HYRpV1vFIAeUAISDQYEX9KnBKzX85ophilSwj87eGx2C3gCx4HJeFCm4yE5dCCE5wHLAZVUM6AEzqimrOzokizoslow8Ny4/cAZ0WN9ihw/qMi9+D4QDlS9PgZnDOOMeKQ3ZD3fKpvyU16TpW1NlvHdMDscnHhHADo7FpFDPSHLAfsROurRobA8PBiWlV1dLq+r8gscYHYi+Eg0KHPjUTkxoIhbXtNxVrXMOYzymL87LotbmiykS7JRMjoH/ARS+qXJKNK1+pDY1U1ZRPr+AM07jawnFJCjfSF5cCAsg3uUBF89CYdO9wTl4mrJukfD2Tm/mDMbqeWZ0Yg8j0jXkmuI2IdrJcnu0bR60fB4rycTkZol8hEif+VvtaHa33fEESh5cSIqT4/U/uTq8w3VilRFOMomYkEJ4B4bJdNyxg1kwPu4ZhPdndkTqgJPR8dxAR2pm20GPzMZkycS4ZrXfb9tR9rq3gjlaUT1Kfy/CB7TZsM05bt/NCuKTP8vM6r0I+WfHa3uUDpcgefeTRXbt7kxJd1AcykhEFOStfzKXTGr4zNajCh3GDrg8eGwvHq4R4acHvEJ0tjNHKcNM6OR9oBzxLipacqPeV3SRRvgNCJ0tG/vBJtE6s9N2BBF3c4CN0JbaFNLwVmXrD+38/nnvG0819RHhmobd3+/ImNR26Rfb2iuGyxtom0tAedCwjfoVdxvJVnV7jyJaADpXft6OqgCwNFXdjmyaRNto41NB1dRqFij6xLD2bVY426ar2nePLuljs2Ptql1zDfX4CnU6sXVYl2HhxGnWXHbYsd20wyvF+z7swGGXYLTJtqWKhqtqXEeHi5g1pZdOpY1SyHz1Uy55vXcyDYdx1ZrhP8X2kKbtspm65obhSemCy5n5z04bd0Rt9/i6mbZmul7yZ84jCw4854LzimXnZq2LO1jhd3XHCfEp5i1tYQz+gWMG/ZD1t/byaJ8sFayosrn1BzS4Qtsdm+uFP4rhxnM+kEXec5TG21p6+bG6NDw2bHq443pzo57PlWyavgzOOwrgA5jbIWxea2XjJua0jPOvl61aeLyS1iM3Di/6eCm43F201q7NUEGwkHLWQRlOaZvaUQHEeHn4MTHhqunuGbVdFG+zpSlEWn4WMrderWoy5mpmExVWSIewNGVx8/lnI6Nzm5ijByB2ciOIzNq7Qh/oeOfR03/tqM3anZjx9JbIzYzGsWGpli13UxhiXybLcsVZFhOa87nME37BGYb+fseovFNNmQdRO5DBJUG+VkSyzlNPl4vSapgdOZHT5W6v46if+uPgtyJ9fEk0psOsM7eddxjDfVPYI6/5K4urZCWfbzMuUzlqEqgg3Oe0xnjeMydvN8ZVzmElamcRtPj9azjDB43K6XbDl4RAuQ0XX63GlJZOkX835354D64D+6D++A+uA/ug/vgPnjngqse5FYJnvQgeJLgCx4EXyD4OXH+7NAjQtZzBM9CZ6FpD0CnHdZspatfgx4T+49OV7qxpqFvOIxklX8FGAA3yB5KfqihsQAAAABJRU5ErkJggg==',0.5,20),(7,0.20,'区块链',2000,'qkl','data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAD4AAAA+CAYAAABzwahEAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAA7FpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTM4IDc5LjE1OTgyNCwgMjAxNi8wOS8xNC0wMTowOTowMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wUmlnaHRzPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvcmlnaHRzLyIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0UmVmPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VSZWYjIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtcFJpZ2h0czpNYXJrZWQ9IkZhbHNlIiB4bXBNTTpPcmlnaW5hbERvY3VtZW50SUQ9InV1aWQ6NjY2MzNFOTdFOTA5RTcxMUJDRkNCOTA2MUNFMjdFMjciIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6MkFFNkZBODY5OUVBMTFFN0FGMDVCNzVBOEVGQzlERTkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6MkFFNkZBODU5OUVBMTFFN0FGMDVCNzVBOEVGQzlERTkiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENTMyBXaW5kb3dzIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6ZWZjZDQwNjgtNzMzYS0yOTRhLWE1M2YtODE1NzAxMGYxZDA4IiBzdFJlZjpkb2N1bWVudElEPSJ1dWlkOjY2NjMzRTk3RTkwOUU3MTFCQ0ZDQjkwNjFDRTI3RTI3Ii8+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+We7f8gAAAfVJREFUeNrsm89LAkEUx9/uqruUUBRCEHgLKk/RtXtIocf+lcCrgtBf0qEgsX+gY9C1og6BEERBBErmbu703rqCdMjVcUJm3he+sMjO832cXztP1upWXiHWCrqCPkKvg156Rp+i614190YfWDH4LrqJXgO99YIuI/w1gVNP36NzYIaoxzfteHibAg0xa4XAS2CeSgSeNxA8T+AZA8EzNhgqBmdwBtdbqYlbuBakD7LgFNzoeiL1BPRvexA0O9G1kniqwNOHmOSON93PjGDDtsFZW0k8ZUPd2XKlh9lojFnHUzfHPUt+go3GmHU8XtwYnMEZnMEZnMEZnMEZ3FBw0Qnlv/VLKIunDDx88KXz7N/1lMVTdh4PLvHQj4chZ1uycKAoXlLRf2eC57hB4ppbUnHNTULSNbdvIZ3T5ENdYc0tfPQhOG+DaI/Z27FJan8RUnsLU+c0V4tbcJEAOnrqwb37qqvPqi4+kj/Fic9QH3DexxmcwRmcwRlcA3Br2VFy79yDp8tZsLLjU7KW7Ojefz2WUo0sSXJ/6lfNbRjP3siAe7wqFU9Zj3PNjWtuvKozOIMzOIPPFbhvILdP4C0DwVsE3jAQvEHgNRi8hGaKiLVG4O/oIgxeP9RdxFj0qrn34ap+gy6g6+gnHec0+oQYEZpY4UeAAQCSWtPrAy5fWwAAAABJRU5ErkJggg==',0.5,20),(8,0.20,'加粉',2000,'jf','data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAD4AAAA+CAYAAABzwahEAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAA6dJREFUeNrsm0tIVFEYx/+Ok1iZmpiZmomFmUaKhZVZURmYkJBUVkREixYtWkS0sYWLDCFo0SpcRFAEQkiYoJULibKil4maVKhNaT5ielnZYNn5OHdyDMGZc8+dmTP3/uHDYZx7vL97zvlexwmbqN4DTXHMKpiVM0tGaKmfWS2zamYj9IZN+8VqZp3MToQgNDQmYmtnlu8Gp5luZJaI0BcxNhCzTVveC2AeEWsFgZfCfCol8FQTgqcSeIQJwSNsMKkscAvcArfALXBpmhsbcHC78REzEsgpAtJzgSUrgTCPZz02CvSyuqGjBehp8yt4GCtLJwwbPasQ2H4EiIya+bPvu4GbF4CvHxVf6ht2AzuPewdNSskEDp0F4lMUBl++DijcK7b3d53k20M58HDmNrYdFr8+LgnIK1YQPHsTMC9O3xhrSqY6QSXAyXPLCHcG73X54OSkZCg5QzFwWcmJwUmOfHCbpCGV2+M/R+WM8+uHYuCfBoNrHL+BD/XIGWe4TzHw/lf6x6B83eCcXT742w5g4o++Md51KZi5ff8MOHTeeMddRYuUrnvi135z8lWjJHh3K595Eb1o1r9VAgbuGgNa68Rm+3GD4o2I57d9c1K/x3kHhh6a0uC0XG+cBz68mfmz4y6g8aJfvPm/jNjQnhvJHgGsLQUyCybz+FmRwOwont4OsLh//zow4oA/ZVyXldpHS/M4MNXW1FmZLvQN9Yk7wqCa8cVZvINC7WS7lyfQtNSbaoBOj/hN11Pfbn4iixIPgZarvHBZtAzYcpDX/a+f8C0yNhrAGU9MBzYfANJWiW2H2ISpY5Wd4v07Um4RkMSAH9UDJccm38/I51vmWmUAwGlGNu4DVhToGyfc41aobxf+360lpPF29XQrLIY9tC/DfgKfE82Bc7bKaRrEeMz4wjTf/YlfZpy6qPsr+WzLkp5enUAlJzZVbqcjU9Hxkw3Gtmbvr6OjJ4Fuje/gtKzpTMwIrS/jP1+2ciBv9KBO6E/5Dh4V632Y8lUU98mxubO+mRzWsybhU1bfwb09BBRV8VHuqSmpoTDlHJj+c7Qdmi8HYa6uJ8UtP83Pz8hpXWGv+9qnFjN3LgG3anSVr3YEoyiG07k6hUqa1doz3K9QLKd6XUIH1vgiJUhl/fOPBW6BW+AWuAUeIuAuE3K7CNxhQnAHgdebELyewKugfe3QJCLWKgJ3MtvBbNAE0IMaq9Pt1Z8yywb/0mlvKO5pZuc0RmLFXwEGANcN5E17VXKTAAAAAElFTkSuQmCC',0.5,20),(9,0.20,'评论',0,'pl','data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAD4AAAA+CAYAAABzwahEAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAmxJREFUeNrsm89LVFEUx78z/hgXmikooaG0VVyopLgTwUAQXUn/QRQRkZuQ2QlipgghulEXbgRxN4hBogiiqE1CES0EqSbNEVFBJZsxnc7h3vkDvOh7vnfPF77MY+DOvM8975x77nu8QGq8DlqF5DD5MbkU/tIOeYr8hrzPXwQ0eC15hnwP/lac3E5eD+pIv7cAGpqRA1wY1Jd3EewRs4YZvA32qY3ByywEL2PwbAvBs4OwVAIu4AIu4ALuJ2Uaj8wrAR6+oO63GsgpcPask6fA3mcgOgwcbRn9BO/OUlcedfcB0DpGbUCuu2G7PKft1XM1CY5EvOaJgo4tASt9wJ99Z4FDd4BqOoeKDtpQPwVmnzmU4yX65sVyr/PQrMQx8HFIHRdXOVjc0pf42YF7l/lFQuV6MMso5WQ5k+XsOlXeCDRRHQhccX5Tl8BCF/Bz0aMR57U+YPAXPIbHejbiXyeVJccFXMD9WdVLqcN79M6sqn94CeysezTi+eXmVZ3Hejbi36aVJccFXMClV5deXXp1yXEBF/B0oobU57+EReBc/PhG498jdX/9VhW3m1JRJVD/Sh3/WHC5qvOa3dgNZIScm4DjbWBj1EVwfqJR32m2Zpvo5DewGwXWBoHzMxfAGZSBGZwVHQG+TFjQsjbTjN9vULO+GAZ+LVvSqzP0aRyY6zR+XOtN8PgGMP9aPcSzZne2GQFW3hqtod4FXx24tbeUbrZz8zi0bFIEXMAFXMD9CJ60kDvJ4DELwWMMHrEQPMLgPdCvHVoiZu1h8ENyC9Trh35XXLMepqv6J3Il1Eun3/2Y0+R+zcis+C/AAEDslEsdvoBHAAAAAElFTkSuQmCC',0.5,20),(10,0.20,'特单',2000,'td','data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAD4AAAA+CAYAAABzwahEAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyJpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMy1jMDExIDY2LjE0NTY2MSwgMjAxMi8wMi8wNi0xNDo1NjoyNyAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENTNiAoV2luZG93cykiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NjhGNUY0NzkwRUFFMTFFNzhDNUJFNDU2MDI4NjBCMDEiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NjhGNUY0N0EwRUFFMTFFNzhDNUJFNDU2MDI4NjBCMDEiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo2OEY1RjQ3NzBFQUUxMUU3OEM1QkU0NTYwMjg2MEIwMSIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo2OEY1RjQ3ODBFQUUxMUU3OEM1QkU0NTYwMjg2MEIwMSIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/PqzyUWQAAAazSURBVHja7Jp7bFNVHMe/596+u3br1m3dYLLBJJjxBqP8g2D0T42vZIqACTGY8K9vDTFRgwxnJgkPNT4QJjIBA8IfgCDxL5mAvEx8jQmDsbG169Zu7dr13uM5596VDiaBre2g3VmWs922957P+b1/p+RC5TTw0W9zv6EaDK/aglfzQSkyahCCkKO4S1LU9Za+jnfFJQ4edE3e5vA3L0UWjGD+5AZHV/OzBi7pbIHmg0FXM+bTEldvZNngzJK1tzM/28A5s0RUJdu4wZklZOkYBx8HHwcfu0GLCkHN5uwCp55ilB09DFddbfaAcykXHzkE2WSCqaJcbEJWgJN7p8DMoHlmYaqshGnBgswHp/kuuFatgir+YZvA5+hAyp5nuCOgjUYUHTwAW56TgVNIrIyM9fcjdvFCZkvcsPghWAS0Gl9Q37FGqH/8mbngZO4cFL7yMhRKQVXeACFc0xE6cBBEUTJT1cnc2fDU1sBUVgbKwFUiQ1VV+L/dgcjefZqdZ5rEpfvnoaBmLYw6NGF2LTPSgSttCNatB4nFUmte6RczgfXFFch9rlqTNFNvSSLCk6vRCLw160B6Aqn3K2n13vfcg5yVK+CurtYvMElLukKzKXT2HGKHDqfHoaYLWp49C4VbvoTRbmN2rDApy0L6iWPgYgsTu5o5RQotKEAxgzYzaC05Gd5txdquZlB1xtTbtXkDqM3GNJvFacZMpBsfy0OYqkRBMwLc44G77iM45sxmMmY5Gfn/AMVfcTy/BDQ39+4Hd7y0EvaZ09lDVBiIxOabR2ZroRulPx6A4eknQe12tjppSDSgTgdQPkmYzqiDy4XKaanRLgZR1LAdZhayiB6nb+oH+A/lWiFD4Q4uEAD1eqGE+zXnaDBCLvFANRpAgr3wb9+OUP128fcdA04rKlD8xWewTJwgdJjcYg6mCngq7FwiUtwEiO4DyOAG8ZnF/+5t9ehdUzOiSJB0VadFRSj8dBOsZROFlMltJJ7cFGQGLBPtU1Lc7SF+F/6KpLL3MTPIW74M1GJJTxwXvTCzCcSeAynXCeIugHK+GWhrF6/nvLAc9opyrbwcYbaduFnDbRwl2kb41rIsLxRKPbh56RJ4Vr+tNQt0m+VS6dpaj+D7a7SFylJCgEpNmcHBI8wkQjt3jfgJtw4uy3C/9ZrwtBI/PyckHnNlJnnhgZmtqR0duqRSFzD4nZU29hzd8aU2nLHauPP11fHQkmh3plkzRBeFb0SMeeJ0JCHW0mKQ0tL0xHG1p2d4ZXDmgjz1BLp5Dj59RgqVfFDXtU6N8cEH0gTe5Rs2/ppYQuFc8gxMFZVQLjEnFxtIrbgphmhc6sF9XUOAE1dhKi6BiaWo0fYriAWDqeVmIU9lphc91pimlJVJkmMqeqKR6MSseQWwVN0HpbMNkfaOVPcy0Fn/DdDSkh5wyZWHqMisSDwFFZkWpaLqss6tQjTgRaTp7+u1MukjcuRo+ooU9XIrIj5v3MFou39tE+zMscn5boTOnEasPyxORFTROU0+fs4oT1luT9VDYbHT8nUZ1SCWpbQMzqp5CJ08h9Cly/p1VWhIsodaUnhDByeluXpo4ycInzorHAyN59HX3Kxx/iwo3naEfzsFoqgQNpCkLwxqfXdto/sado/qvrefXrW1wb9pc7xqihPri7DMnwljgQt9h39GtCcAKUkZ3GDVxgNlG0+PT5xMfyNi4MRxhM/9noCupyxssrlLYFm4EOF//kK05ZK2QWT0qi7qPKY9vr37MPD1trHpwJDePvh3NGi2plCoCakan1yPP4ac1lYEa+uQtEMg/f7q/v1j23qKHvkJoaYmveYeujhH5VQgNxdK4y/wfrAONJYc/PC/zRg4c3ZswQnL4nq+2grRKBERiw62UcQOyNOmaov9bierb2I3bzkNWov+S/XbXO+6end+D/i7kwI+qgOFyA/7EHj0YTgXLYLC9Z1ovTVRQFRVMYkfZ2bRi9aFi0GsVhCHA4YpU1DwcS17sPY+kmgjQxUnPkd8PnRv2Ijw7j1JC4yj77mVT4Jnzy6Y7TlxN9f7ayP877wH2nR+eCnzTcixg7DixlA2kVV3DsgTJsD+yGL0fL5Fq4IDQVYU+UEDATZ3gQSSe56WnGajpwiS282KGD+jDmoNgpGcdurNjHSM5JydsaJETUZhkiboUTm3u32Mg4+Dj4OPg2cmOOVfyciywZmlcE5hV7aBc2ZJisU+zDo1Z8ySJeRdG3RNrs8WaM7KmYVzc/ibl/Xb3G/2OUu9lGSev+PfvQk5S3yckbPya/8JMADeZoOK4jjzWgAAAABJRU5ErkJggg==',0.5,10),(11,0.20,'高价',2000,'gj','data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAD4AAAA+CAYAAABzwahEAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKTWlDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVN3WJP3Fj7f92UPVkLY8LGXbIEAIiOsCMgQWaIQkgBhhBASQMWFiApWFBURnEhVxILVCkidiOKgKLhnQYqIWotVXDjuH9yntX167+3t+9f7vOec5/zOec8PgBESJpHmomoAOVKFPDrYH49PSMTJvYACFUjgBCAQ5svCZwXFAADwA3l4fnSwP/wBr28AAgBw1S4kEsfh/4O6UCZXACCRAOAiEucLAZBSAMguVMgUAMgYALBTs2QKAJQAAGx5fEIiAKoNAOz0ST4FANipk9wXANiiHKkIAI0BAJkoRyQCQLsAYFWBUiwCwMIAoKxAIi4EwK4BgFm2MkcCgL0FAHaOWJAPQGAAgJlCLMwAIDgCAEMeE80DIEwDoDDSv+CpX3CFuEgBAMDLlc2XS9IzFLiV0Bp38vDg4iHiwmyxQmEXKRBmCeQinJebIxNI5wNMzgwAABr50cH+OD+Q5+bk4eZm52zv9MWi/mvwbyI+IfHf/ryMAgQAEE7P79pf5eXWA3DHAbB1v2upWwDaVgBo3/ldM9sJoFoK0Hr5i3k4/EAenqFQyDwdHAoLC+0lYqG9MOOLPv8z4W/gi372/EAe/tt68ABxmkCZrcCjg/1xYW52rlKO58sEQjFu9+cj/seFf/2OKdHiNLFcLBWK8ViJuFAiTcd5uVKRRCHJleIS6X8y8R+W/QmTdw0ArIZPwE62B7XLbMB+7gECiw5Y0nYAQH7zLYwaC5EAEGc0Mnn3AACTv/mPQCsBAM2XpOMAALzoGFyolBdMxggAAESggSqwQQcMwRSswA6cwR28wBcCYQZEQAwkwDwQQgbkgBwKoRiWQRlUwDrYBLWwAxqgEZrhELTBMTgN5+ASXIHrcBcGYBiewhi8hgkEQcgIE2EhOogRYo7YIs4IF5mOBCJhSDSSgKQg6YgUUSLFyHKkAqlCapFdSCPyLXIUOY1cQPqQ28ggMor8irxHMZSBslED1AJ1QLmoHxqKxqBz0XQ0D12AlqJr0Rq0Hj2AtqKn0UvodXQAfYqOY4DRMQ5mjNlhXIyHRWCJWBomxxZj5Vg1Vo81Yx1YN3YVG8CeYe8IJAKLgBPsCF6EEMJsgpCQR1hMWEOoJewjtBK6CFcJg4Qxwicik6hPtCV6EvnEeGI6sZBYRqwm7iEeIZ4lXicOE1+TSCQOyZLkTgohJZAySQtJa0jbSC2kU6Q+0hBpnEwm65Btyd7kCLKArCCXkbeQD5BPkvvJw+S3FDrFiOJMCaIkUqSUEko1ZT/lBKWfMkKZoKpRzame1AiqiDqfWkltoHZQL1OHqRM0dZolzZsWQ8ukLaPV0JppZ2n3aC/pdLoJ3YMeRZfQl9Jr6Afp5+mD9HcMDYYNg8dIYigZaxl7GacYtxkvmUymBdOXmchUMNcyG5lnmA+Yb1VYKvYqfBWRyhKVOpVWlX6V56pUVXNVP9V5qgtUq1UPq15WfaZGVbNQ46kJ1Bar1akdVbupNq7OUndSj1DPUV+jvl/9gvpjDbKGhUaghkijVGO3xhmNIRbGMmXxWELWclYD6yxrmE1iW7L57Ex2Bfsbdi97TFNDc6pmrGaRZp3mcc0BDsax4PA52ZxKziHODc57LQMtPy2x1mqtZq1+rTfaetq+2mLtcu0W7eva73VwnUCdLJ31Om0693UJuja6UbqFutt1z+o+02PreekJ9cr1Dund0Uf1bfSj9Rfq79bv0R83MDQINpAZbDE4Y/DMkGPoa5hpuNHwhOGoEctoupHEaKPRSaMnuCbuh2fjNXgXPmasbxxirDTeZdxrPGFiaTLbpMSkxeS+Kc2Ua5pmutG003TMzMgs3KzYrMnsjjnVnGueYb7ZvNv8jYWlRZzFSos2i8eW2pZ8ywWWTZb3rJhWPlZ5VvVW16xJ1lzrLOtt1ldsUBtXmwybOpvLtqitm63Edptt3xTiFI8p0in1U27aMez87ArsmuwG7Tn2YfYl9m32zx3MHBId1jt0O3xydHXMdmxwvOuk4TTDqcSpw+lXZxtnoXOd8zUXpkuQyxKXdpcXU22niqdun3rLleUa7rrStdP1o5u7m9yt2W3U3cw9xX2r+00umxvJXcM970H08PdY4nHM452nm6fC85DnL152Xlle+70eT7OcJp7WMG3I28Rb4L3Le2A6Pj1l+s7pAz7GPgKfep+Hvqa+It89viN+1n6Zfgf8nvs7+sv9j/i/4XnyFvFOBWABwQHlAb2BGoGzA2sDHwSZBKUHNQWNBbsGLww+FUIMCQ1ZH3KTb8AX8hv5YzPcZyya0RXKCJ0VWhv6MMwmTB7WEY6GzwjfEH5vpvlM6cy2CIjgR2yIuB9pGZkX+X0UKSoyqi7qUbRTdHF09yzWrORZ+2e9jvGPqYy5O9tqtnJ2Z6xqbFJsY+ybuIC4qriBeIf4RfGXEnQTJAntieTE2MQ9ieNzAudsmjOc5JpUlnRjruXcorkX5unOy553PFk1WZB8OIWYEpeyP+WDIEJQLxhP5aduTR0T8oSbhU9FvqKNolGxt7hKPJLmnVaV9jjdO31D+miGT0Z1xjMJT1IreZEZkrkj801WRNberM/ZcdktOZSclJyjUg1plrQr1zC3KLdPZisrkw3keeZtyhuTh8r35CP5c/PbFWyFTNGjtFKuUA4WTC+oK3hbGFt4uEi9SFrUM99m/ur5IwuCFny9kLBQuLCz2Lh4WfHgIr9FuxYji1MXdy4xXVK6ZHhp8NJ9y2jLspb9UOJYUlXyannc8o5Sg9KlpUMrglc0lamUycturvRauWMVYZVkVe9ql9VbVn8qF5VfrHCsqK74sEa45uJXTl/VfPV5bdra3kq3yu3rSOuk626s91m/r0q9akHV0IbwDa0b8Y3lG19tSt50oXpq9Y7NtM3KzQM1YTXtW8y2rNvyoTaj9nqdf13LVv2tq7e+2Sba1r/dd3vzDoMdFTve75TsvLUreFdrvUV99W7S7oLdjxpiG7q/5n7duEd3T8Wej3ulewf2Re/ranRvbNyvv7+yCW1SNo0eSDpw5ZuAb9qb7Zp3tXBaKg7CQeXBJ9+mfHvjUOihzsPcw83fmX+39QjrSHkr0jq/dawto22gPaG97+iMo50dXh1Hvrf/fu8x42N1xzWPV56gnSg98fnkgpPjp2Snnp1OPz3Umdx590z8mWtdUV29Z0PPnj8XdO5Mt1/3yfPe549d8Lxw9CL3Ytslt0utPa49R35w/eFIr1tv62X3y+1XPK509E3rO9Hv03/6asDVc9f41y5dn3m978bsG7duJt0cuCW69fh29u0XdwruTNxdeo94r/y+2v3qB/oP6n+0/rFlwG3g+GDAYM/DWQ/vDgmHnv6U/9OH4dJHzEfVI0YjjY+dHx8bDRq98mTOk+GnsqcTz8p+Vv9563Or59/94vtLz1j82PAL+YvPv655qfNy76uprzrHI8cfvM55PfGm/K3O233vuO+638e9H5ko/ED+UPPR+mPHp9BP9z7nfP78L/eE8/sl0p8zAAAAIGNIUk0AAHolAACAgwAA+f8AAIDpAAB1MAAA6mAAADqYAAAXb5JfxUYAAAV5SURBVHja7JtbTFRXFIY/zsDIRUCQaquG2tDYQWG4KmCrVVvrLZLYaGxNmqZPfeHJV14hMekjfW7Sp8YGqk6tgngt1guVGg2IooARLYjItQLijNOHNSdngHOGGWAuMLMSMhv2Pvvwn7X2v/61DkRVVThxWSpQDhwGVrO47BlwHDhWVs4LAMU1UQC0AEcXIWhcmI4Cd3+sZBNAVFWFMxW4D7xDeNgLwKK4wjtcQOPCWq4ApYSflSpAehgCT1cAcxgCNyuEqUWAR4BHgPvXoqLkK1gWPZ+bbdwCRVuN5y/XQnOTjLd8AW8dcPW8SzNvhpLt+tfdvQV/1oUo8ILNnkH/c0MDnVUA1kIZD7yEltvQdA0Sk2RuqlkLIT4B6k+BwxFCoZ5bZOwtgM42uH5Rxh+sg093aXNbd8GatTK+Uidr9ezDTCg9AjHmEAGeWwSffG48//xfqDsBTieseA92HZh8tk0m2P0lJKfImroTco1uiZUOB7+F+KVBBp6zyTPooQE4fRzsdkhIhH2HIFrncMXGQenX8mm3yzVDA/p7Ll8Bh76TBxUU4FkFsGWn8fzYKNh+kU/zEij9SsAbWXKKeN5kkmtOH4eJ1/prE5ME/MpVAQa+IQ+27TaedzjgTLV4zWSCvQfFUzPZmrVy5lXSO1NtTGaxcXDgG0jPCBDw9bmwfa/nNRd+h+4uV9raqZGXtw81v1jGTx/LXoYpKRr2H4ZMq5+BZ1phxz7Pa65fgrYWLcXppaeZrGSHsD/IXtcveRZCn+2Xe/kkoKoqnM6IZA0j81q5bdvtOWx//Ql6u2WcmgZHvp/7LzcyDD9XeS+Jm5tEFs+rxxvqjYUFQH6JNu7vg5e9cwf+8J42jjFDzkbPQqmh3g+h7nBAbY3kWD3LsIinVVMJbi7WcX8y28fGGWuG2hrfdLzia+jV20Ra6rGrO7O6e2u2Yd7zTJO1eUX665xOOHdS1vuV3J60Q2OD/ty6LEhaJuPhQc9Hw5cw/yjbWPXdvAJdnQFi9VtX5QH40+vtrdqeecX6ax4/glt/BTCdOZ1w7pR4dapZrJp32lv1j4U3Ya5GS4YFUpbrF0DnTgYhj4+PQe1v0wnFZNIk58gw9Dz1fe+2Zv1soZrdDmdrjIsYvwuY3m79ltD6XIiLl/GDWbB7u4vN0zOkhp9qV85C3/MgK7eW29B6d/LPYsxSq88m3IcHNSGkp7+bm6bfL2iSVc8D1kKpw8dGpcrylc3fXS0dl6kR5otI8TtwvTNnXqI1FN3PrLfAp3p7bBTOVodYs1Fl2Xrb9NZUjBk6H8rD8WaPvueiANWydC4iJWDVWWebtIlVi4sXqTk+Bl0dM1//qFXf240NsxMpAS1Lb1yefKbziiTFeSNm2lpE+a3LmixS/m5YAPW42iJ+NSLfJyRCZi50PPAc7gMvpaLLL9baz8ODcxMpAW9EjI1C7QmNiPKLZWz0skDN3fFLwZKjEeaZ6rmJlKB0YLq74Jrr7UnSMrBkew73h/ek3lb77vMhUoLWerrTqBFWXokQlJ4H+/tgZAiyC4xF0YLruV04LcBS0+D9DP1wb28V0OYlxjJ4wQF/MyHdkTcTUPixfrg/fiTv4OZbpAQVuBrKF/+AtJUQpUhed59buUraSvW2+RUpQQeuktedRmH4drdeWscDOf+NDfrNjQUPHDSWd29YKibJ3/4QKSED3OGQ/J6cAqP/CeDUNDhvI+AWHegbvhqRdJWYDM63InHdz/yiBQ6i5VvvwOtx/4qUkAOuipRgWuQP/CLAI8AjwBct8IkwxD2hAE/CEPgTBbCFIXCbAlQi/4QWLvYCqFSAfmAP0BMGoHuAPWXl9Kus3gRsAI4BnYvxTAM/ABvKymkC+H8AgdjzfdSohjIAAAAASUVORK5CYII=',1,20),(12,0.20,'长单',0,'cd','data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAD4AAAA+CAYAAABzwahEAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAA7FpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTM4IDc5LjE1OTgyNCwgMjAxNi8wOS8xNC0wMTowOTowMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wUmlnaHRzPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvcmlnaHRzLyIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0UmVmPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VSZWYjIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtcFJpZ2h0czpNYXJrZWQ9IkZhbHNlIiB4bXBNTTpPcmlnaW5hbERvY3VtZW50SUQ9InV1aWQ6MkRBQkUxNUI0RUQ2RTYxMUFEMkNGRkI3NjU5RjlCMjgiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NEY4RkQ3QjE3MDM4MTFFN0JDNTVGRDQ0QjRERDI0NzIiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NEY4RkQ3QjA3MDM4MTFFN0JDNTVGRDQ0QjRERDI0NzIiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENTMyBXaW5kb3dzIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6YTI2YjJkNjQtMWYzNS00ODRkLTljOGMtYjE5ZDU0NThiMTFiIiBzdFJlZjpkb2N1bWVudElEPSJ1dWlkOjJEQUJFMTVCNEVENkU2MTFBRDJDRkZCNzY1OUY5QjI4Ii8+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8++jH+JQAABgBJREFUeNrsW+tvk2UUP71s3dptXdd2l2QaJlMRF8QYYhS8fgDFEAhGvCQaRQIxflPxf3DwzQ/GGxhjJItGomjQL6IgfvIGWYCEzcUw2EbXrt3arlvbt57fu/dtn1Wnfdv3wvbul5xsvex5zu85zznPOed559hzcYgUdLAcZNnNcjOLi1YGJJa/WI6z9LNM4E2n8uEmlvMsr7P0rCDSKkdwek3heK/6ZpjlG5Z2WvkAx6/B2als7zDZByFwBvGdZD/sBPFeGxJf4xQCnJ1Qb0fSRDa19ipxW8Jt9AQuh4Nub2ygO72N1Nvooa76OmpxuajRubDms5JE0/k8jc1n6fJshi6kM3QpPSvnmcuSeEddHW1v89N9LU3kdy2dAWMBIPj+Rp9Xfi/BC/HzdJJOxhI0kc0uD+IBt4ueCwdpi7+5aj/CQj0e8NPW1hb6iRfgWCRKU7n8jUv8UVb0hfZgcRurgAV/T6bpIm/h0bl5imRz8hZXLR6uc1O3p152h41NXtkVVDd5iBdwU7OPPp6YpFOJGd10dXBZWqh1kDpW8EBXmB5oaV70Poh+FYvTudQs5QuFimMCtvwOdpM7eCFEnJmeoXfHIpQtFKy3OCx2sLtTtpYK+OVRthCsrBVYoF+TKVnuZuu/1BGS/R/Awra53XRodLy4Yyw5ztxsnTfKSMMn3xwZrYp0OTAGxsKYKjAX5sTclhHf3xmmPoH0Z5MxevvaBGX+xxo+l5O2cvAqjwX/BoyFMTG2Csx5oDNsDfGHOegg8KgYiMTo88mpiv721a52epm38H4NymNskfyDPDeCqanEW/nIerEjVHx9mqPtF9Gpiv/+niaf/PN+PuO1AOTFbf88nyDwedOI45xWt+k4Z1wfcCAzC++PR+Q5AS/r8FQoYA5xRNgtgqWOMOk5STKNOHz+o+ulhYa7IQ8wnPi2QIt81gKDfE6fS6XJbKjJkHruP8aB0lDi+PJmIUk5EY1bVl0hMVKxmXeg00jit3GVhcAGxDl3Pm+BtVUgG0QqvFAfuOlW1s0w4uuFMxuZlUTWARmemCStL0tvdSXe0+Ap/n6Ja2ercUHxc+AWQTfdiaOJoAJVltW4Iugg6qY7cTFZQGlpNUQdAhoTGU3EG5ylwiAtSZYTFys0UTfdy9KCAcoPrFu75GeTbNEBzs9PV9CA0KqbJotnpNLwXmf1hd2cVJmaIc7IUMw4/qMXoHXMqohP5Uo+VU2aqOJUYroiC8GH3xmLLPldUYdYLmfcVkcL+CZPvfw7emR/ZuaqIo7uzFEdChtVF+Da/LxxFh8WiK7TmCkZATFpGdFoBE3ExYQBNbWV1zAoTtCTUzGYzhhHHDcdqp8jZ9/g81pGfIOvsXhREeVYMDxrIHEEmbNCB2RHW6tlxMW50ZUx9DgDTk4lij3yPl51rLzZuIt3mtrZzbEu38UTxjcikFT8KCQUezvC5HE6TCPt4bN7r9Dv+4F1iVaRPlcVn45FYpTKS8XiAOTNwj4m3akUJEnWAd3dalAVcVzrfhKJFl+j1bwraLy/7woG5LZyKR+IyLqYRhz4Pj69aMs/Ew7S7mDAMNJPhgL0bLht0fxiq9k04sB74xEaTC2c7fDyp1mxV7raZT/UCw08FsbcEyqRRsvrwxozv5o0RETtvzq2qPeGbf/Wmm458tYK3Jr293TLY4qkD18dl+euBbpcE+MCb19nmB7xN/8j0zsRi9MfyXTF/TlYAnfkOKfL+2jY3rB0TodrYl2Iq8BFAyI8LgVFJHJ5+i210Au/UvZgAMpblJ8oOEAUaWj5oyM4QY5wIKvFpw0lDjS78ChImxx9a73KhWXRhPiUj6yZvL6PguhOXGwibAv45V2g9WIvyvXA2USSvuWMLGpQb88w4sUJWHqVx73WNnjk5CPIC6Fme+jqoImAWn84s/C41xAXHIYqRSY851ZQqrrLN0AfXrfjbDljlfgqcRsRl2zIex7Eh2xIfATEj9uQ+Jcgfpjluo1IR1gOgTgK2ydI+Z/LFQ5w3A7OalT/haUPK6H4fHYFkQWXYWVn9ylc6W8BBgDrs0XHMvlcMwAAAABJRU5ErkJggg==',0.5,20),(13,0.20,'电商',2000,'ds','data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAD4AAAA+CAYAAABzwahEAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAA7FpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTM4IDc5LjE1OTgyNCwgMjAxNi8wOS8xNC0wMTowOTowMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wUmlnaHRzPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvcmlnaHRzLyIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0UmVmPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VSZWYjIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtcFJpZ2h0czpNYXJrZWQ9IkZhbHNlIiB4bXBNTTpPcmlnaW5hbERvY3VtZW50SUQ9InV1aWQ6NjY2MzNFOTdFOTA5RTcxMUJDRkNCOTA2MUNFMjdFMjciIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NDY3MkVEMTc5OUVBMTFFN0I4QzNDOTNGNzNFMTI1QjIiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NDY3MkVEMTY5OUVBMTFFN0I4QzNDOTNGNzNFMTI1QjIiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENTMyBXaW5kb3dzIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6MGY2MTM0N2YtNmQ2Ny1lMzQ1LWFlY2EtOGJjMjIxZTc2ZTI2IiBzdFJlZjpkb2N1bWVudElEPSJ1dWlkOjY2NjMzRTk3RTkwOUU3MTFCQ0ZDQjkwNjFDRTI3RTI3Ii8+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+XKVMuwAAA3NJREFUeNrsm0tIFVEYx//n6A184INCo0zLJz4ohVxFuwzbSFCQmCJFLsxFrrJdLWrlNnVnai1Sg1zUolBDxYUokYaaoollQd57ycfVi/cxX2ccEjVMb13vuc7MB3cxh7kf85v/9zjnzAzzFlyEat5jl1OY82src0zlMvdiCHRkZIn2UmTqBwo7XmppqvqkjjEV3Hv0Uim39zcz9xKHjo0sUYpy+NwtS0v1E+Yqr08Jme+chMeha+gNC41UvHEX0rka3oaBVk2wqsycrX45DYOZysyZ66fFcOCCmYM8MJwJZg6DmglugpvgJrgJrquZ657PzM4Gv1cDxMf/vUUODoIePgKcTn0ozmvu7gq9PivKzwcrKNBRqCu0d68JCfoBV2prgR/zezs5Pk5HOT46CqWsbOc72PESCA/Xwl2kBOkm1Hczq3WT4vE6Uny3Bc+8FSwpSTuIiAB/+yawJA4HqLVV/NoCrLjNKlfCyEiw4mIJoT5vlR+/MzMSwG3ywamrW3Jxk2EeD6i3N/DgJDnU1akylpcNqHhnl6Q+vrYGLC3JgV5dBQ0MSFyWSlKd+voAl0seONlschT3oZrvj+IyCpzdDhoelgwuIdSpW6hNJBncJgP8neTVmYxePjUFTE/LXZ0FVHGnEzTyEdTQIH9ZquW4Tcs3xtYPlZLr4mZIqvQBzXG3G1hY2Dhk2dlBuxHh/331zZU9KzNowUP97ZAEOEtP1xQ/kwtKS9PCf2Vl5z85HDu3JDEdhaIEP/gWxZNPgdc99q9/kUrU0gJ69TqIQ30/LCYGrLIy+HKc+vuBubn9Axdrbmpq/m836gt+wb4FfkCq+u87evUKeHsbeOtzsKKif/dTWAj+tAX8RbtPu6hywHNywCoqgOhoIDYWrOo2kJrqu5/ERLDqO9oDiqgosJs3wPLyghecZWZuzN60AaaN+eonI0Nc4bZLzMoKXnAaG9s2QKCJCd/9TE7+2cPHx/1yjSH3U1Ie7EtLs9nBRB9ff7RTVw8MDfnuZ3ERmJ0FOyn8uF2gxkZQT49/otKs6ia4CW6Cm+AmuAl+gMFZqPGoBTOnQ7Fuo3GrzJzCE0cMBy6YOYWduKZ+hGYYasGqMvOQ7x3T3iPny9XPD3WvtGBUWS1NldNs60e1356xlc9nmcseqrOc9lBE8nuhdIkKrY79EmAAF9FB8pG1ytEAAAAASUVORK5CYII=',0.5,20),(14,0.20,'其他',0,'qt','data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAD4AAAA+CAYAAABzwahEAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAA7FpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTM4IDc5LjE1OTgyNCwgMjAxNi8wOS8xNC0wMTowOTowMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wUmlnaHRzPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvcmlnaHRzLyIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0UmVmPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VSZWYjIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtcFJpZ2h0czpNYXJrZWQ9IkZhbHNlIiB4bXBNTTpPcmlnaW5hbERvY3VtZW50SUQ9InV1aWQ6NjY2MzNFOTdFOTA5RTcxMUJDRkNCOTA2MUNFMjdFMjciIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6MkFFNkZBODY5OUVBMTFFN0FGMDVCNzVBOEVGQzlERTkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6MkFFNkZBODU5OUVBMTFFN0FGMDVCNzVBOEVGQzlERTkiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENTMyBXaW5kb3dzIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6ZWZjZDQwNjgtNzMzYS0yOTRhLWE1M2YtODE1NzAxMGYxZDA4IiBzdFJlZjpkb2N1bWVudElEPSJ1dWlkOjY2NjMzRTk3RTkwOUU3MTFCQ0ZDQjkwNjFDRTI3RTI3Ii8+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+We7f8gAAAfVJREFUeNrsm89LAkEUx9/uqruUUBRCEHgLKk/RtXtIocf+lcCrgtBf0qEgsX+gY9C1og6BEERBBErmbu703rqCdMjVcUJm3he+sMjO832cXztP1upWXiHWCrqCPkKvg156Rp+i614190YfWDH4LrqJXgO99YIuI/w1gVNP36NzYIaoxzfteHibAg0xa4XAS2CeSgSeNxA8T+AZA8EzNhgqBmdwBtdbqYlbuBakD7LgFNzoeiL1BPRvexA0O9G1kniqwNOHmOSON93PjGDDtsFZW0k8ZUPd2XKlh9lojFnHUzfHPUt+go3GmHU8XtwYnMEZnMEZnMEZnMEZ3FBw0Qnlv/VLKIunDDx88KXz7N/1lMVTdh4PLvHQj4chZ1uycKAoXlLRf2eC57hB4ppbUnHNTULSNbdvIZ3T5ENdYc0tfPQhOG+DaI/Z27FJan8RUnsLU+c0V4tbcJEAOnrqwb37qqvPqi4+kj/Fic9QH3DexxmcwRmcwRlcA3Br2VFy79yDp8tZsLLjU7KW7Ojefz2WUo0sSXJ/6lfNbRjP3siAe7wqFU9Zj3PNjWtuvKozOIMzOIPPFbhvILdP4C0DwVsE3jAQvEHgNRi8hGaKiLVG4O/oIgxeP9RdxFj0qrn34ap+gy6g6+gnHec0+oQYEZpY4UeAAQCSWtPrAy5fWwAAAABJRU5ErkJggg==',0.5,20);
/*!40000 ALTER TABLE `mdd_task_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mdd_trade`
--

DROP TABLE IF EXISTS `mdd_trade`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mdd_trade` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '编号',
  `uid` bigint(20) DEFAULT NULL COMMENT '用户编号',
  `subject` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '商品名称',
  `body` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '商品描述',
  `out_trade_no` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '商户订单号',
  `trade_no` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '第三方订单号',
  `total_amount` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '价格',
  `state` int(11) DEFAULT '1' COMMENT '订单状态:0=已支付,1=未支付,2=作废',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `cancel_time` timestamp NULL DEFAULT NULL COMMENT '作废时间',
  `success_time` timestamp NULL DEFAULT NULL COMMENT '支付成功时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='交易';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mdd_trade`
--

LOCK TABLES `mdd_trade` WRITE;
/*!40000 ALTER TABLE `mdd_trade` DISABLE KEYS */;
INSERT INTO `mdd_trade` VALUES (1,10062,'米币充值','米多多平台的米币','201907251606073717',NULL,'1',1,'2019-07-25 08:06:07',NULL,NULL),(2,10067,'米币充值','米多多平台的米币','201910031349558483',NULL,'50',1,'2019-10-03 05:49:55',NULL,NULL),(3,10060,'米币充值','米多多平台的米币','201910132020422779',NULL,'10',1,'2019-10-13 12:20:42',NULL,NULL),(4,10057,'米币充值','米多多平台的米币','201910141542244932',NULL,'1',1,'2019-10-14 07:42:24',NULL,NULL),(5,10060,'米币充值','米多多平台的米币','201910151329166322',NULL,'50',1,'2019-10-15 05:29:16',NULL,NULL),(6,10067,'米币充值','米多多平台的米币','201910181449027077',NULL,'20',1,'2019-10-18 06:49:02',NULL,NULL),(7,10067,'米币充值','米多多平台的米币','201910202309499728',NULL,'10',1,'2019-10-20 15:09:49',NULL,NULL),(8,10067,'米币充值','米多多平台的米币','201910202310474694',NULL,'10',1,'2019-10-20 15:10:47',NULL,NULL),(9,10067,'米币充值','米多多平台的米币','201910202311264358','2019102022001401210522626537','1',0,'2019-10-20 15:11:26',NULL,'2019-10-20 15:11:34'),(10,10060,'米币充值','米多多平台的米币','201910202313205320','2019102022001488780585601690','1',0,'2019-10-20 15:13:20',NULL,'2019-10-20 15:13:33'),(11,10070,'保证金充值','米多多平台的保证金','201910211434075835',NULL,'1000',1,'2019-10-21 06:34:07',NULL,NULL);
/*!40000 ALTER TABLE `mdd_trade` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mdd_user`
--

DROP TABLE IF EXISTS `mdd_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mdd_user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '用户编号',
  `pid` bigint(20) DEFAULT NULL COMMENT '上级编号',
  `pwd` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '密码',
  `phone` varchar(22) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '手机号',
  `nickname` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '昵称',
  `auth_state` tinyint(4) DEFAULT '0' COMMENT '认证状态:0=未认证,1=审核中,2=未通过,3=已认证',
  `name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '姓名',
  `head_img` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '头像',
  `id_card_number` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '身份证号',
  `id_card_positive_photo` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '身份证正面照片',
  `id_card_negative_photo` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '身份证背面照片',
  `id_card_hand_photo` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '手持身份证照片',
  `alipay_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '支付宝姓名',
  `alipay_number` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '支付宝号码',
  `wechat_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '微信号',
  `pay_pwd` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '支付密码',
  `invite_code` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '邀请码',
  `reg_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '注册时间',
  `state` tinyint(4) DEFAULT '1' COMMENT '状态:0=禁用,1=正常',
  `mi_coin` float DEFAULT '1000' COMMENT '米币',
  `income` float DEFAULT '0' COMMENT '收入',
  `rank` int(11) DEFAULT NULL COMMENT '等级',
  `is_top` tinyint(4) DEFAULT NULL COMMENT '是否置顶',
  `openid` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'openid',
  `earnest_money` float DEFAULT '0' COMMENT '保证金',
  `credit_score` int(11) DEFAULT '0' COMMENT '信用分',
  `grade` int(11) DEFAULT '1' COMMENT '级别:1=会员,2=队长',
  `top_expire_time` timestamp NULL DEFAULT NULL COMMENT '置顶到期时间',
  `advance_count` int(11) DEFAULT '0' COMMENT '提现次数',
  `total_advance_money` float DEFAULT '0' COMMENT '提现总额',
  `update_alipay_count` int(11) DEFAULT '0' COMMENT '修改支付宝次数',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`),
  CONSTRAINT `FK_PID` FOREIGN KEY (`pid`) REFERENCES `mdd_user` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=10071 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='用户';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mdd_user`
--

LOCK TABLES `mdd_user` WRITE;
/*!40000 ALTER TABLE `mdd_user` DISABLE KEYS */;
INSERT INTO `mdd_user` VALUES (10060,NULL,'93097f6a630bc8e863da4a38b845484e','13067081763','俗韵',0,NULL,'http://qiniuyun.shanhaijuhe.com/headimg.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-06-18 09:31:11',1,110208,1.06,NULL,NULL,NULL,0,0,1,NULL,0,0,0),(10067,10060,'2521f2472b143bbacfc82de5af6e2eb6','18302654751','士大夫',0,NULL,'headimg.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-10-03 05:18:32',1,1000,0.5,NULL,NULL,NULL,0,0,1,NULL,0,0,0),(10068,10060,'93097f6a630bc8e863da4a38b845484e','15080566661','英俊的人',0,NULL,'headimg.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-10-17 03:26:57',1,1000,0,NULL,NULL,NULL,0,0,1,NULL,0,0,0),(10069,10068,'93097f6a630bc8e863da4a38b845484e','13375906001','7',0,NULL,'headimg.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-10-17 03:28:04',1,1000,0,NULL,NULL,NULL,0,0,1,NULL,0,0,0),(10070,NULL,'93097f6a630bc8e863da4a38b845484e','13956935893','好好恢复',0,NULL,'headimg.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-10-21 06:31:36',1,1000,0,NULL,NULL,NULL,0,0,1,NULL,0,0,0);
/*!40000 ALTER TABLE `mdd_user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-11-12 18:29:26
