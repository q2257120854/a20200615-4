import request from '@/utils/request'

export function add(data) {
  return request({
    url: 'api/mdd/taskType/add',
    method: 'post',
    data
  })
}

export function del(id) {
  return request({
    url: 'api/mdd/taskType/del/' + id,
    method: 'post'
  })
}

export function edit(data) {
  return request({
    url: 'api/mdd/taskType/update',
    method: 'post',
    data
  })
}
