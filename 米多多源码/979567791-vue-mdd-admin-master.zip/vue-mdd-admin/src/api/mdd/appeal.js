import request from '@/utils/request'

export function add(data) {
  return request({
    url: 'api/mdd/appeal/add',
    method: 'post',
    data
  })
}

export function del(id) {
  return request({
    url: 'api/mdd/appeal/del/' + id,
    method: 'post'
  })
}

export function edit(data) {
  return request({
    url: 'api/mdd/appeal/update',
    method: 'post',
    data
  })
}
