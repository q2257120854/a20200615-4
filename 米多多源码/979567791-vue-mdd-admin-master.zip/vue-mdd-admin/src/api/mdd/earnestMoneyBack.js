import request from '@/utils/request'

export function add(data) {
  return request({
    url: 'api/mdd/earnestMoneyBack/add',
    method: 'post',
    data
  })
}

export function del(id) {
  return request({
    url: 'api/mdd/earnestMoneyBack/del/' + id,
    method: 'post'
  })
}

export function edit(data) {
  return request({
    url: 'api/mdd/earnestMoneyBack/update',
    method: 'post',
    data
  })
}

export function pass(id) {
  return request({
    url: 'api/mdd/earnestMoneyBack/pass/' + id,
    method: 'post'
  })
}

export function fail(id) {
  return request({
    url: 'api/mdd/earnestMoneyBack/fail/' + id,
    method: 'post'
  })
}
