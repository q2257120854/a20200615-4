import request from '@/utils/request'

export function add(data) {
  return request({
    url: 'api/mdd/user/add',
    method: 'post',
    data
  })
}

export function del(id) {
  return request({
    url: 'api/mdd/user/del/' + id,
    method: 'post'
  })
}

export function edit(data) {
  return request({
    url: 'api/mdd/user/update',
    method: 'post',
    data
  })
}
