import request from '@/utils/request'

export function add(data) {
  return request({
    url: 'api/mdd/task/add',
    method: 'post',
    data
  })
}

export function del(id) {
  return request({
    url: 'api/mdd/task/del/' + id,
    method: 'post'
  })
}

export function edit(data) {
  return request({
    url: 'api/mdd/task/update',
    method: 'post',
    data
  })
}

export function statistics() {
  return request({
    url: 'api/mdd/task/statistics',
    method: 'post'
  })
}

export function detail(id) {
  return request({
    url: 'api/mdd/task/detail/' + id,
    method: 'post'
  })
}

export function pass(id) {
  return request({
    url: 'api/mdd/task/pass/' + id,
    method: 'post'
  })
}

export function fail(id, reason) {
  return request({
    url: 'api/mdd/task/fail',
    method: 'get',
    params: { task_id: id, reason: reason }
  })
}

export function finish(task_id, uid) {
  return request({
    url: 'api/mdd/task/finish',
    method: 'get',
    params: { task_id: task_id, uid: uid }
  })
}
