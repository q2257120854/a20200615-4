import request from '@/utils/request'

export function list(task_id, uid) {
  return request({
    url: 'api/mdd/chat/list',
    method: 'get',
    params: { task_id: task_id, uid: uid }
  })
}
