import request from '@/utils/request'

export function add(data) {
  return request({
    url: 'api/jobs/add',
    method: 'post',
    data
  })
}

export function del(id) {
  return request({
    url: 'api/jobs/del/' + id,
    method: 'post'
  })
}

export function edit(data) {
  return request({
    url: 'api/jobs/update',
    method: 'post',
    data
  })
}

export function updateIsPause(id) {
  return request({
    url: 'api/jobs/updatepause/' + id,
    method: 'post'
  })
}

export function execution(id) {
  return request({
    url: 'api/jobs/exec/' + id,
    method: 'post'
  })
}
