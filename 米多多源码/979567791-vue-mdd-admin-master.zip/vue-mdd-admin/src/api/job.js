import request from '@/utils/request'

export function getAllJob(deptId) {
  const params = {
    deptId,
    page: 0,
    size: 9999
  }
  return request({
    url: 'api/job/query',
    method: 'get',
    params
  })
}

export function add(data) {
  return request({
    url: 'api/job/add',
    method: 'post',
    data
  })
}

export function del(id) {
  return request({
    url: 'api/job/del' + id,
    method: 'post'
  })
}

export function edit(data) {
  return request({
    url: 'api/job/update',
    method: 'post',
    data
  })
}
