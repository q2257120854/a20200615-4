import request from '@/utils/request'

// 支付
export function toWxPay(data) {
  return request({
    url: 'api/wxpay/pay',
    data,
    method: 'post'
  })
}
