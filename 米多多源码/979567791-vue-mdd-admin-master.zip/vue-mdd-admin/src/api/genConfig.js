import request from '@/utils/request'

export function get() {
  return request({
    url: 'api/genConfig/query',
    method: 'post'
  })
}

export function update(data) {
  return request({
    url: 'api/genConfig/update',
    data,
    method: 'post'
  })
}
