<template>
  <div>
    <el-button size="mini" type="success" @click="chatRecord">聊天记录</el-button>
    <el-dialog :append-to-body="true" :visible.sync="dialog" title="聊天记录" width="300px">
      <div v-if="chatlist.length !=0" class="exchange-info">
        <div class="hd">
          <ul class="desc">
            <li v-for="(item) in chatlist" :key="item.id">
              {{ item.direction === 0 ? '商家:' : '用户:' }}
              {{ item.content }}
              <div v-if="item.image_list != null && item.image_list.length != 0" class="img">
                <img v-for="(i,num) in item.image_list.split(',')" :key="num" :src="i" alt="">
              </div>
            </li>
          </ul>
        </div>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import { list } from '@/api/mdd/chat'
export default {
  props: {
    data: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      dialog: false, chatlist: []
    }
  },
  methods: {
    chatRecord() {
      list(this.data.task_id, this.data.uid).then(res => {
        this.chatlist = res
      })
      this.dialog = true
    }
  }
}
</script>

<style scoped>
  div{
    display: inline-block;
    margin-right: 3px;
  }
  img { width: 100%; height:auto; max-height: 360px; min-height:50px;}
</style>
