<template>
  <el-dialog :append-to-body="true" :visible.sync="dialog" :title="isAdd ? '新增' : '编辑'" width="500px">
    <el-form ref="form" :model="form" :rules="rules" size="small" label-width="80px">
      <el-form-item label="用户编号" prop="uid">
        <el-input v-model="form.uid" style="width: 370px;"/>
      </el-form-item>
      <el-form-item label="申诉的任务编号" prop="task_id">
        <el-input v-model="form.task_id" style="width: 370px;"/>
      </el-form-item>
      <el-form-item label="申诉内容" prop="content">
        <el-input v-model="form.content" style="width: 370px;"/>
      </el-form-item>
      <el-form-item label="添加时间" prop="add_time">
        <el-input v-model="form.add_time" style="width: 370px;"/>
      </el-form-item>
      <el-form-item label="是否解决" prop="is_solve">
        <el-input v-model="form.is_solve" style="width: 370px;"/>
      </el-form-item>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button type="text" @click="cancel">取消</el-button>
      <el-button :loading="loading" type="primary" @click="doSubmit">确认</el-button>
    </div>
  </el-dialog>
</template>

<script>
import { add, edit } from '@/api/mdd/appeal'
export default {
  props: {
    isAdd: {
      type: Boolean,
      required: true
    },
    sup_this: {
      type: Object,
      default: null
    }
  },
  data() {
    return {
      loading: false, dialog: false,
      rules: {
        id: [
          { required: true, message: '编号不能为空', trigger: 'blur' }
        ],
        uid: [
          { required: true, message: '用户编号不能为空', trigger: 'blur' }
        ],
        task_id: [
          { required: true, message: '申诉的任务编号不能为空', trigger: 'blur' }
        ],
        content: [
          { required: true, message: '申诉内容不能为空', trigger: 'blur' }
        ]
      },
      form: {
        id: '',
        uid: '',
        task_id: '',
        content: '',
        add_time: '',
        is_solve: ''
      }
    }
  },
  methods: {
    cancel() {
      this.resetForm()
    },
    doSubmit() {
      this.$refs['form'].validate((valid) => {
        if (valid) {
          this.loading = true
          if (this.isAdd) {
            this.doAdd()
          } else this.doEdit()
        } else {
          return false
        }
      })
    },
    doAdd() {
      add(this.form).then(res => {
        this.resetForm()
        this.$notify({
          title: '添加成功',
          type: 'success',
          duration: 2500
        })
        this.loading = false
        this.$parent.$parent.init()
      }).catch(err => {
        this.loading = false
        console.log(err.response.data.message)
      })
    },
    doEdit() {
      edit(this.form).then(res => {
        this.resetForm()
        this.$notify({
          title: '修改成功',
          type: 'success',
          duration: 2500
        })
        this.loading = false
        this.sup_this.init()
      }).catch(err => {
        this.loading = false
        console.log(err.response.data.message)
      })
    },
    resetForm() {
      this.dialog = false
      this.$refs['form'].resetFields()
      this.form = {
        id: '',
        uid: '',
        task_id: '',
        content: '',
        add_time: '',
        is_solve: ''
      }
    }
  }
}
</script>

<style scoped>

</style>
