<template>
  <el-dialog :append-to-body="true" :visible.sync="dialog" :title="isAdd ? '新增' : '编辑'" width="500px">
    <el-form ref="form" :model="form" :rules="rules" size="small" label-width="80px">
      <el-form-item label="服务费(百分比)" prop="service_charge">
        <el-input v-model="form.service_charge" style="width: 370px;"/>
      </el-form-item>
      <el-form-item label="名称" prop="name">
        <el-input v-model="form.name" style="width: 370px;"/>
      </el-form-item>
      <el-form-item label="保证金" prop="earnest_money">
        <el-input v-model="form.earnest_money" style="width: 370px;"/>
      </el-form-item>
      <el-form-item label="别名" prop="alias">
        <el-input v-model="form.alias" style="width: 370px;"/>
      </el-form-item>
      <el-form-item label="最低出价" prop="min_price">
        <el-input v-model="form.min_price" style="width: 370px;"/>
      </el-form-item>
      <el-form-item label="最低单数" prop="min_count">
        <el-input v-model="form.min_count" style="width: 370px;"/>
      </el-form-item>
      <el-form-item label="图标" prop="icon">
        <el-input v-model="form.icon" style="width: 370px;"/>
      </el-form-item>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button type="text" @click="cancel">取消</el-button>
      <el-button :loading="loading" type="primary" @click="doSubmit">确认</el-button>
    </div>
  </el-dialog>
</template>

<script>
import { add, edit } from '@/api/mdd/taskType'
export default {
  props: {
    isAdd: {
      type: Boolean,
      required: true
    },
    sup_this: {
      type: Object,
      default: null
    }
  },
  data() {
    return {
      loading: false, dialog: false,
      rules: {
        id: [
          { required: true, message: '任务类型编号不能为空', trigger: 'blur' }
        ],
        service_charge: [
          { required: true, message: '服务费(百分比)不能为空', trigger: 'blur' }
        ],
        name: [
          { required: true, message: '名称不能为空', trigger: 'blur' }
        ],
        earnest_money: [
          { required: true, message: '保证金不能为空', trigger: 'blur' }
        ],
        alias: [
          { required: true, message: '别名不能为空', trigger: 'blur' }
        ],
        min_price: [
          { required: true, message: '最低出价不能为空', trigger: 'blur' }
        ],
        min_count: [
          { required: true, message: '最低单数不能为空', trigger: 'blur' }
        ],
        icon: [
          { required: true, message: '图标不能为空', trigger: 'blur' }
        ]
      },
      form: {
        id: '',
        service_charge: '',
        name: '',
        earnest_money: '',
        alias: '',
        min_price: '',
        min_count: '',
        icon: ''
      }
    }
  },
  methods: {
    cancel() {
      this.resetForm()
    },
    doSubmit() {
      this.$refs['form'].validate((valid) => {
        if (valid) {
          this.loading = true
          if (this.isAdd) {
            this.doAdd()
          } else this.doEdit()
        } else {
          return false
        }
      })
    },
    doAdd() {
      add(this.form).then(res => {
        this.resetForm()
        this.$notify({
          title: '添加成功',
          type: 'success',
          duration: 2500
        })
        this.loading = false
        this.$parent.$parent.init()
      }).catch(err => {
        this.loading = false
        console.log(err.response.data.message)
      })
    },
    doEdit() {
      edit(this.form).then(res => {
        this.resetForm()
        this.$notify({
          title: '修改成功',
          type: 'success',
          duration: 2500
        })
        this.loading = false
        this.sup_this.init()
      }).catch(err => {
        this.loading = false
        console.log(err.response.data.message)
      })
    },
    resetForm() {
      this.dialog = false
      this.$refs['form'].resetFields()
      this.form = {
        id: '',
        service_charge: '',
        name: '',
        earnest_money: '',
        alias: '',
        min_price: '',
        min_count: '',
        icon: ''
      }
    }
  }
}
</script>

<style scoped>

</style>
