<template>
  <div class="app-container">
    <eHeader :query="query"/>
    <!--表格渲染-->
    <el-table v-loading="loading" :data="data" size="small" style="width: 100%;">
      <el-table-column prop="id" label="任务编号" width="100px"/>
      <!-- <el-table-column prop="task_type_id" label="任务类型编号"/> -->
      <el-table-column prop="uid" label="用户编号"/>
      <el-table-column prop="device" label="支持设备">
        <template slot-scope="scope">
          <div v-for="item in deviceDicts" :key="item.id">
            <el-tag v-if="scope.row.device.toString() === item.value">{{ item.label }}</el-tag>
          </div>
        </template>
      </el-table-column>
      <el-table-column prop="title" label="标题"/>
      <el-table-column prop="price" label="单价"/>
      <el-table-column prop="total_count" label="总数量"/>
      <el-table-column prop="residue_count" label="剩余数量"/>
      <el-table-column prop="balance" label="余额"/>
      <el-table-column prop="end_time" label="截止时间" width="150px">
        <template slot-scope="scope">
          <span>{{ parseTime(scope.row.end_time) }}</span>
        </template>
      </el-table-column>
      <el-table-column prop="add_time" label="发布时间" width="150px">
        <template slot-scope="scope">
          <span>{{ parseTime(scope.row.add_time) }}</span>
        </template>
      </el-table-column>
      <el-table-column prop="state" label="状态">
        <template slot-scope="scope">
          <div v-for="item in taskStateDicts" :key="item.id">
            <el-tag v-if="scope.row.state.toString() === item.value">{{ item.label }}</el-tag>
          </div>
        </template>
      </el-table-column>
      <el-table-column prop="top_expire_time" label="置顶到期时间" width="150px">
        <template slot-scope="scope">
          <span>{{ parseTime(scope.row.top_expire_time) }}</span>
        </template>
      </el-table-column>
      <el-table-column label="操作" width="230px" align="center">
        <template slot-scope="scope">
          <edit v-if="checkPermission(['ADMIN'])" :data="scope.row" :sup_this="sup_this"/>
          <el-popover
            v-if="checkPermission(['ADMIN'])"
            :ref="scope.row.id"
            placement="top"
            width="180">
            <p>确定删除本条数据吗？</p>
            <div style="text-align: right; margin: 0">
              <el-button size="mini" type="text" @click="$refs[scope.row.id].doClose()">取消</el-button>
              <el-button :loading="delLoading" type="primary" size="mini" @click="subDelete(scope.row.id)">确定</el-button>
            </div>
            <el-button slot="reference" type="danger" size="mini">删除</el-button>
          </el-popover>
          <el-button v-if="scope.row.state == 1" slot="reference" type="danger" size="mini" @click="check(scope.row.id)">审核</el-button>
        </template>
      </el-table-column>
    </el-table>
    <!--分页组件-->
    <el-pagination
      :total="total"
      style="margin-top: 8px;"
      layout="total, prev, pager, next, sizes"
      @size-change="sizeChange"
      @current-change="pageChange"/>
    <taskDetails ref="taskDetail"/>
  </div>
</template>

<script>
import checkPermission from '@/utils/permission'
import initData from '@/mixins/initData'
import { get } from '@/api/dictDetail'
import { del } from '@/api/mdd/task'
import { parseTime } from '@/utils/index'
import eHeader from './module/header'
import edit from './module/edit'
import taskDetails from './module/taskDetails'
export default {
  components: { eHeader, edit, taskDetails },
  mixins: [initData],
  data() {
    return {
      delLoading: false, sup_this: this, taskStateDicts: null, deviceDicts: null
    }
  },
  created() {
    this.$nextTick(() => {
      this.init()
      get('task_state').then(res => {
        this.taskStateDicts = res.content
      })
      get('device').then(res => {
        this.deviceDicts = res.content
      })
    })
  },
  methods: {
    parseTime,
    checkPermission,
    check(id) {
      this.$refs.taskDetail.open(id)
    },
    beforeInit() {
      this.url = 'api/mdd/task/query'
      const sort = 'id,desc'
      this.params = { page: this.page, size: this.size, sort: sort }
      const query = this.query
      const state = query.state
      const type = query.type
      const value = query.value
      if (type && value) { this.params[type] = value }
      if (state) { this.params['state'] = state }
      return true
    },
    subDelete(id) {
      this.delLoading = true
      del(id).then(res => {
        this.delLoading = false
        this.$refs[id].doClose()
        this.init()
        this.$notify({
          title: '删除成功',
          type: 'success',
          duration: 2500
        })
      }).catch(err => {
        this.delLoading = false
        this.$refs[id].doClose()
        console.log(err.response.data.message)
      })
    }
  }
}
</script>

<style scoped>

</style>
