<template>
  <div>
    <el-button size="mini" type="success" @click="to">编辑</el-button>
    <eForm ref="form" :sup_this="sup_this" :is-add="false"/>
  </div>
</template>
<script>
import eForm from './form'
export default {
  components: { eForm },
  props: {
    data: {
      type: Object,
      required: true
    },
    sup_this: {
      type: Object,
      required: true
    }
  },
  methods: {
    to() {
      const _this = this.$refs.form
      _this.form = {
        id: this.data.id,
        task_type_id: this.data.task_type_id,
        uid: this.data.uid,
        device: this.data.device,
        title: this.data.title,
        price: this.data.price,
        total_count: this.data.total_count,
        unsubmit_count: this.data.unsubmit_count,
        submit_count: this.data.submit_count,
        fail_count: this.data.fail_count,
        finish_count: this.data.finish_count,
        service_charge: this.data.service_charge,
        end_time: this.data.end_time,
        explain_img: this.data.explain_img,
        url: this.data.url,
        word_verify: this.data.word_verify,
        remark: this.data.remark,
        add_time: this.data.add_time,
        is_top: this.data.is_top,
        is_hot: this.data.is_hot,
        state: this.data.state,
        balance: this.data.balance,
        reject_reason: this.data.reject_reason,
        cancel_time: this.data.cancel_time,
        top_expire_time: this.data.top_expire_time,
        del_state: this.data.del_state,
        order_time_limit: this.data.order_time_limit,
        check_time_limit: this.data.check_time_limit
      }
      _this.dialog = true
    }
  }
}
</script>

<style scoped>
  div{
    display: inline-block;
    margin-right: 3px;
  }
</style>
