<template>
  <div id="taskdetails">
    <el-dialog :append-to-body="true" :visible.sync="checkDialog" title="审核" width="500px">
      <!-- 任务详情 -->
      <div class="scroll">
        <el-button slot="reference" type="success" size="mini" @click="pass()">通过</el-button>
        <el-button slot="reference" type="danger" size="mini" @click="fail()">不通过</el-button>
        <!-- 任务描述 -->
        <TaskDescribe :task-describe="taskDetails"/>
        <!-- 验证图 -->
        <div class="task-verification-img">
          <div class="hd">验证图<span class="font-red">共{{ explain_img.length }}张</span></div>
          <div class="bd">
            <div v-for="(item,idx) in explain_img" :key="idx">
              <img :src="item" alt="">
              <span>图 {{ idx+1 }}</span>
            </div>
          </div>
        </div>
        <!--  操作说明 -->
        <div class="task-run-book">
          <div class="borderT">
            <div class="hd">
              <div class="title_line"/>
              <div class="title_font">操作说明</div>
            </div>
            <ul class="bd">
              <li v-for="(item,idx) in taskDetails.step_list" :key="idx">
                <div class="desc">
                  <i>{{ idx +1 }}</i>
                  {{ item.description }}
                </div>
                <img :src="item.explain_img" alt="">
              </li>
            </ul>
          </div>
        </div>
      </div>
    </el-dialog>
    <el-dialog :append-to-body="true" :visible.sync="failDialog" title="不通过" width="500px">
      <el-form ref="failform" :model="failform" size="small" label-width="80px">
        <el-form-item label="拒绝原因">
          <el-input v-model="failform.reason" style="width: 370px;"/>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="doCheckFailSubmit()">确认</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>

// 任务描述
import TaskDescribe from '@/components/TaskDescribe'
import { detail, pass, fail } from '@/api/mdd/task'

export default {
  name: 'TaskDetails',
  components: {
    TaskDescribe
  },
  data() {
    return {
      tit: '任务详情',
      rulePopup: false,
      // status:1,
      taskDetails: {},
      explain_img: [],
      checkDialog: false,
      failDialog: false,
      task_id: null,
      failform: {
        reason: ''
      }
    }
  },
  created() {
  },
  methods: {
    open(id) {
      this.task_id = id
      this.checkDialog = true
      detail(id).then((response) => {
        this.taskDetails = response
        // 验证图
        this.explain_img = this.taskDetails.explain_img.split(',')
      })
    },
    fail() {
      this.failDialog = true
    },
    pass() {
      pass(this.task_id).then((response) => {
        this.checkDialog = false
        this.$parent.init()
      })
    },
    doCheckFailSubmit() {
      fail(this.task_id, this.failform.reason).then((response) => {
        this.failDialog = false
        this.$parent.init()
      })
    }
  }

}
</script>

<style lang="scss" scoped>

.scroll-wrapper {
  position: absolute; width: 100%; top: 38px; bottom: 48px;  overflow: hidden;
}

.task-verification-img {
  text-align: center; color: #333;
  .hd { line-height: 25px; }
  .bd {
  img { width:170px; border: 1Px solid #ccc;}
  span {display: block; line-height:30px; padding-bottom: 24px;}
  }
}

.task-run-book {
  .hd {
  padding-top: 20px; height:50px; background: #cecece; margin-top: -1px; text-align: center;position: relative;
  .title_line { width:82%; position: absolute; top: 30px; left: 9%; height:1Px; border-top: 1Px solid #878787;  border-bottom: 1Px solid #878787; background-color: #333;}
  .title_font {position: relative; z-index:3; left:26%; width: 48%; height:14px; background-color: #cecece; font-size: 14px; }
  }
  .bd {
  li{
    overflow: hidden;
    .desc {
    position: relative; background-color: #fff; padding: 14px 14px 14px 50px; line-height:22px;
    i { position: absolute; left: 14px; width:22px; height:22px; background-color: #30b1fc; color: #fff; text-align: center;  border-radius: 50%; }
    }
    img {
    display: block; margin: 12px auto; width:170px; border: 1Px solid #ccc;
    }
  }
  }
}

.footer_msg_wrap {
  padding:32px 0 16px; text-align: center;
  p { line-height:17px;
  a{ color: #56b1ff; }
  }
}
</style>
