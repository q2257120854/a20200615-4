<template>
  <div class="app-container">
    <eHeader :query="query"/>
    <!--表格渲染-->
    <el-table v-loading="loading" :data="data" style="width: 100%;" size="small" row-key="id">
      <el-table-column prop="id" label="用户编号" width="200px"/>
      <el-table-column prop="pid" label="上级编号"/>
      <el-table-column prop="phone" label="手机号"/>
      <el-table-column prop="nickname" label="昵称"/>
      <el-table-column prop="head_img" label="头像">
        <template slot-scope="scope">
          <img :src="scope.row.head_img" style="width: 36px; height: 36px" fit="fit">
        </template>
      </el-table-column>
      <el-table-column prop="alipay_name" label="支付宝姓名"/>
      <el-table-column prop="alipay_number" label="支付宝号码"/>
      <el-table-column prop="reg_time" label="注册时间">
        <template slot-scope="scope">
          <span>{{ parseTime(scope.row.reg_time) }}</span>
        </template>
      </el-table-column>
      <el-table-column prop="state" label="状态">
        <template slot-scope="scope">
          <div v-for="item in stateDicts" :key="item.id">
            <el-tag v-if="scope.row.state.toString() === item.value" :type="scope.row.state === 1 ? '' : 'info'">{{ item.label }}</el-tag>
          </div>
        </template>
      </el-table-column>
      <el-table-column prop="mi_coin" label="米币"/>
      <el-table-column prop="income" label="收入"/>
      <el-table-column prop="grade" label="级别">
        <template slot-scope="scope">
          <div v-for="item in gradeDicts" :key="item.id">
            <el-tag v-if="scope.row.grade.toString() === item.value">{{ item.label }}</el-tag>
          </div>
        </template>
      </el-table-column>
      <el-table-column prop="earnest_money" label="保证金"/>
      <el-table-column prop="top_expire_time" label="置顶到期时间">
        <template slot-scope="scope">
          <span>{{ parseTime(scope.row.top_expire_time) }}</span>
        </template>
      </el-table-column>
      <el-table-column prop="total_advance_money" label="提现总额"/>
      <el-table-column label="操作" width="150px" align="center">
        <template slot-scope="scope">
          <edit v-if="checkPermission(['ADMIN'])" :data="scope.row" :sup_this="sup_this"/>
          <el-popover
            v-if="checkPermission(['ADMIN'])"
            :ref="scope.row.id"
            placement="top"
            width="180">
            <p>确定删除本条数据吗？</p>
            <div style="text-align: right; margin: 0">
              <el-button size="mini" type="text" @click="$refs[scope.row.id].doClose()">取消</el-button>
              <el-button :loading="delLoading" type="primary" size="mini" @click="subDelete(scope.row.id)">确定</el-button>
            </div>
            <el-button slot="reference" type="danger" size="mini">删除</el-button>
          </el-popover>
        </template>
      </el-table-column>
    </el-table>
    <!--分页组件-->
    <el-pagination
      :total="total"
      style="margin-top: 8px;"
      layout="total, prev, pager, next, sizes"
      @size-change="sizeChange"
      @current-change="pageChange"/>
  </div>
</template>

<script>
import checkPermission from '@/utils/permission'
import initData from '@/mixins/initData'
import { get } from '@/api/dictDetail'
import { del } from '@/api/mdd/user'
import { parseTime } from '@/utils/index'
import eHeader from './module/header'
import edit from './module/edit'
export default {
  components: { eHeader, edit },
  mixins: [initData],
  data() {
    return {
      delLoading: false, sup_this: this, gradeDicts: null, stateDicts: null
    }
  },
  created() {
    this.$nextTick(() => {
      this.init()
      get('user_grade').then(res => {
        this.gradeDicts = res.content
      })
      get('user_state').then(res => {
        this.stateDicts = res.content
      })
    })
  },
  methods: {
    parseTime,
    checkPermission,
    beforeInit() {
      this.url = 'api/mdd/user/query'
      const sort = 'id,desc'
      this.params = { page: this.page, size: this.size, sort: sort }
      const query = this.query
      const type = query.type
      const value = query.value
      if (type && value) { this.params[type] = value }
      return true
    },
    subDelete(id) {
      this.delLoading = true
      del(id).then(res => {
        this.delLoading = false
        this.$refs[id].doClose()
        this.init()
        this.$notify({
          title: '删除成功',
          type: 'success',
          duration: 2500
        })
      }).catch(err => {
        this.delLoading = false
        this.$refs[id].doClose()
        console.log(err.response.data.message)
      })
    }
  }
}
</script>

<style scoped>

</style>
