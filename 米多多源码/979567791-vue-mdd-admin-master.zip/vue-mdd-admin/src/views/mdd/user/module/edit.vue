<template>
  <div>
    <el-button size="mini" type="success" @click="to">编辑</el-button>
    <eForm ref="form" :sup_this="sup_this" :is-add="false"/>
  </div>
</template>
<script>
import eForm from './form'
export default {
  components: { eForm },
  props: {
    data: {
      type: Object,
      required: true
    },
    sup_this: {
      type: Object,
      required: true
    }
  },
  methods: {
    to() {
      const _this = this.$refs.form
      _this.form = {
        id: this.data.id,
        pid: this.data.pid,
        pwd: this.data.pwd,
        phone: this.data.phone,
        nickname: this.data.nickname,
        auth_state: this.data.auth_state,
        name: this.data.name,
        head_img: this.data.head_img,
        id_card_number: this.data.id_card_number,
        id_card_positive_photo: this.data.id_card_positive_photo,
        id_card_negative_photo: this.data.id_card_negative_photo,
        id_card_hand_photo: this.data.id_card_hand_photo,
        alipay_name: this.data.alipay_name,
        alipay_number: this.data.alipay_number,
        wechat_number: this.data.wechat_number,
        pay_pwd: this.data.pay_pwd,
        invite_code: this.data.invite_code,
        reg_time: this.data.reg_time,
        state: this.data.state,
        mi_coin: this.data.mi_coin,
        income: this.data.income,
        rank: this.data.rank,
        is_top: this.data.is_top,
        openid: this.data.openid,
        earnest_money: this.data.earnest_money,
        credit_score: this.data.credit_score,
        grade: this.data.grade,
        top_expire_time: this.data.top_expire_time,
        advance_count: this.data.advance_count,
        total_advance_money: this.data.total_advance_money,
        update_alipay_count: this.data.update_alipay_count
      }
      _this.dialog = true
    }
  }
}
</script>

<style scoped>
  div{
    display: inline-block;
    margin-right: 3px;
  }
</style>
