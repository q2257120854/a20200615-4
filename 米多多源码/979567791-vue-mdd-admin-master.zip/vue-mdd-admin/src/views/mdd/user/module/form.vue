<template>
  <el-dialog :append-to-body="true" :visible.sync="dialog" :title="isAdd ? '新增' : '编辑'" width="500px">
    <el-form ref="form" :model="form" :rules="rules" size="small" label-width="80px">
      <el-form-item label="上级编号" prop="pid">
        <el-input v-model="form.pid" style="width: 370px;"/>
      </el-form-item>
      <el-form-item label="密码" prop="pwd">
        <el-input v-model="form.pwd" style="width: 370px;"/>
      </el-form-item>
      <el-form-item label="手机号" prop="phone">
        <el-input v-model="form.phone" style="width: 370px;"/>
      </el-form-item>
      <el-form-item label="昵称" prop="nickname">
        <el-input v-model="form.nickname" style="width: 370px;"/>
      </el-form-item>
      <el-form-item label="姓名" prop="name">
        <el-input v-model="form.name" style="width: 370px;"/>
      </el-form-item>
      <el-form-item label="头像" prop="head_img">
        <el-input v-model="form.head_img" style="width: 370px;"/>
      </el-form-item>
      <el-form-item label="支付宝姓名" prop="alipay_name">
        <el-input v-model="form.alipay_name" style="width: 370px;"/>
      </el-form-item>
      <el-form-item label="支付宝号码" prop="alipay_number">
        <el-input v-model="form.alipay_number" style="width: 370px;"/>
      </el-form-item>
      <el-form-item label="注册时间" prop="reg_time">
        <el-input v-model="form.reg_time" style="width: 370px;"/>
      </el-form-item>
      <el-form-item label="状态:0=禁用,1=正常" prop="state">
        <el-input v-model="form.state" style="width: 370px;"/>
      </el-form-item>
      <el-form-item label="米币" prop="mi_coin">
        <el-input v-model="form.mi_coin" style="width: 370px;"/>
      </el-form-item>
      <el-form-item label="收入" prop="income">
        <el-input v-model="form.income" style="width: 370px;"/>
      </el-form-item>
      <el-form-item label="等级" prop="rank">
        <el-input v-model="form.rank" style="width: 370px;"/>
      </el-form-item>
      <el-form-item label="是否置顶" prop="is_top">
        <el-input v-model="form.is_top" style="width: 370px;"/>
      </el-form-item>
      <el-form-item label="保证金" prop="earnest_money">
        <el-input v-model="form.earnest_money" style="width: 370px;"/>
      </el-form-item>
      <el-form-item label="级别:1=会员,2=队长" prop="grade">
        <el-input v-model="form.grade" style="width: 370px;"/>
      </el-form-item>
      <el-form-item label="置顶到期时间" prop="top_expire_time">
        <el-input v-model="form.top_expire_time" style="width: 370px;"/>
      </el-form-item>
      <el-form-item label="提现次数" prop="advance_count">
        <el-input v-model="form.advance_count" style="width: 370px;"/>
      </el-form-item>
      <el-form-item label="提现总额" prop="total_advance_money">
        <el-input v-model="form.total_advance_money" style="width: 370px;"/>
      </el-form-item>
      <el-form-item label="修改支付宝次数" prop="update_alipay_count">
        <el-input v-model="form.update_alipay_count" style="width: 370px;"/>
      </el-form-item>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button type="text" @click="cancel">取消</el-button>
      <el-button :loading="loading" type="primary" @click="doSubmit">确认</el-button>
    </div>
  </el-dialog>
</template>

<script>
import { add, edit } from '@/api/mdd/user'
export default {
  props: {
    isAdd: {
      type: Boolean,
      required: true
    },
    sup_this: {
      type: Object,
      default: null
    }
  },
  data() {
    return {
      loading: false, dialog: false,
      rules: {
      },
      form: {
        id: '',
        pid: '',
        pwd: '',
        phone: '',
        nickname: '',
        auth_state: '',
        name: '',
        head_img: '',
        id_card_number: '',
        id_card_positive_photo: '',
        id_card_negative_photo: '',
        id_card_hand_photo: '',
        alipay_name: '',
        alipay_number: '',
        wechat_number: '',
        pay_pwd: '',
        invite_code: '',
        reg_time: '',
        state: '',
        mi_coin: '',
        income: '',
        rank: '',
        is_top: '',
        openid: '',
        earnest_money: '',
        credit_score: '',
        grade: '',
        top_expire_time: '',
        advance_count: '',
        total_advance_money: '',
        update_alipay_count: ''
      }
    }
  },
  methods: {
    cancel() {
      this.resetForm()
    },
    doSubmit() {
      this.$refs['form'].validate((valid) => {
        if (valid) {
          this.loading = true
          if (this.isAdd) {
            this.doAdd()
          } else this.doEdit()
        } else {
          return false
        }
      })
    },
    doAdd() {
      add(this.form).then(res => {
        this.resetForm()
        this.$notify({
          title: '添加成功',
          type: 'success',
          duration: 2500
        })
        this.loading = false
        this.$parent.$parent.init()
      }).catch(err => {
        this.loading = false
        console.log(err.response.data.message)
      })
    },
    doEdit() {
      edit(this.form).then(res => {
        this.resetForm()
        this.$notify({
          title: '修改成功',
          type: 'success',
          duration: 2500
        })
        this.loading = false
        this.sup_this.init()
      }).catch(err => {
        this.loading = false
        console.log(err.response.data.message)
      })
    },
    resetForm() {
      this.dialog = false
      this.$refs['form'].resetFields()
      this.form = {
        id: '',
        pid: '',
        pwd: '',
        phone: '',
        nickname: '',
        auth_state: '',
        name: '',
        head_img: '',
        id_card_number: '',
        id_card_positive_photo: '',
        id_card_negative_photo: '',
        id_card_hand_photo: '',
        alipay_name: '',
        alipay_number: '',
        wechat_number: '',
        pay_pwd: '',
        invite_code: '',
        reg_time: '',
        state: '',
        mi_coin: '',
        income: '',
        rank: '',
        is_top: '',
        openid: '',
        earnest_money: '',
        credit_score: '',
        grade: '',
        top_expire_time: '',
        advance_count: '',
        total_advance_money: '',
        update_alipay_count: ''
      }
    }
  }
}
</script>

<style scoped>

</style>
