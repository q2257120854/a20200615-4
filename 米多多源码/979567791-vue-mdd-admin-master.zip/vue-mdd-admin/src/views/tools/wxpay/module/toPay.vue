<template>
  <div>
    <el-form ref="form" :model="form" :rules="rules" style="margin-top: 6px;" size="small" label-width="190px">
      <el-form-item label="公众号的APPID" prop="appid">
        <el-input v-model="form.appid" style="width: 35%"/>
        <span style="color: #C0C0C0;margin-left: 10px;">请正确输入获取用户OpenID时使用的公众号APPID，以保证付款目标用户的准确性</span>
      </el-form-item>
      <el-form-item label="收款用户OpenID" prop="openid">
        <el-input v-model="form.openid" style="width: 35%"/>
        <span style="color: #C0C0C0;margin-left: 10px;">只支持向账户类型为个人的用户付款，请输入对应公众号APPID所获取的用户OpenID</span>
      </el-form-item>
      <el-form-item label="付款金额（元）" prop="amount">
        <el-input v-model="form.amount" style="width: 35%"/>
        <span style="color: #C0C0C0;margin-left: 10px;">支持小数点后两位</span>
      </el-form-item>
      <el-form-item label="付款说明" prop="transnote">
        <el-input v-model="form.transnote" style="width: 35%" rows="8" type="textarea"/>
      </el-form-item>
      <el-button :loading="loading" style="margin-left:2%;" size="medium" type="success" @click="doSubmit">付款</el-button>
    </el-form>
  </div>
</template>

<script>
import { toWxPay } from '@/api/wxpay'
export default {
  data() {
    return {
      url: '',
      // 新窗口的引用
      newWin: null,
      loading: false, form: { appid: 'wx078e72794fbfc50c', openid: 'oeJKG1LG3fWH-fxmwuSGd3fMrC_c', amount: '1', transnote: '转账说明' },
      rules: {
        appid: [
          { required: true, message: '公众号的APPID不能为空', trigger: 'blur' }
        ],
        openid: [
          { required: true, message: '收款用户OpenID不能为空', trigger: 'blur' }
        ],
        amount: [
          { required: true, message: '付款金额不能为空', trigger: 'blur' }
        ],
        transnote: [
          { required: true, message: '付款说明不能为空', trigger: 'blur' }
        ]
      }
    }
  },
  watch: {
    url(newVal, oldVal) {
      if (newVal && this.newWin) {
        this.newWin.sessionStorage.clear()
        this.newWin.location.href = newVal
        // 重定向后把url和newWin重置
        this.url = ''
        this.newWin = null
      }
    }
  },
  methods: {
    doSubmit() {
      this.$refs['form'].validate((valid) => {
        if (valid) {
          this.loading = true
          const tempData = Object.assign({}, this.form)
          tempData.amount = this.form.amount * 100
          toWxPay(tempData).then(res => {
            this.loading = false
          }).catch(err => {
            this.loading = false
            console.log(err.response.data.message)
          })
        } else {
          return false
        }
      })
    }
  }
}
</script>

<style scoped>
</style>
