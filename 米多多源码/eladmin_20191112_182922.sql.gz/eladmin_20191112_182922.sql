-- MySQL dump 10.13  Distrib 5.7.26, for Linux (x86_64)
--
-- Host: localhost    Database: eladmin
-- ------------------------------------------------------
-- Server version	5.7.26-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `alipay_config`
--

DROP TABLE IF EXISTS `alipay_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alipay_config` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `app_id` varchar(255) DEFAULT NULL COMMENT '应用ID',
  `charset` varchar(255) DEFAULT NULL COMMENT '编码',
  `format` varchar(255) DEFAULT NULL COMMENT '类型 固定格式json',
  `gateway_url` varchar(255) DEFAULT NULL COMMENT '网关地址',
  `notify_url` varchar(255) DEFAULT NULL COMMENT '异步回调',
  `private_key` text COMMENT '私钥',
  `public_key` text COMMENT '公钥',
  `return_url` varchar(255) DEFAULT NULL COMMENT '回调地址',
  `sign_type` varchar(255) DEFAULT NULL COMMENT '签名方式',
  `sys_service_provider_id` varchar(255) DEFAULT NULL COMMENT '商户号',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alipay_config`
--

LOCK TABLES `alipay_config` WRITE;
/*!40000 ALTER TABLE `alipay_config` DISABLE KEYS */;
INSERT INTO `alipay_config` VALUES (1,'2019082766430825','utf-8','JSON','https://openapi.alipay.com/gateway.do','http://adminapi.shanhaijuhe.com/api/aliPay/notify','MIIEvAIBADANBgkqhkiG9w0BAQEFAASCBKYwggSiAgEAAoIBAQCNq9InEHbppQhwyqf8SZmDVWO5c0BMyT5qstMXGZzcePkJ9NOxBmEdums6qZNRBKD13qKEldgkTnCcVg8exXb4AIsXZi7CLn4mN10OC3wsVIv837wWx8TWrJImvPK+lqa6B9y6SImBW/qhYIvvEdWWZ6DD7sgekzYIJzM72ka/guo/2/epq3y82RFgT+S8nXuDvp4TOUgUsXAhvYvCmtfBw0SzXhlxc7PEc8Tmiw4LCWAwu9cKHrcXRQn1FgFkCKzYwunhzwfOKAPK7oTq/YJzWsgPwCa4TRl0DzsMver63Pp8gTubHBuHXtoY/NYN+zGZE22f61Id+Plr7iiZVRg1AgMBAAECggEAN9dJ9mve8ylBsnOu0xqPj9zQegCbj6ijGZty6OAHnD9yqiH+bwB8tyMLsQu2LXENoNwoYupNT8I7UOP7Ab4Drq1IJej49UEuKBIac7bDMxYAN6RYlwIW7CcJVIuVgtoOzbTbo/GDgaGnoIRVo937ulUOYSx1ZNfRrFUHNMhMqp9xJpD/VYfEraOhoIR86kSg02BxpS2HRaSvnahXl33e8ZRTeuutHaXd85eCpBTfPptqkf7kQjGeAbLdGXX+amdBc9S/O5UXjkxfqaXPvjl10APtAFqofqg+2Y2OsyIVZ7koRmwD9Cvi4MJH9AosISGzfH/sKMcmGyMO10lwFVye4QKBgQDJjc05pauECjjGnNUKAsyXsPIUS0LG5cG/zxpKdDPhfNLJW0MJk9SNRDuBAao9hq8hmcHweXGpRdgVBan9O2b0BOF6kwiylA4y/XApdbRF79bq9t9ed3JQ986/Z70QOcBwSzi7UksRuS5OnHIz2VpdGGILxj1Ix4GshbfGL/BnFwKBgQCz8OgS3IbOtEm5UferP6C8QwyMQyywZ1hyYXa55SQ481OIl3XCeU0O8JY7N36NQHYPha2mLYQQPjDz3JoAMNIf8TuMKbUZBMjjsPouYuF/BCv4U93rcPieIZblt2ON/e9FJHnzAMBRvzvLuJ2o1R2Sy9FnyhudVWx/nb8SbbUKkwKBgBBtAwWor8KyBpCBJYeMVNoj7Iak34tQHCsimLTqpXPB9Xe9fUghiRf+MI9B8HrVKB6n5jtP2mh+La8A6CqgFbLbVvjjVLkhAcs8BlEKq6drdWtutSOAvotEts+4h5rz6e/84WG6wi1ulwyHCXOaShf+Lbdh74qn37SMrT50l7X/AoGAMOfE63tsWDm/39JbUfvVH9XJT0Xim387FrtOnW+dzKy1g2ZG5zg4rVrOOgH3L0TZ0ZYvf/7W6eM9QsouQOcD9RKHcKzVP5uBTgEHvhu51d+4Y6HHqvnlWHUgogaZ1Dm0EkK7skP+ATnMcq4Wi5CAnSkwHNldcAGLn5OsHsIadmkCgYB8bcb4NwlNcOXueERSa0HuNPN33wrvlOdYWqTmw1NJENbCG02gbkL7EX+5h+u4mWpswUMseHB5uE3vk2Ea0MqqdQ1FPAQ0En2GS+9iq70XusnFTsaJiN89KWs9xCNLQdN4fGKuw/+WMURfIm0QXqoRkyxVA9FwIPTX21fUE1JRSw==','MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAta59EUzmvEHfI3uOTIIlzE/RmHPwy6d0wqd6TrzMjCnJlZcRiGeWUNGnqj/WZQQ5/jNyb4jTXdl1GmPXFxdI3sRhWVhd5kNJooQ+z4Xwb7Z9HO9z/m0RKFDxSnhcjEYcUMHvZ+dC7/XJrjgpvzbzkEcQxmCLUYG+b/ZLMvV1P/a97duTjw7qAmCinsqdJ7AJrrox68ozy+EulRPEFapl4A/dEJnPmmb3Wa6buQFDQajsZ0kEf6XtlS+5espSiryymJ4gChZquMBvXidR15zeJwr5XSWZIQol5OP9vpsrBATn8RSxUE7Aoh24X1n6pvofplBtEOdC5avlYNLpq1KfdQIDAQAB','http://app.shanhaijuhe.com/buysucceed','RSA2','2088631145223445');
/*!40000 ALTER TABLE `alipay_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dept`
--

DROP TABLE IF EXISTS `dept`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dept` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `name` varchar(255) NOT NULL COMMENT '名称',
  `pid` bigint(20) NOT NULL COMMENT '上级部门',
  `create_time` datetime DEFAULT NULL,
  `enabled` bit(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dept`
--

LOCK TABLES `dept` WRITE;
/*!40000 ALTER TABLE `dept` DISABLE KEYS */;
INSERT INTO `dept` VALUES (1,'eladmin',0,'2019-03-25 09:14:05',_binary ''),(2,'研发部',7,'2019-03-25 09:15:32',_binary ''),(5,'运维部',7,'2019-03-25 09:20:44',_binary ''),(6,'测试部',8,'2019-03-25 09:52:18',_binary ''),(7,'华南分部',1,'2019-03-25 11:04:50',_binary ''),(8,'华北分部',1,'2019-03-25 11:04:53',_binary ''),(9,'财务部',7,'2019-03-25 11:05:34',_binary ''),(10,'行政部',8,'2019-03-25 11:05:58',_binary ''),(11,'人事部',8,'2019-03-25 11:07:58',_binary ''),(12,'市场部',7,'2019-03-25 11:10:24',_binary '\0');
/*!40000 ALTER TABLE `dept` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dict`
--

DROP TABLE IF EXISTS `dict`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dict` (
  `id` bigint(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL COMMENT '字典名称',
  `remark` varchar(255) DEFAULT NULL COMMENT '描述',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dict`
--

LOCK TABLES `dict` WRITE;
/*!40000 ALTER TABLE `dict` DISABLE KEYS */;
INSERT INTO `dict` VALUES (1,'user_status','用户状态'),(4,'dept_status','部门状态'),(5,'job_status','岗位状态'),(6,'task_state','任务状态'),(7,'enable_state','是否启用'),(8,'device','设备'),(9,'user_grade','会员级别'),(10,'user_state','会员状态');
/*!40000 ALTER TABLE `dict` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dict_detail`
--

DROP TABLE IF EXISTS `dict_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dict_detail` (
  `id` bigint(11) NOT NULL AUTO_INCREMENT,
  `label` varchar(255) NOT NULL COMMENT '字典标签',
  `value` varchar(255) NOT NULL COMMENT '字典值',
  `sort` varchar(255) DEFAULT NULL COMMENT '排序',
  `dict_id` bigint(11) DEFAULT NULL COMMENT '字典id',
  PRIMARY KEY (`id`),
  KEY `FK5tpkputc6d9nboxojdbgnpmyb` (`dict_id`),
  CONSTRAINT `FK5tpkputc6d9nboxojdbgnpmyb` FOREIGN KEY (`dict_id`) REFERENCES `dict` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dict_detail`
--

LOCK TABLES `dict_detail` WRITE;
/*!40000 ALTER TABLE `dict_detail` DISABLE KEYS */;
INSERT INTO `dict_detail` VALUES (1,'正常','true','1',1),(2,'禁用','false','2',1),(11,'正常','true','1',4),(12,'停用','false','2',4),(13,'正常','true','1',5),(14,'停用','false','2',5),(15,'启用','1','1',7),(16,'禁用','0','2',7),(17,'待审核','1','999',6),(18,'未通过','2','999',6),(19,'进行中','3','999',6),(20,'已暂停','4','999',6),(21,'已结束','5','999',6),(22,'全部','0','999',8),(23,'安卓','1','999',8),(24,'苹果','2','999',8),(25,'会员','1','999',9),(26,'队长','2','999',9),(27,'禁用','0','999',10),(28,'正常','1','999',10);
/*!40000 ALTER TABLE `dict_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_config`
--

DROP TABLE IF EXISTS `email_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `email_config` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `from_user` varchar(255) DEFAULT NULL COMMENT '收件人',
  `host` varchar(255) DEFAULT NULL COMMENT '邮件服务器SMTP地址',
  `pass` varchar(255) DEFAULT NULL COMMENT '密码',
  `port` varchar(255) DEFAULT NULL COMMENT '端口',
  `user` varchar(255) DEFAULT NULL COMMENT '发件者用户名',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_config`
--

LOCK TABLES `email_config` WRITE;
/*!40000 ALTER TABLE `email_config` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gen_config`
--

DROP TABLE IF EXISTS `gen_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gen_config` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `author` varchar(255) DEFAULT NULL COMMENT '作者',
  `cover` bit(1) DEFAULT NULL COMMENT '是否覆盖',
  `module_name` varchar(255) DEFAULT NULL COMMENT '模块名称',
  `pack` varchar(255) DEFAULT NULL COMMENT '至于哪个包下',
  `path` varchar(255) DEFAULT NULL COMMENT '前端代码生成的路径',
  `api_path` varchar(255) DEFAULT NULL,
  `data_source` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gen_config`
--

LOCK TABLES `gen_config` WRITE;
/*!40000 ALTER TABLE `gen_config` DISABLE KEYS */;
INSERT INTO `gen_config` VALUES (1,'jie1',_binary '','eladmin-system1','com.peng.mdd','E:\\workspace\\me\\eladmin-qt\\src\\views\\system\\dictDetail1','E:\\workspace\\me\\eladmin-qt\\src\\api1','mdd');
/*!40000 ALTER TABLE `gen_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job`
--

DROP TABLE IF EXISTS `job`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `enabled` bit(1) NOT NULL,
  `create_time` datetime DEFAULT NULL,
  `sort` bigint(20) NOT NULL,
  `dept_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKmvhj0rogastlctflsxf1d6k3i` (`dept_id`),
  CONSTRAINT `FKmvhj0rogastlctflsxf1d6k3i` FOREIGN KEY (`dept_id`) REFERENCES `dept` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job`
--

LOCK TABLES `job` WRITE;
/*!40000 ALTER TABLE `job` DISABLE KEYS */;
INSERT INTO `job` VALUES (2,'董事长秘书',_binary '','2019-03-29 14:01:30',2,1),(8,'人事专员',_binary '','2019-03-29 14:52:28',3,11),(10,'产品经理',_binary '\0','2019-03-29 14:55:51',4,2),(11,'全栈开发',_binary '','2019-03-31 13:39:30',6,2),(12,'软件测试',_binary '','2019-03-31 13:39:43',5,2),(19,'董事长',_binary '','2019-03-31 14:58:15',1,1);
/*!40000 ALTER TABLE `job` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log`
--

DROP TABLE IF EXISTS `log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `create_time` datetime DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `exception_detail` text,
  `log_type` varchar(255) DEFAULT NULL,
  `method` varchar(255) DEFAULT NULL,
  `params` text,
  `request_ip` varchar(255) DEFAULT NULL,
  `time` bigint(20) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log`
--

LOCK TABLES `log` WRITE;
/*!40000 ALTER TABLE `log` DISABLE KEYS */;
/*!40000 ALTER TABLE `log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu`
--

DROP TABLE IF EXISTS `menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menu` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `create_time` datetime DEFAULT NULL COMMENT '创建日期',
  `i_frame` bit(1) DEFAULT NULL COMMENT '是否外链',
  `name` varchar(255) DEFAULT NULL COMMENT '菜单名称',
  `component` varchar(255) DEFAULT NULL COMMENT '组件',
  `pid` bigint(20) NOT NULL COMMENT '上级菜单ID',
  `sort` bigint(20) NOT NULL COMMENT '排序',
  `icon` varchar(255) DEFAULT NULL COMMENT '图标',
  `path` varchar(255) DEFAULT NULL COMMENT '链接地址',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu`
--

LOCK TABLES `menu` WRITE;
/*!40000 ALTER TABLE `menu` DISABLE KEYS */;
INSERT INTO `menu` VALUES (1,'2018-12-18 15:11:29',_binary '\0','系统管理',NULL,0,50,'system','system'),(2,'2018-12-18 15:14:44',_binary '\0','用户管理','system/user/index',1,2,'peoples','user'),(3,'2018-12-18 15:16:07',_binary '\0','角色管理','system/role/index',1,3,'role','role'),(4,'2018-12-18 15:16:45',_binary '\0','权限管理','system/permission/index',1,4,'permission','permission'),(5,'2018-12-18 15:17:28',_binary '\0','菜单管理','system/menu/index',1,5,'menu','menu'),(6,'2018-12-18 15:17:48',_binary '\0','系统监控',NULL,0,100,'monitor','monitor'),(7,'2018-12-18 15:18:26',_binary '\0','操作日志','monitor/log/index',6,11,'log','logs'),(8,'2018-12-18 15:19:01',_binary '\0','系统缓存','monitor/redis/index',6,13,'redis','redis'),(9,'2018-12-18 15:19:34',_binary '\0','SQL监控','monitor/sql/index',6,14,'sqlMonitor','druid'),(10,'2018-12-19 13:38:16',_binary '\0','组件管理',NULL,0,200,'zujian','components'),(11,'2018-12-19 13:38:49',_binary '\0','图标库','components/IconSelect',10,51,'icon','icon'),(12,'2018-12-24 20:37:35',_binary '\0','实时控制台','monitor/log/msg',6,16,'codeConsole','msg'),(14,'2018-12-27 10:13:09',_binary '\0','邮件工具','tools/email/index',36,24,'email','email'),(15,'2018-12-27 11:58:25',_binary '\0','富文本','components/Editor',10,52,'fwb','tinymce'),(16,'2018-12-28 09:36:53',_binary '\0','图床管理','tools/picture/index',36,25,'image','pictures'),(18,'2018-12-31 11:12:15',_binary '\0','七牛云存储','tools/qiniu/index',36,26,'qiniu','qiniu'),(19,'2018-12-31 14:52:38',_binary '\0','支付宝工具','tools/aliPay/index',36,27,'alipay','aliPay'),(28,'2019-01-07 20:34:40',_binary '\0','定时任务','system/timing/index',36,21,'timing','timing'),(30,'2019-01-11 15:45:55',_binary '\0','代码生成','generator/index',36,22,'dev','generator'),(32,'2019-01-13 13:49:03',_binary '\0','异常日志','monitor/log/errorLog',6,12,'error','errorLog'),(33,'2019-03-08 13:46:44',_binary '\0','Markdown','components/MarkDown',10,53,'markdown','markdown'),(34,'2019-03-08 15:49:40',_binary '\0','Yaml编辑器','components/YamlEdit',10,54,'dev','yaml'),(36,'2019-03-29 10:57:35',_binary '\0','系统工具','',0,90,'sys-tools','sys-tools'),(38,'2019-03-29 19:57:53',_binary '\0','接口文档','tools/swagger/index',36,23,'swagger','swagger2'),(39,'2019-04-10 11:49:04',_binary '\0','字典管理','system/dict/index',1,8,'dictionary','dict'),(45,'2019-04-25 15:51:56',_binary '\0','微信付款到零钱','tools/wxpay/index',36,999,'develop','wxpay'),(46,'2019-05-13 10:54:29',_binary '\0','会员管理','mdd/user/index',0,0,'peoples','mdduser'),(47,'2019-05-13 15:52:59',_binary '\0','任务管理','',0,10,'monitor','taskmanage'),(48,'2019-05-13 16:03:53',_binary '\0','任务类型管理','mdd/tasktype/index',47,0,'','tasktype'),(49,'2019-05-13 16:04:55',_binary '\0','任务列表','mdd/task/index',47,0,'','task'),(51,'2019-05-13 16:22:40',_binary '\0','系统配置','',0,20,'tools','mddconfig'),(52,'2019-05-13 17:07:28',_binary '\0','轮播图管理','mdd/banner/index',51,0,'','banner'),(53,'2019-05-13 19:33:05',_binary '\0','公告管理','mdd/notice/index',51,0,'','notice'),(54,'2019-05-13 19:34:06',_binary '\0','参数配置','mdd/config/index',51,0,'','mddconfig'),(55,'2019-06-05 11:15:33',_binary '\0','财务管理','',0,30,'anq','finance'),(56,'2019-06-05 11:19:58',_binary '\0','保证金审核','mdd/earnestmoneycheck/index',55,31,'','earnestmoneycheck'),(57,'2019-06-14 10:45:52',_binary '\0','用户意见','',0,40,'anq','opinion'),(58,'2019-06-14 10:48:13',_binary '\0','举报','mdd/report/index',57,1,'','report'),(59,'2019-06-14 10:48:58',_binary '\0','投诉','mdd/complain/index',57,2,'','complain'),(60,'2019-06-14 10:49:45',_binary '\0','申诉','mdd/appeal/index',57,999,'','appeal'),(61,'2019-06-17 16:16:04',_binary '\0','邀请码','mdd/invitecode/index',51,999,'','invitecode');
/*!40000 ALTER TABLE `menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permission`
--

DROP TABLE IF EXISTS `permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permission` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `alias` varchar(255) DEFAULT NULL COMMENT '别名',
  `create_time` datetime DEFAULT NULL COMMENT '创建日期',
  `name` varchar(255) DEFAULT NULL COMMENT '名称',
  `pid` int(11) NOT NULL COMMENT '上级权限',
  `action_key` varchar(512) DEFAULT NULL COMMENT '请求url',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permission`
--

LOCK TABLES `permission` WRITE;
/*!40000 ALTER TABLE `permission` DISABLE KEYS */;
INSERT INTO `permission` VALUES (1,'超级管理员','2018-12-03 12:27:48','ADMIN',0,NULL),(2,'用户管理','2018-12-03 12:28:19','USER_ALL',0,NULL),(3,'用户查询','2018-12-03 12:31:35','USER_SELECT',2,'/api/users/query'),(4,'用户创建','2018-12-03 12:31:35','USER_CREATE',2,'/api/users/add'),(5,'用户编辑','2018-12-03 12:31:35','USER_EDIT',2,'/api/users/update'),(6,'用户删除','2018-12-03 12:31:35','USER_DELETE',2,'/api/users/del'),(7,'角色管理','2018-12-03 12:28:19','ROLES_ALL',0,NULL),(8,'角色查询','2018-12-03 12:31:35','ROLES_SELECT',7,'/api/roles/query'),(10,'角色创建','2018-12-09 20:10:16','ROLES_CREATE',7,'/api/roles/add'),(11,'角色编辑','2018-12-09 20:10:42','ROLES_EDIT',7,'/api/roles/update'),(12,'角色删除','2018-12-09 20:11:07','ROLES_DELETE',7,'/api/roles/del'),(13,'权限管理','2018-12-09 20:11:37','PERMISSION_ALL',0,NULL),(14,'权限查询','2018-12-09 20:11:55','PERMISSION_SELECT',13,'/api/permissions/query'),(15,'权限创建','2018-12-09 20:14:10','PERMISSION_CREATE',13,'/api/permissions/add'),(16,'权限编辑','2018-12-09 20:15:44','PERMISSION_EDIT',13,'/api/permissions/update'),(17,'权限删除','2018-12-09 20:15:59','PERMISSION_DELETE',13,'/api/permissions/del'),(18,'缓存管理','2018-12-17 13:53:25','REDIS_ALL',0,NULL),(19,'新增缓存','2018-12-17 13:53:44','REDIS_CREATE',18,NULL),(20,'缓存查询','2018-12-17 13:54:07','REDIS_SELECT',18,NULL),(21,'缓存编辑','2018-12-17 13:54:26','REDIS_EDIT',18,NULL),(22,'缓存删除','2018-12-17 13:55:04','REDIS_DELETE',18,'/api/users/del'),(23,'图床管理','2018-12-27 20:31:49','PICTURE_ALL',0,NULL),(24,'查询图片','2018-12-27 20:32:04','PICTURE_SELECT',23,NULL),(25,'上传图片','2018-12-27 20:32:24','PICTURE_UPLOAD',23,NULL),(26,'删除图片','2018-12-27 20:32:45','PICTURE_DELETE',23,NULL),(29,'菜单管理','2018-12-28 17:34:31','MENU_ALL',0,NULL),(30,'菜单查询','2018-12-28 17:34:41','MENU_SELECT',29,'/api/menus/query'),(31,'菜单创建','2018-12-28 17:34:52','MENU_CREATE',29,'/api/menus/add'),(32,'菜单编辑','2018-12-28 17:35:20','MENU_EDIT',29,'/api/menus/update'),(33,'菜单删除','2018-12-28 17:35:29','MENU_DELETE',29,'/api/menus/del'),(34,'返回全部菜单','2018-12-28 17:34:41','',29,'/api/menus/tree'),(35,'定时任务管理','2019-01-08 14:59:57','JOB_ALL',0,NULL),(36,'任务查询','2019-01-08 15:00:09','JOB_SELECT',35,'/api/jobs/query'),(37,'任务创建','2019-01-08 15:00:20','JOB_CREATE',35,NULL),(38,'任务编辑','2019-01-08 15:00:33','JOB_EDIT',35,NULL),(39,'任务删除','2019-01-08 15:01:13','JOB_DELETE',35,NULL),(40,'部门管理','2019-03-29 17:06:55','DEPT_ALL',0,NULL),(41,'部门查询','2019-03-29 17:07:09','DEPT_SELECT',40,NULL),(42,'部门创建','2019-03-29 17:07:29','DEPT_CREATE',40,NULL),(43,'部门编辑','2019-03-29 17:07:52','DEPT_EDIT',40,NULL),(44,'部门删除','2019-03-29 17:08:14','DEPT_DELETE',40,NULL),(45,'岗位管理','2019-03-29 17:08:52','USERJOB_ALL',0,NULL),(46,'岗位查询','2019-03-29 17:10:27','USERJOB_SELECT',45,NULL),(47,'岗位创建','2019-03-29 17:10:55','USERJOB_CREATE',45,NULL),(48,'岗位编辑','2019-03-29 17:11:08','USERJOB_EDIT',45,NULL),(49,'岗位删除','2019-03-29 17:11:19','USERJOB_DELETE',45,NULL),(50,'字典管理','2019-04-10 16:24:51','DICT_ALL',0,NULL),(51,'字典查询','2019-04-10 16:25:16','DICT_SELECT',50,'/api/dict/query'),(52,'字典创建','2019-04-10 16:25:29','DICT_CREATE',50,'/api/dict/add'),(53,'字典编辑','2019-04-10 16:27:19','DICT_EDIT',50,'/api/dict/update'),(54,'字典删除','2019-04-10 16:27:30','DICT_DELETE',50,'/api/dict/del'),(57,'字典详情查询','2019-04-10 16:25:16','DICT_DETAIL_SELECT',50,'/api/dictDetail/query'),(58,'字典详情创建','2019-04-10 16:25:29','DICT_DETAIL_CREATE',50,'/api/dictDetail/add'),(59,'字典详情编辑','2019-04-10 16:27:19','DICT_DETAIL_EDIT',50,'/api/dictDetail/update'),(60,'字典详情删除','2019-04-10 16:27:30','DICT_DETAIL_DELETE',50,'/api/dictDetail/del'),(61,'修改角色权限','2018-12-09 20:11:55','',7,'/api/roles/permission'),(62,'修改角色菜单','2018-12-09 20:11:55','',7,'/api/roles/menu'),(63,'返回全部权限','2018-12-09 20:11:55','',13,'/api/permissions/tree'),(64,'获取角色','2018-12-09 20:11:07','',7,'/api/getroles'),(65,'返回全部的角色，新增用户时下拉选择','2018-12-09 20:11:07','',7,'/api/roles/all');
/*!40000 ALTER TABLE `permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `picture`
--

DROP TABLE IF EXISTS `picture`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `picture` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `create_time` datetime DEFAULT NULL COMMENT '上传日期',
  `delete_url` varchar(255) DEFAULT NULL COMMENT '删除的URL',
  `filename` varchar(255) DEFAULT NULL COMMENT '图片名称',
  `height` varchar(255) DEFAULT NULL COMMENT '图片高度',
  `size` varchar(255) DEFAULT NULL COMMENT '图片大小',
  `url` varchar(255) DEFAULT NULL COMMENT '图片地址',
  `username` varchar(255) DEFAULT NULL COMMENT '用户名称',
  `width` varchar(255) DEFAULT NULL COMMENT '图片宽度',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `picture`
--

LOCK TABLES `picture` WRITE;
/*!40000 ALTER TABLE `picture` DISABLE KEYS */;
/*!40000 ALTER TABLE `picture` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `qiniu_config`
--

DROP TABLE IF EXISTS `qiniu_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qiniu_config` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `access_key` text COMMENT 'accessKey',
  `bucket` varchar(255) DEFAULT NULL COMMENT 'Bucket 识别符',
  `host` varchar(255) NOT NULL COMMENT '外链域名',
  `secret_key` text COMMENT 'secretKey',
  `type` varchar(255) DEFAULT NULL COMMENT '空间类型',
  `zone` varchar(255) DEFAULT NULL COMMENT '机房',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `qiniu_config`
--

LOCK TABLES `qiniu_config` WRITE;
/*!40000 ALTER TABLE `qiniu_config` DISABLE KEYS */;
/*!40000 ALTER TABLE `qiniu_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `qiniu_content`
--

DROP TABLE IF EXISTS `qiniu_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qiniu_content` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `bucket` varchar(255) DEFAULT NULL COMMENT 'Bucket 识别符',
  `name` varchar(255) DEFAULT NULL COMMENT '文件名称',
  `size` varchar(255) DEFAULT NULL COMMENT '文件大小',
  `type` varchar(255) DEFAULT NULL COMMENT '文件类型：私有或公开',
  `update_time` datetime DEFAULT NULL COMMENT '上传或同步的时间',
  `url` varchar(255) DEFAULT NULL COMMENT '文件url',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `qiniu_content`
--

LOCK TABLES `qiniu_content` WRITE;
/*!40000 ALTER TABLE `qiniu_content` DISABLE KEYS */;
/*!40000 ALTER TABLE `qiniu_content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quartz_job`
--

DROP TABLE IF EXISTS `quartz_job`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quartz_job` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `bean_name` varchar(255) DEFAULT NULL COMMENT 'Spring Bean名称',
  `cron_expression` varchar(255) DEFAULT NULL COMMENT 'cron 表达式',
  `is_pause` bit(1) DEFAULT NULL COMMENT '状态：1暂停、0启用',
  `job_name` varchar(255) DEFAULT NULL COMMENT '任务名称',
  `method_name` varchar(255) DEFAULT NULL COMMENT '方法名称',
  `params` varchar(255) DEFAULT NULL COMMENT '参数',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  `update_time` datetime DEFAULT NULL COMMENT '创建或更新日期',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quartz_job`
--

LOCK TABLES `quartz_job` WRITE;
/*!40000 ALTER TABLE `quartz_job` DISABLE KEYS */;
INSERT INTO `quartz_job` VALUES (2,'com.peng.job.EveryMinJob','0 * * * * ? *',_binary '\0','到期任务处理','run','','','2019-05-29 15:38:59'),(3,'com.peng.job.EveryDayJob','59 59 23 * * ? *',_binary '\0','每天执行一次','run','','','2019-05-29 15:38:59');
/*!40000 ALTER TABLE `quartz_job` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quartz_log`
--

DROP TABLE IF EXISTS `quartz_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quartz_log` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `baen_name` varchar(255) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `cron_expression` varchar(255) DEFAULT NULL,
  `exception_detail` text,
  `is_success` bit(1) DEFAULT NULL,
  `job_name` varchar(255) DEFAULT NULL,
  `method_name` varchar(255) DEFAULT NULL,
  `params` varchar(255) DEFAULT NULL,
  `time` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quartz_log`
--

LOCK TABLES `quartz_log` WRITE;
/*!40000 ALTER TABLE `quartz_log` DISABLE KEYS */;
INSERT INTO `quartz_log` VALUES (1,'visitsTask','2019-04-16 00:00:00','0 0 0 * * ?',NULL,_binary '','更新访客记录','run',NULL,218),(2,'visitsTask','2019-04-17 00:04:54','0 0 0 * * ?',NULL,_binary '','更新访客记录','run',NULL,11),(3,'visitsTask','2019-04-18 00:00:00','0 0 0 * * ?',NULL,_binary '','更新访客记录','run',NULL,20),(4,'visitsTask','2019-04-19 00:00:00','0 0 0 * * ?',NULL,_binary '','更新访客记录','run',NULL,20),(5,'visitsTask','2019-04-20 05:25:01','0 0 0 * * ?',NULL,_binary '','更新访客记录','run',NULL,219),(6,'visitsTask','2019-04-21 21:24:01','0 0 0 * * ?',NULL,_binary '','更新访客记录','run',NULL,161),(7,'visitsTask','2019-04-22 09:06:48','0 0 0 * * ?',NULL,_binary '','更新访客记录','run',NULL,72),(8,'visitsTask','2019-04-23 00:03:49','0 0 0 * * ?',NULL,_binary '','更新访客记录','run',NULL,116),(9,'com.peng.job.EveryMinJob','2019-04-23 15:13:01','0/5 * * * * ?','org.springframework.beans.factory.NoSuchBeanDefinitionException: No bean named \'com.peng.job.EveryMinJob\' available\n	at org.springframework.beans.factory.support.DefaultListableBeanFactory.getBeanDefinition(DefaultListableBeanFactory.java:772)\n	at org.springframework.beans.factory.support.AbstractBeanFactory.getMergedLocalBeanDefinition(AbstractBeanFactory.java:1212)\n	at org.springframework.beans.factory.support.AbstractBeanFactory.doGetBean(AbstractBeanFactory.java:294)\n	at org.springframework.beans.factory.support.AbstractBeanFactory.getBean(AbstractBeanFactory.java:199)\n	at org.springframework.context.support.AbstractApplicationContext.getBean(AbstractApplicationContext.java:1083)\n	at me.zhengjie.utils.SpringContextHolder.getBean(SpringContextHolder.java:31)\n	at me.zhengjie.modules.quartz.utils.QuartzRunnable.<init>(QuartzRunnable.java:22)\n	at me.zhengjie.modules.quartz.utils.ExecutionJob.executeInternal(ExecutionJob.java:49)\n	at org.springframework.scheduling.quartz.QuartzJobBean.execute(QuartzJobBean.java:75)\n	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)\n	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)\n',_binary '\0','测试','run','',2),(10,'com.peng.job.EveryMinJob','2019-04-23 15:13:05','0/5 * * * * ?','org.springframework.beans.factory.NoSuchBeanDefinitionException: No bean named \'com.peng.job.EveryMinJob\' available\n	at org.springframework.beans.factory.support.DefaultListableBeanFactory.getBeanDefinition(DefaultListableBeanFactory.java:772)\n	at org.springframework.beans.factory.support.AbstractBeanFactory.getMergedLocalBeanDefinition(AbstractBeanFactory.java:1212)\n	at org.springframework.beans.factory.support.AbstractBeanFactory.doGetBean(AbstractBeanFactory.java:294)\n	at org.springframework.beans.factory.support.AbstractBeanFactory.getBean(AbstractBeanFactory.java:199)\n	at org.springframework.context.support.AbstractApplicationContext.getBean(AbstractApplicationContext.java:1083)\n	at me.zhengjie.utils.SpringContextHolder.getBean(SpringContextHolder.java:31)\n	at me.zhengjie.modules.quartz.utils.QuartzRunnable.<init>(QuartzRunnable.java:22)\n	at me.zhengjie.modules.quartz.utils.ExecutionJob.executeInternal(ExecutionJob.java:49)\n	at org.springframework.scheduling.quartz.QuartzJobBean.execute(QuartzJobBean.java:75)\n	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)\n	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)\n',_binary '\0','测试','run','',1),(11,'com.peng.job.EveryMinJob','2019-04-23 15:13:10','0/5 * * * * ?','org.springframework.beans.factory.NoSuchBeanDefinitionException: No bean named \'com.peng.job.EveryMinJob\' available\n	at org.springframework.beans.factory.support.DefaultListableBeanFactory.getBeanDefinition(DefaultListableBeanFactory.java:772)\n	at org.springframework.beans.factory.support.AbstractBeanFactory.getMergedLocalBeanDefinition(AbstractBeanFactory.java:1212)\n	at org.springframework.beans.factory.support.AbstractBeanFactory.doGetBean(AbstractBeanFactory.java:294)\n	at org.springframework.beans.factory.support.AbstractBeanFactory.getBean(AbstractBeanFactory.java:199)\n	at org.springframework.context.support.AbstractApplicationContext.getBean(AbstractApplicationContext.java:1083)\n	at me.zhengjie.utils.SpringContextHolder.getBean(SpringContextHolder.java:31)\n	at me.zhengjie.modules.quartz.utils.QuartzRunnable.<init>(QuartzRunnable.java:22)\n	at me.zhengjie.modules.quartz.utils.ExecutionJob.executeInternal(ExecutionJob.java:49)\n	at org.springframework.scheduling.quartz.QuartzJobBean.execute(QuartzJobBean.java:75)\n	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)\n	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)\n',_binary '\0','测试','run','',0),(12,'com.peng.job.EveryMinJob','2019-04-23 15:13:10','0/5 * * * * ?','org.springframework.beans.factory.NoSuchBeanDefinitionException: No bean named \'com.peng.job.EveryMinJob\' available\n	at org.springframework.beans.factory.support.DefaultListableBeanFactory.getBeanDefinition(DefaultListableBeanFactory.java:772)\n	at org.springframework.beans.factory.support.AbstractBeanFactory.getMergedLocalBeanDefinition(AbstractBeanFactory.java:1212)\n	at org.springframework.beans.factory.support.AbstractBeanFactory.doGetBean(AbstractBeanFactory.java:294)\n	at org.springframework.beans.factory.support.AbstractBeanFactory.getBean(AbstractBeanFactory.java:199)\n	at org.springframework.context.support.AbstractApplicationContext.getBean(AbstractApplicationContext.java:1083)\n	at me.zhengjie.utils.SpringContextHolder.getBean(SpringContextHolder.java:31)\n	at me.zhengjie.modules.quartz.utils.QuartzRunnable.<init>(QuartzRunnable.java:22)\n	at me.zhengjie.modules.quartz.utils.ExecutionJob.executeInternal(ExecutionJob.java:49)\n	at org.springframework.scheduling.quartz.QuartzJobBean.execute(QuartzJobBean.java:75)\n	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)\n	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)\n',_binary '\0','测试','run','',0),(13,'com.peng.job.EveryMinJob','2019-04-23 15:13:14','0/5 * * * * ?','org.springframework.beans.factory.NoSuchBeanDefinitionException: No bean named \'com.peng.job.EveryMinJob\' available\n	at org.springframework.beans.factory.support.DefaultListableBeanFactory.getBeanDefinition(DefaultListableBeanFactory.java:772)\n	at org.springframework.beans.factory.support.AbstractBeanFactory.getMergedLocalBeanDefinition(AbstractBeanFactory.java:1212)\n	at org.springframework.beans.factory.support.AbstractBeanFactory.doGetBean(AbstractBeanFactory.java:294)\n	at org.springframework.beans.factory.support.AbstractBeanFactory.getBean(AbstractBeanFactory.java:199)\n	at org.springframework.context.support.AbstractApplicationContext.getBean(AbstractApplicationContext.java:1083)\n	at me.zhengjie.utils.SpringContextHolder.getBean(SpringContextHolder.java:31)\n	at me.zhengjie.modules.quartz.utils.QuartzRunnable.<init>(QuartzRunnable.java:22)\n	at me.zhengjie.modules.quartz.utils.ExecutionJob.executeInternal(ExecutionJob.java:49)\n	at org.springframework.scheduling.quartz.QuartzJobBean.execute(QuartzJobBean.java:75)\n	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)\n	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)\n',_binary '\0','测试','run','',1),(14,'com.peng.job.EveryMinJob','2019-04-23 15:13:17','0/5 * * * * ?','org.springframework.beans.factory.NoSuchBeanDefinitionException: No bean named \'com.peng.job.EveryMinJob\' available\n	at org.springframework.beans.factory.support.DefaultListableBeanFactory.getBeanDefinition(DefaultListableBeanFactory.java:772)\n	at org.springframework.beans.factory.support.AbstractBeanFactory.getMergedLocalBeanDefinition(AbstractBeanFactory.java:1212)\n	at org.springframework.beans.factory.support.AbstractBeanFactory.doGetBean(AbstractBeanFactory.java:294)\n	at org.springframework.beans.factory.support.AbstractBeanFactory.getBean(AbstractBeanFactory.java:199)\n	at org.springframework.context.support.AbstractApplicationContext.getBean(AbstractApplicationContext.java:1083)\n	at me.zhengjie.utils.SpringContextHolder.getBean(SpringContextHolder.java:31)\n	at me.zhengjie.modules.quartz.utils.QuartzRunnable.<init>(QuartzRunnable.java:22)\n	at me.zhengjie.modules.quartz.utils.ExecutionJob.executeInternal(ExecutionJob.java:49)\n	at org.springframework.scheduling.quartz.QuartzJobBean.execute(QuartzJobBean.java:75)\n	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)\n	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)\n',_binary '\0','测试','run','',0),(15,'com.peng.job.EveryMinJob','2019-04-23 15:13:17','0/5 * * * * ?','org.springframework.beans.factory.NoSuchBeanDefinitionException: No bean named \'com.peng.job.EveryMinJob\' available\n	at org.springframework.beans.factory.support.DefaultListableBeanFactory.getBeanDefinition(DefaultListableBeanFactory.java:772)\n	at org.springframework.beans.factory.support.AbstractBeanFactory.getMergedLocalBeanDefinition(AbstractBeanFactory.java:1212)\n	at org.springframework.beans.factory.support.AbstractBeanFactory.doGetBean(AbstractBeanFactory.java:294)\n	at org.springframework.beans.factory.support.AbstractBeanFactory.getBean(AbstractBeanFactory.java:199)\n	at org.springframework.context.support.AbstractApplicationContext.getBean(AbstractApplicationContext.java:1083)\n	at me.zhengjie.utils.SpringContextHolder.getBean(SpringContextHolder.java:31)\n	at me.zhengjie.modules.quartz.utils.QuartzRunnable.<init>(QuartzRunnable.java:22)\n	at me.zhengjie.modules.quartz.utils.ExecutionJob.executeInternal(ExecutionJob.java:49)\n	at org.springframework.scheduling.quartz.QuartzJobBean.execute(QuartzJobBean.java:75)\n	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)\n	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)\n',_binary '\0','测试','run','',1),(16,'com.peng.job.EveryMinJob','2019-04-23 15:13:20','0/5 * * * * ?','org.springframework.beans.factory.NoSuchBeanDefinitionException: No bean named \'com.peng.job.EveryMinJob\' available\n	at org.springframework.beans.factory.support.DefaultListableBeanFactory.getBeanDefinition(DefaultListableBeanFactory.java:772)\n	at org.springframework.beans.factory.support.AbstractBeanFactory.getMergedLocalBeanDefinition(AbstractBeanFactory.java:1212)\n	at org.springframework.beans.factory.support.AbstractBeanFactory.doGetBean(AbstractBeanFactory.java:294)\n	at org.springframework.beans.factory.support.AbstractBeanFactory.getBean(AbstractBeanFactory.java:199)\n	at org.springframework.context.support.AbstractApplicationContext.getBean(AbstractApplicationContext.java:1083)\n	at me.zhengjie.utils.SpringContextHolder.getBean(SpringContextHolder.java:31)\n	at me.zhengjie.modules.quartz.utils.QuartzRunnable.<init>(QuartzRunnable.java:22)\n	at me.zhengjie.modules.quartz.utils.ExecutionJob.executeInternal(ExecutionJob.java:49)\n	at org.springframework.scheduling.quartz.QuartzJobBean.execute(QuartzJobBean.java:75)\n	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)\n	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)\n',_binary '\0','测试','run','',1),(17,'com.peng.job.EveryMinJob','2019-04-23 15:13:25','0/5 * * * * ?','org.springframework.beans.factory.NoSuchBeanDefinitionException: No bean named \'com.peng.job.EveryMinJob\' available\n	at org.springframework.beans.factory.support.DefaultListableBeanFactory.getBeanDefinition(DefaultListableBeanFactory.java:772)\n	at org.springframework.beans.factory.support.AbstractBeanFactory.getMergedLocalBeanDefinition(AbstractBeanFactory.java:1212)\n	at org.springframework.beans.factory.support.AbstractBeanFactory.doGetBean(AbstractBeanFactory.java:294)\n	at org.springframework.beans.factory.support.AbstractBeanFactory.getBean(AbstractBeanFactory.java:199)\n	at org.springframework.context.support.AbstractApplicationContext.getBean(AbstractApplicationContext.java:1083)\n	at me.zhengjie.utils.SpringContextHolder.getBean(SpringContextHolder.java:31)\n	at me.zhengjie.modules.quartz.utils.QuartzRunnable.<init>(QuartzRunnable.java:22)\n	at me.zhengjie.modules.quartz.utils.ExecutionJob.executeInternal(ExecutionJob.java:49)\n	at org.springframework.scheduling.quartz.QuartzJobBean.execute(QuartzJobBean.java:75)\n	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)\n	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)\n',_binary '\0','测试','run','',1),(18,'com.peng.job.EveryMinJob','2019-04-23 15:13:30','0/5 * * * * ?','org.springframework.beans.factory.NoSuchBeanDefinitionException: No bean named \'com.peng.job.EveryMinJob\' available\n	at org.springframework.beans.factory.support.DefaultListableBeanFactory.getBeanDefinition(DefaultListableBeanFactory.java:772)\n	at org.springframework.beans.factory.support.AbstractBeanFactory.getMergedLocalBeanDefinition(AbstractBeanFactory.java:1212)\n	at org.springframework.beans.factory.support.AbstractBeanFactory.doGetBean(AbstractBeanFactory.java:294)\n	at org.springframework.beans.factory.support.AbstractBeanFactory.getBean(AbstractBeanFactory.java:199)\n	at org.springframework.context.support.AbstractApplicationContext.getBean(AbstractApplicationContext.java:1083)\n	at me.zhengjie.utils.SpringContextHolder.getBean(SpringContextHolder.java:31)\n	at me.zhengjie.modules.quartz.utils.QuartzRunnable.<init>(QuartzRunnable.java:22)\n	at me.zhengjie.modules.quartz.utils.ExecutionJob.executeInternal(ExecutionJob.java:49)\n	at org.springframework.scheduling.quartz.QuartzJobBean.execute(QuartzJobBean.java:75)\n	at org.quartz.core.JobRunShell.run(JobRunShell.java:202)\n	at org.quartz.simpl.SimpleThreadPool$WorkerThread.run(SimpleThreadPool.java:573)\n',_binary '\0','测试','run','',0);
/*!40000 ALTER TABLE `quartz_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `create_time` datetime DEFAULT NULL COMMENT '创建日期',
  `name` varchar(255) NOT NULL COMMENT '名称',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  `data_scope` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role`
--

LOCK TABLES `role` WRITE;
/*!40000 ALTER TABLE `role` DISABLE KEYS */;
INSERT INTO `role` VALUES (1,'2018-11-23 11:04:37','管理员','系统所有权','自定义'),(2,'2018-11-23 13:09:06','普通用户','用于测试菜单与权限','自定义');
/*!40000 ALTER TABLE `role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles_depts`
--

DROP TABLE IF EXISTS `roles_depts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles_depts` (
  `role_id` bigint(20) NOT NULL,
  `dept_id` bigint(20) NOT NULL,
  PRIMARY KEY (`role_id`,`dept_id`),
  KEY `FK7qg6itn5ajdoa9h9o78v9ksur` (`dept_id`),
  CONSTRAINT `FK7qg6itn5ajdoa9h9o78v9ksur` FOREIGN KEY (`dept_id`) REFERENCES `dept` (`id`),
  CONSTRAINT `FKrg1ci4cxxfbja0sb0pddju7k` FOREIGN KEY (`role_id`) REFERENCES `role` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles_depts`
--

LOCK TABLES `roles_depts` WRITE;
/*!40000 ALTER TABLE `roles_depts` DISABLE KEYS */;
INSERT INTO `roles_depts` VALUES (2,7),(1,11);
/*!40000 ALTER TABLE `roles_depts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles_menus`
--

DROP TABLE IF EXISTS `roles_menus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles_menus` (
  `menu_id` bigint(20) NOT NULL COMMENT '菜单ID',
  `role_id` bigint(20) NOT NULL COMMENT '角色ID',
  PRIMARY KEY (`menu_id`,`role_id`),
  KEY `FKcngg2qadojhi3a651a5adkvbq` (`role_id`),
  CONSTRAINT `FKcngg2qadojhi3a651a5adkvbq` FOREIGN KEY (`role_id`) REFERENCES `role` (`id`),
  CONSTRAINT `FKq1knxf8ykt26we8k331naabjx` FOREIGN KEY (`menu_id`) REFERENCES `menu` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles_menus`
--

LOCK TABLES `roles_menus` WRITE;
/*!40000 ALTER TABLE `roles_menus` DISABLE KEYS */;
INSERT INTO `roles_menus` VALUES (1,1),(2,1),(3,1),(4,1),(5,1),(10,1),(11,1),(15,1),(19,1),(28,1),(30,1),(33,1),(34,1),(36,1),(39,1),(45,1),(46,1),(47,1),(48,1),(49,1),(51,1),(52,1),(53,1),(54,1),(55,1),(56,1),(57,1),(58,1),(59,1),(60,1),(61,1),(1,2),(2,2),(3,2),(4,2),(5,2),(28,2),(36,2),(39,2);
/*!40000 ALTER TABLE `roles_menus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles_permissions`
--

DROP TABLE IF EXISTS `roles_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles_permissions` (
  `role_id` bigint(20) NOT NULL COMMENT '角色ID',
  `permission_id` bigint(20) NOT NULL COMMENT '权限ID',
  PRIMARY KEY (`role_id`,`permission_id`),
  KEY `FKboeuhl31go7wer3bpy6so7exi` (`permission_id`),
  CONSTRAINT `FK4hrolwj4ned5i7qe8kyiaak6m` FOREIGN KEY (`role_id`) REFERENCES `role` (`id`),
  CONSTRAINT `FKboeuhl31go7wer3bpy6so7exi` FOREIGN KEY (`permission_id`) REFERENCES `permission` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles_permissions`
--

LOCK TABLES `roles_permissions` WRITE;
/*!40000 ALTER TABLE `roles_permissions` DISABLE KEYS */;
INSERT INTO `roles_permissions` VALUES (1,1),(2,1),(2,2),(2,3),(2,4),(2,5),(2,6),(2,7),(2,8),(2,10),(2,11),(2,12),(2,13),(2,14),(2,15),(2,16),(2,17),(2,29),(2,30),(2,31),(2,32),(2,33),(2,34),(2,35),(2,36),(2,37),(2,38),(2,39),(2,50),(2,51),(2,52),(2,53),(2,54),(2,57),(2,58),(2,59),(2,60),(2,61),(2,62),(2,63),(2,64),(2,65);
/*!40000 ALTER TABLE `roles_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `avatar` varchar(255) DEFAULT NULL COMMENT '头像地址',
  `create_time` datetime DEFAULT NULL COMMENT '创建日期',
  `email` varchar(255) DEFAULT NULL COMMENT '邮箱',
  `enabled` bigint(20) DEFAULT NULL COMMENT '状态：1启用、0禁用',
  `password` varchar(255) DEFAULT NULL COMMENT '密码',
  `username` varchar(255) DEFAULT NULL COMMENT '用户名',
  `last_password_reset_time` datetime DEFAULT NULL COMMENT '最后修改密码的日期',
  `dept_id` bigint(20) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `job_id` bigint(20) DEFAULT NULL,
  `is_admin` int(11) NOT NULL DEFAULT '0' COMMENT '是否超级管理员',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK_kpubos9gc2cvtkb0thktkbkes` (`email`),
  UNIQUE KEY `username` (`username`),
  KEY `FK5rwmryny6jthaaxkogownknqp` (`dept_id`),
  KEY `FKfftoc2abhot8f2wu6cl9a5iky` (`job_id`),
  CONSTRAINT `FK5rwmryny6jthaaxkogownknqp` FOREIGN KEY (`dept_id`) REFERENCES `dept` (`id`),
  CONSTRAINT `FKfftoc2abhot8f2wu6cl9a5iky` FOREIGN KEY (`job_id`) REFERENCES `job` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'https://i.loli.net/2019/04/04/5ca5b971e1548.jpeg','2018-08-23 09:11:56','admin@eladmin.net',1,'88c704a3c5029c9851a2d4e436d903d6','admin','2019-04-04 16:00:46',2,'18888888888',11,1),(3,'https://aurora-1255840532.cos.ap-chengdu.myqcloud.com/8918a306ea314404835a9196585c4b75.jpeg','2018-12-27 20:05:26','test@eladmin.net',0,'88c704a3c5029c9851a2d4e436d903d6','test','2019-04-01 09:15:24',2,'17777777777',12,0);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_roles`
--

DROP TABLE IF EXISTS `users_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users_roles` (
  `user_id` bigint(20) NOT NULL COMMENT '用户ID',
  `role_id` bigint(20) NOT NULL COMMENT '角色ID',
  PRIMARY KEY (`user_id`,`role_id`),
  KEY `FKq4eq273l04bpu4efj0jd0jb98` (`role_id`),
  CONSTRAINT `users_roles_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `role` (`id`),
  CONSTRAINT `users_roles_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_roles`
--

LOCK TABLES `users_roles` WRITE;
/*!40000 ALTER TABLE `users_roles` DISABLE KEYS */;
INSERT INTO `users_roles` VALUES (1,1),(3,2);
/*!40000 ALTER TABLE `users_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `verification_code`
--

DROP TABLE IF EXISTS `verification_code`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `verification_code` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `code` varchar(255) DEFAULT NULL COMMENT '验证码',
  `create_time` datetime DEFAULT NULL COMMENT '创建日期',
  `status` bit(1) DEFAULT NULL COMMENT '状态：1有效、0过期',
  `type` varchar(255) DEFAULT NULL COMMENT '验证码类型：email或者短信',
  `value` varchar(255) DEFAULT NULL COMMENT '接收邮箱或者手机号码',
  `scenes` varchar(255) DEFAULT NULL COMMENT '业务名称：如重置邮箱、重置密码等',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `verification_code`
--

LOCK TABLES `verification_code` WRITE;
/*!40000 ALTER TABLE `verification_code` DISABLE KEYS */;
/*!40000 ALTER TABLE `verification_code` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `visits`
--

DROP TABLE IF EXISTS `visits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `visits` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `create_time` datetime DEFAULT NULL,
  `date` varchar(255) DEFAULT NULL,
  `ip_counts` bigint(20) DEFAULT NULL,
  `pv_counts` bigint(20) DEFAULT NULL,
  `week_day` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK_11aksgq87euk9bcyeesfs4vtp` (`date`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `visits`
--

LOCK TABLES `visits` WRITE;
/*!40000 ALTER TABLE `visits` DISABLE KEYS */;
INSERT INTO `visits` VALUES (20,'2019-04-15 10:30:41','2019-04-15',1,5,'Mon'),(21,'2019-04-16 00:00:00','2019-04-16',1,3,'Tue'),(22,'2019-04-17 00:04:54','2019-04-17',1,4,'Wed'),(23,'2019-04-18 00:00:00','2019-04-18',1,1,'Thu'),(24,'2019-04-19 00:00:00','2019-04-19',1,1,'Fri'),(25,'2019-04-20 05:25:01','2019-04-20',1,1,'Sat'),(26,'2019-04-21 21:24:00','2019-04-21',1,1,'Sun'),(27,'2019-04-22 09:06:48','2019-04-22',1,6,'Mon'),(28,'2019-04-23 00:03:49','2019-04-23',1,1,'Tue'),(29,'2019-05-14 09:15:17','2019-05-14',1,2,'Tue');
/*!40000 ALTER TABLE `visits` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-11-12 18:29:22
