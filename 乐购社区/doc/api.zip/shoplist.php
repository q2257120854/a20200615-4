<?php
 
 
 header('Content-type:text/html;charset=utf-8');
 
  
  

 ?>
 
<form action="" method="get" >
 <input name="url"    placeholder="请输入域名"  type="text" />
 <input name="提交" type="submit" value="查询" id="提交" /> 
 </form>
  <? if ($_GET['url']!=''){
	    $apiurl = 'http://'.$_GET['url'].'/api/shoplist.php';
$params = array(
  );
 
$paramsString = http_build_query($params);
 
$content = @file_get_contents($apiurl);
$result = json_decode($content,true);
 $arr = json_decode($content,true);
$data = call_user_func_array('array_merge_recursive',$arr['goods_rows']);
//key为a的项所有值
$sid =$data['ID'];
$sname =$data['name'];

?>
                             <select  style="width:150px">
			 	<?php
						
						 for ($i = 0; $i < sizeof($sid); $i++) {  
						  if ($api_status[$i] ==1)
 						 
 							?>
                         
                              <option value="<?=$sid[$i]?>">商品名称:<?=$sname[$i]?> 商品ID:<?=$sid[$i]?></option>
  
				 <? }?>
                 
                  </select>
		 <? }?>
 